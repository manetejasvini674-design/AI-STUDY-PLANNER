<?php
require_once __DIR__ . "/config.php";
startSession();
if (!isset($_SESSION["user_id"])) { header("Location: login.php"); exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1.0"/>
  <title>Analytics – StudyAI</title>
  <style>
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;1,9..40,300&display=swap');

/* ===== RESET & ROOT ===== */
* { margin: 0; padding: 0; box-sizing: border-box; }
:root {
  --bg: #060910;
  --surface: #0d1117;
  --surface2: #111827;
  --border: rgba(255,255,255,0.06);
  --border-glow: rgba(0,210,255,0.2);
  --cyan: #00d2ff;
  --cyan-dim: rgba(0,210,255,0.12);
  --violet: #7c3aed;
  --violet-dim: rgba(124,58,237,0.15);
  --emerald: #10b981;
  --amber: #f59e0b;
  --rose: #f43f5e;
  --text: #f0f4f8;
  --text-2: #8b9db5;
  --text-3: #4a5568;
}
body { background: var(--bg); color: var(--text); font-family: 'DM Sans', sans-serif; overflow-x: hidden; }
::-webkit-scrollbar { width: 4px; }
::-webkit-scrollbar-track { background: var(--surface); }
::-webkit-scrollbar-thumb { background: var(--cyan); border-radius: 4px; }

/* ===== ANIMATIONS ===== */
@keyframes fadeUp    { from { opacity:0; transform:translateY(24px); } to { opacity:1; transform:translateY(0); } }
@keyframes fadeIn    { from { opacity:0; } to { opacity:1; } }
@keyframes float     { 0%,100% { transform:translateY(0); } 50% { transform:translateY(-8px); } }
@keyframes glowPulse { 0%,100% { box-shadow:0 0 20px rgba(0,210,255,.1); } 50% { box-shadow:0 0 40px rgba(0,210,255,.3); } }
@keyframes gradShift { 0%,100% { background-position:0% 50%; } 50% { background-position:100% 50%; } }
@keyframes barGrow   { from { width:0; } to { width:var(--w); } }
@keyframes countUp   { from { opacity:0; transform:scale(.7); } to { opacity:1; transform:scale(1); } }
@keyframes slideIn   { from { opacity:0; transform:translateX(-20px); } to { opacity:1; transform:translateX(0); } }
@keyframes bounce    { 0%,80%,100% { transform:scale(.6); opacity:.5; } 40% { transform:scale(1); opacity:1; } }
@keyframes spin      { from { transform:rotate(0deg); } to { transform:rotate(360deg); } }
@keyframes orbit     { from { transform:rotate(0deg) translateX(60px) rotate(0deg); } to { transform:rotate(360deg) translateX(60px) rotate(-360deg); } }

.fade-up   { animation: fadeUp .6s ease forwards; }
.fade-up-1 { animation: fadeUp .6s .1s ease forwards; opacity:0; }
.fade-up-2 { animation: fadeUp .6s .2s ease forwards; opacity:0; }
.fade-up-3 { animation: fadeUp .6s .3s ease forwards; opacity:0; }
.fade-up-4 { animation: fadeUp .6s .4s ease forwards; opacity:0; }
.slide-in  { animation: slideIn .5s ease forwards; }

/* ===== LAYOUT ===== */
.app { display:flex; min-height:100vh; }

/* ===== SIDEBAR ===== */
.sidebar {
  width:240px; min-height:100vh; background:var(--surface);
  border-right:1px solid var(--border); display:flex; flex-direction:column;
  position:fixed; left:0; top:0; bottom:0; z-index:100;
}
.sidebar-logo {
  padding:28px 24px; border-bottom:1px solid var(--border);
  display:flex; align-items:center; gap:12px;
}
.logo-icon {
  width:38px; height:38px; background:linear-gradient(135deg,var(--cyan),var(--violet));
  border-radius:10px; display:flex; align-items:center; justify-content:center;
  font-size:18px; animation:float 3s ease-in-out infinite; flex-shrink:0;
}
.logo-text {
  font-family:'Syne',sans-serif; font-weight:800; font-size:16px;
  background:linear-gradient(90deg,var(--cyan),var(--violet));
  -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text;
}
.logo-sub { font-size:10px; color:var(--text-3); margin-top:1px; }
.sidebar-nav { flex:1; padding:16px 12px; display:flex; flex-direction:column; gap:4px; overflow-y:auto; }
.nav-section-label {
  font-size:10px; font-weight:600; letter-spacing:.12em;
  color:var(--text-3); padding:12px 12px 6px; text-transform:uppercase;
}
.nav-item {
  display:flex; align-items:center; gap:10px; padding:10px 12px;
  border-radius:10px; cursor:pointer; transition:all .2s;
  color:var(--text-2); font-size:14px; font-weight:400; position:relative;
  border:1px solid transparent; text-decoration:none;
}
.nav-item:hover { background:var(--cyan-dim); color:var(--text); border-color:var(--border-glow); }
.nav-item.active {
  background:linear-gradient(135deg,rgba(0,210,255,.15),rgba(124,58,237,.1));
  color:var(--cyan); border-color:rgba(0,210,255,.25);
  box-shadow:inset 0 0 20px rgba(0,210,255,.05);
}
.nav-item.active::before {
  content:''; position:absolute; left:0; top:50%; transform:translateY(-50%);
  width:3px; height:60%; background:var(--cyan); border-radius:0 2px 2px 0;
}
.nav-icon { width:18px; height:18px; flex-shrink:0; display:flex; align-items:center; justify-content:center; }
.nav-badge {
  margin-left:auto; background:var(--rose); color:#fff;
  font-size:10px; font-weight:700; padding:2px 7px; border-radius:20px;
}
.sidebar-footer { padding:16px 12px; border-top:1px solid var(--border); }
.user-card {
  display:flex; align-items:center; gap:10px; padding:10px 12px;
  background:var(--surface2); border-radius:10px; border:1px solid var(--border); cursor:pointer; transition:all .2s;
}
.user-card:hover { border-color:var(--border-glow); }
.avatar {
  width:34px; height:34px; border-radius:50%;
  background:linear-gradient(135deg,var(--cyan),var(--violet));
  display:flex; align-items:center; justify-content:center;
  font-weight:700; font-size:14px; color:#fff; flex-shrink:0;
}
.avatar-lg { width:50px; height:50px; font-size:18px; }
.user-name  { font-size:13px; font-weight:500; color:var(--text); }
.user-role  { font-size:11px; color:var(--text-2); }

/* ===== MAIN ===== */
.main { margin-left:240px; flex:1; min-height:100vh; }

/* ===== TOPBAR ===== */
.topbar {
  height:64px; background:rgba(13,17,23,.8); backdrop-filter:blur(20px);
  border-bottom:1px solid var(--border); display:flex; align-items:center;
  padding:0 32px; gap:16px; position:sticky; top:0; z-index:50;
}
.topbar-title { font-family:'Syne',sans-serif; font-weight:700; font-size:18px; flex:1; }
.topbar-actions { display:flex; align-items:center; gap:10px; }
.icon-btn {
  width:38px; height:38px; border-radius:10px; border:1px solid var(--border);
  background:var(--surface2); display:flex; align-items:center; justify-content:center;
  cursor:pointer; transition:all .2s; color:var(--text-2); position:relative;
}
.icon-btn:hover { border-color:var(--border-glow); color:var(--cyan); box-shadow:0 0 20px rgba(0,210,255,.15); }
.notif-dot {
  position:absolute; top:7px; right:7px; width:7px; height:7px;
  background:var(--rose); border-radius:50%; border:1.5px solid var(--surface);
}

/* ===== PAGE ===== */
.page { padding:32px; animation:fadeIn .4s ease; }

/* ===== CARDS ===== */
.card {
  background:var(--surface); border:1px solid var(--border); border-radius:16px;
  padding:24px; transition:all .3s;
}
.card:hover { border-color:rgba(0,210,255,.15); box-shadow:0 4px 30px rgba(0,0,0,.3); }

/* ===== STAT CARD ===== */
.stat-card {
  background:var(--surface); border:1px solid var(--border); border-radius:16px;
  padding:22px; position:relative; overflow:hidden; transition:all .3s;
}
.stat-card::after {
  content:''; position:absolute; bottom:0; left:0; right:0; height:2px;
  background:var(--accent,var(--cyan)); transform:scaleX(0); transition:transform .3s; transform-origin:left;
}
.stat-card:hover::after { transform:scaleX(1); }
.stat-card:hover { border-color:var(--border-glow); transform:translateY(-2px); }
.stat-icon { width:42px; height:42px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:20px; margin-bottom:14px; }
.stat-value { font-family:'Syne',sans-serif; font-weight:800; font-size:28px; line-height:1; animation:countUp .5s ease; }
.stat-label { font-size:13px; color:var(--text-2); margin-top:4px; }
.stat-change { font-size:12px; margin-top:8px; display:flex; align-items:center; gap:4px; }
.stat-up   { color:var(--emerald); }
.stat-down { color:var(--rose); }

/* ===== SECTION HEADER ===== */
.section-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:20px; }
.section-title { font-family:'Syne',sans-serif; font-weight:700; font-size:18px; }
.section-sub   { font-size:13px; color:var(--text-2); margin-top:2px; }

/* ===== BUTTONS ===== */
.btn-primary {
  background:linear-gradient(135deg,var(--cyan),var(--violet));
  border:none; color:#fff; padding:10px 20px; border-radius:10px;
  cursor:pointer; font-size:14px; font-weight:500; font-family:'DM Sans',sans-serif;
  transition:all .2s; box-shadow:0 4px 15px rgba(0,210,255,.2); display:inline-flex; align-items:center; gap:6px;
}
.btn-primary:hover { transform:translateY(-1px); box-shadow:0 6px 25px rgba(0,210,255,.35); }
.btn-secondary {
  background:var(--surface2); border:1px solid var(--border); color:var(--text);
  padding:10px 20px; border-radius:10px; cursor:pointer; font-size:14px;
  font-family:'DM Sans',sans-serif; transition:all .2s; display:inline-flex; align-items:center; gap:6px;
}
.btn-secondary:hover { border-color:var(--border-glow); color:var(--cyan); }
.btn-ghost {
  background:none; border:1px solid var(--border); color:var(--text-2);
  padding:8px 16px; border-radius:8px; cursor:pointer; font-size:13px;
  font-family:'DM Sans',sans-serif; transition:all .2s; display:inline-flex; align-items:center; gap:6px;
}
.btn-ghost:hover { border-color:var(--border-glow); color:var(--cyan); }
.btn-hero {
  padding:14px 32px; border-radius:12px; font-size:15px; font-weight:600;
  cursor:pointer; font-family:'DM Sans',sans-serif; transition:all .3s;
}
.btn-hero-primary {
  background:linear-gradient(135deg,var(--cyan),var(--violet));
  border:none; color:#fff; box-shadow:0 8px 30px rgba(0,210,255,.3);
}
.btn-hero-primary:hover { transform:translateY(-2px); box-shadow:0 12px 40px rgba(0,210,255,.45); }
.btn-hero-secondary { background:transparent; border:1px solid var(--border); color:var(--text); }
.btn-hero-secondary:hover { border-color:var(--border-glow); color:var(--cyan); }
.btn-sm { padding:6px 14px; font-size:12px; border-radius:8px; }
.btn-icon {
  width:38px; height:38px; padding:0; border-radius:10px;
  display:inline-flex; align-items:center; justify-content:center;
}

/* ===== FORMS ===== */
.form-group { margin-bottom:16px; }
.input-label { font-size:13px; color:var(--text-2); margin-bottom:6px; display:block; }
.input-field {
  width:100%; background:var(--surface2); border:1px solid var(--border);
  border-radius:10px; padding:10px 14px; color:var(--text); font-size:14px;
  font-family:'DM Sans',sans-serif; transition:all .2s; outline:none;
}
.input-field:focus { border-color:var(--border-glow); box-shadow:0 0 0 3px rgba(0,210,255,.08); }
.input-field::placeholder { color:var(--text-3); }
.select-field {
  width:100%; background:var(--surface2); border:1px solid var(--border);
  border-radius:10px; padding:10px 14px; color:var(--text); font-size:14px;
  font-family:'DM Sans',sans-serif; transition:all .2s; outline:none; appearance:none; cursor:pointer;
}
.select-field:focus { border-color:var(--border-glow); }
select option { background:var(--surface2); color:var(--text); }

/* ===== PROGRESS ===== */
.progress-wrap   { margin-bottom:14px; }
.progress-header { display:flex; justify-content:space-between; margin-bottom:6px; font-size:13px; }
.progress-track  { height:6px; background:var(--surface2); border-radius:20px; overflow:hidden; }
.progress-fill {
  height:100%; border-radius:20px; transition:width 1.2s ease;
  background:linear-gradient(90deg, var(--pfrom, var(--cyan)), var(--pto, var(--violet)));
}

/* ===== GRIDS ===== */
.grid-4 { display:grid; grid-template-columns:repeat(4,1fr); gap:16px; }
.grid-3 { display:grid; grid-template-columns:repeat(3,1fr); gap:16px; }
.grid-2 { display:grid; grid-template-columns:repeat(2,1fr); gap:20px; }
.grid-13 { display:grid; grid-template-columns:1fr 3fr; gap:20px; }
.grid-31 { display:grid; grid-template-columns:3fr 1fr; gap:20px; }

/* ===== TAGS ===== */
.tag { display:inline-flex; align-items:center; gap:4px; padding:4px 10px; border-radius:6px; font-size:12px; font-weight:500; }

/* ===== TASK ITEM ===== */
.task-item {
  display:flex; align-items:center; gap:12px; padding:14px 16px;
  background:var(--surface2); border-radius:10px; border:1px solid var(--border);
  margin-bottom:8px; transition:all .2s; cursor:pointer;
}
.task-item:hover { border-color:var(--border-glow); background:rgba(0,210,255,.03); }
.task-check {
  width:20px; height:20px; border-radius:6px; border:2px solid var(--border-glow);
  display:flex; align-items:center; justify-content:center; flex-shrink:0; transition:all .2s;
}
.task-check.done { background:var(--emerald); border-color:var(--emerald); }
.task-name     { font-size:14px; font-weight:500; }
.task-name.done { text-decoration:line-through; color:var(--text-2); }
.task-meta     { font-size:12px; color:var(--text-2); margin-top:2px; }

/* ===== NOTIFICATIONS ===== */
.notif-item {
  display:flex; gap:12px; padding:14px 16px; border-radius:10px;
  border:1px solid var(--border); background:var(--surface2); margin-bottom:8px; transition:all .2s;
}
.notif-item:hover { border-color:var(--border-glow); }
.notif-item.unread { border-left:3px solid var(--cyan); }
.notif-dot-ui { width:38px; height:38px; border-radius:10px; flex-shrink:0; display:flex; align-items:center; justify-content:center; font-size:18px; }

/* ===== SCHEDULE ===== */
.schedule-block {
  border-radius:8px; padding:8px 12px; margin-bottom:4px; font-size:13px;
  font-weight:500; border-left:3px solid; transition:all .2s; cursor:pointer;
}
.schedule-block:hover { transform:translateX(3px); }

/* ===== AI THINKING ===== */
.ai-thinking { display:flex; gap:4px; align-items:center; }
.ai-dot { width:8px; height:8px; border-radius:50%; background:var(--cyan); animation:bounce 1.2s ease-in-out infinite; }
.ai-dot:nth-child(2) { animation-delay:.2s; background:var(--violet); }
.ai-dot:nth-child(3) { animation-delay:.4s; background:#ff6b9d; }

/* ===== KANBAN ===== */
.kanban-col {
  background:var(--surface); border:1px solid var(--border); border-radius:16px;
  padding:20px; min-height:400px;
}
.kanban-card {
  background:var(--surface2); border:1px solid var(--border); border-radius:12px;
  padding:14px; margin-bottom:8px; transition:all .2s; cursor:pointer;
}
.kanban-card:hover { border-color:rgba(0,210,255,.2); transform:translateY(-1px); box-shadow:0 4px 20px rgba(0,0,0,.3); }

/* ===== LANDING ===== */
.landing-nav {
  position:fixed; top:0; left:0; right:0; z-index:200;
  padding:16px 48px; display:flex; align-items:center; justify-content:space-between;
  background:rgba(6,9,16,.85); backdrop-filter:blur(20px);
  border-bottom:1px solid var(--border);
}
.landing-nav-link { font-size:14px; color:var(--text-2); cursor:pointer; transition:color .2s; text-decoration:none; }
.landing-nav-link:hover { color:var(--text); }
.hero { min-height:100vh; display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center; padding:40px; position:relative; overflow:hidden; }
.hero-bg { position:absolute; inset:0; overflow:hidden; z-index:0; }
.orb { position:absolute; border-radius:50%; filter:blur(80px); opacity:.15; }
.orb1 { width:600px; height:600px; background:var(--cyan); top:-200px; left:-200px; }
.orb2 { width:500px; height:500px; background:var(--violet); bottom:-150px; right:-150px; }
.orb3 { width:300px; height:300px; background:var(--emerald); bottom:100px; left:200px; animation:float 6s ease-in-out infinite; }
.hero-content { position:relative; z-index:1; max-width:800px; }
.hero-badge {
  display:inline-flex; align-items:center; gap:8px; padding:8px 16px;
  background:rgba(0,210,255,.1); border:1px solid rgba(0,210,255,.25);
  border-radius:20px; font-size:13px; color:var(--cyan); margin-bottom:32px;
  animation:glowPulse 2s ease-in-out infinite;
}
.hero-title { font-family:'Syne',sans-serif; font-weight:800; font-size:64px; line-height:1.05; margin-bottom:20px; letter-spacing:-2px; }
.gradient-text {
  background:linear-gradient(135deg,var(--cyan),var(--violet),#ff6b9d);
  background-size:200% auto; -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text;
  animation:gradShift 3s ease infinite;
}
.hero-sub { font-size:18px; color:var(--text-2); line-height:1.6; margin-bottom:40px; max-width:560px; margin-left:auto; margin-right:auto; }
.features-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:20px; margin-top:80px; text-align:left; }
.feature-card {
  background:rgba(13,17,23,.7); backdrop-filter:blur(20px); border:1px solid var(--border);
  border-radius:16px; padding:24px; transition:all .3s;
}
.feature-card:hover { border-color:var(--border-glow); transform:translateY(-4px); box-shadow:0 20px 40px rgba(0,0,0,.4); }
.feature-icon  { font-size:28px; margin-bottom:14px; }
.feature-title { font-family:'Syne',sans-serif; font-weight:700; font-size:16px; margin-bottom:8px; }
.feature-desc  { font-size:13px; color:var(--text-2); line-height:1.6; }

/* ===== AUTH ===== */
.auth-wrap { min-height:100vh; display:flex; align-items:center; justify-content:center; background:var(--bg); position:relative; overflow:hidden; }
.auth-card {
  background:var(--surface); border:1px solid var(--border); border-radius:20px;
  padding:40px; width:420px; position:relative; z-index:1; animation:fadeUp .5s ease;
}
.auth-title { font-family:'Syne',sans-serif; font-weight:800; font-size:28px; margin-bottom:8px; }
.auth-sub   { font-size:14px; color:var(--text-2); margin-bottom:32px; }
.auth-divider { display:flex; align-items:center; gap:12px; margin:20px 0; color:var(--text-3); font-size:12px; }
.auth-divider::before,.auth-divider::after { content:''; flex:1; height:1px; background:var(--border); }
.auth-link { color:var(--cyan); text-decoration:none; font-size:14px; }
.auth-link:hover { text-decoration:underline; }

/* ===== DASHBOARD PREVIEW (login page) ===== */
.dashboard-preview {
  background:var(--surface2); border:1px solid var(--border); border-radius:16px;
  padding:20px; cursor:pointer; transition:all .3s; position:relative; overflow:hidden;
  margin-top:20px;
}
.dashboard-preview::before {
  content:''; position:absolute; inset:0;
  background:linear-gradient(135deg,rgba(0,210,255,.05),rgba(124,58,237,.05));
  opacity:0; transition:opacity .3s;
}
.dashboard-preview:hover { border-color:var(--border-glow); transform:translateY(-3px); box-shadow:0 10px 40px rgba(0,210,255,.1); }
.dashboard-preview:hover::before { opacity:1; }
.preview-badge {
  display:inline-flex; align-items:center; gap:6px; padding:6px 12px;
  background:rgba(0,210,255,.1); border:1px solid rgba(0,210,255,.2);
  border-radius:20px; font-size:12px; color:var(--cyan); margin-bottom:12px;
}
.preview-mini-stat {
  background:var(--surface); border:1px solid var(--border); border-radius:10px;
  padding:12px; text-align:center;
}
.preview-mini-val { font-family:'Syne',sans-serif; font-weight:800; font-size:20px; }
.preview-mini-lbl { font-size:11px; color:var(--text-2); margin-top:2px; }
.preview-bar { height:5px; background:var(--surface); border-radius:20px; overflow:hidden; margin-top:6px; }
.preview-bar-fill { height:100%; border-radius:20px; background:linear-gradient(90deg,var(--cyan),var(--violet)); }

/* ===== TIMER ===== */
.timer-display {
  font-family:'Syne',sans-serif; font-size:72px; font-weight:800;
  background:linear-gradient(135deg,var(--cyan),var(--violet));
  -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text;
  letter-spacing:-2px; line-height:1;
}

/* ===== CGPA TOOL ===== */
.cgpa-card {
  background:var(--surface); border:1px solid var(--border); border-radius:16px;
  padding:28px; transition:all .3s;
}
.cgpa-result {
  background:linear-gradient(135deg,rgba(0,210,255,.08),rgba(124,58,237,.08));
  border:1px solid rgba(0,210,255,.2); border-radius:14px; padding:24px;
  animation:fadeUp .5s ease;
}
.cgpa-big { font-family:'Syne',sans-serif; font-weight:800; font-size:48px; background:linear-gradient(135deg,var(--cyan),var(--violet)); -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text; }
.subject-row { display:grid; grid-template-columns:2fr 1fr 1fr 38px; gap:10px; align-items:center; margin-bottom:10px; }
.subject-row-header { display:grid; grid-template-columns:2fr 1fr 1fr 38px; gap:10px; align-items:center; margin-bottom:8px; font-size:12px; color:var(--text-3); font-weight:600; letter-spacing:.05em; text-transform:uppercase; }
.remove-btn {
  width:34px; height:34px; border-radius:8px; background:rgba(244,63,94,.1); border:1px solid rgba(244,63,94,.2);
  color:var(--rose); cursor:pointer; display:flex; align-items:center; justify-content:center;
  transition:all .2s; font-size:16px; flex-shrink:0;
}
.remove-btn:hover { background:rgba(244,63,94,.2); }
.plan-item {
  display:flex; gap:14px; padding:14px 16px; background:var(--surface2); border:1px solid var(--border);
  border-radius:12px; margin-bottom:10px; animation:slideIn .4s ease;
}
.plan-item-icon { width:40px; height:40px; border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:18px; flex-shrink:0; }

/* ===== TOOLTIP ===== */
.tooltip-wrap { position:relative; }
.tooltip {
  position:absolute; bottom:calc(100% + 8px); left:50%; transform:translateX(-50%);
  background:var(--surface2); border:1px solid var(--border); border-radius:8px;
  padding:6px 10px; font-size:12px; white-space:nowrap; pointer-events:none; opacity:0; transition:opacity .2s; z-index:99;
}
.tooltip-wrap:hover .tooltip { opacity:1; }

/* ===== STEP INDICATOR ===== */
.step-bar { display:flex; gap:8px; margin-bottom:24px; }
.step-seg { flex:1; height:3px; border-radius:4px; transition:all .3s; }
.step-seg.active { background:linear-gradient(90deg,var(--cyan),var(--violet)); box-shadow:0 0 10px rgba(0,210,255,.3); }
.step-seg.inactive { background:var(--border); }

/* ===== MISC ===== */
.divider { height:1px; background:var(--border); margin:20px 0; }
.badge { display:inline-flex; align-items:center; padding:3px 10px; border-radius:20px; font-size:12px; font-weight:600; }
.glow-cyan { box-shadow:0 0 20px rgba(0,210,255,.2); }
.glow-violet { box-shadow:0 0 20px rgba(124,58,237,.2); }
.text-cyan { color:var(--cyan); }
.text-violet { color:var(--violet); }
.text-emerald { color:var(--emerald); }
.text-amber { color:var(--amber); }
.text-rose { color:var(--rose); }
.text-muted { color:var(--text-2); }
.fw-bold { font-weight:700; }
.fw-800 { font-family:'Syne',sans-serif; font-weight:800; }
.mt-8  { margin-top:8px; }
.mt-16 { margin-top:16px; }
.mt-24 { margin-top:24px; }
.mb-8  { margin-bottom:8px; }
.mb-16 { margin-bottom:16px; }
.mb-24 { margin-bottom:24px; }
.flex  { display:flex; }
.flex-center { display:flex; align-items:center; }
.flex-between { display:flex; align-items:center; justify-content:space-between; }
.flex-col { display:flex; flex-direction:column; }
.gap-8  { gap:8px; }
.gap-12 { gap:12px; }
.gap-16 { gap:16px; }
.gap-24 { gap:24px; }
.w-full { width:100%; }
.text-center { text-align:center; }

/* ===== MINI CHART SVG ===== */
.chart-svg { width:100%; overflow:visible; }


/* ═══ SIDEBAR EXTRA ═══ */
.sidebar { width:240px; min-height:100vh; background:var(--surface); border-right:1px solid var(--border); display:flex; flex-direction:column; position:fixed; left:0; top:0; bottom:0; z-index:100; }
.sidebar-logo { padding:26px 20px; border-bottom:1px solid var(--border); display:flex; align-items:center; gap:12px; }
.logo-icon { width:38px; height:38px; background:linear-gradient(135deg,var(--cyan),var(--violet)); border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:18px; animation:float 3s ease-in-out infinite; flex-shrink:0; text-decoration:none; }
.logo-text { font-family:'Syne',sans-serif; font-weight:800; font-size:16px; background:linear-gradient(90deg,var(--cyan),var(--violet)); -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text; }
.logo-sub { font-size:10px; color:var(--text-3); margin-top:1px; }
.sidebar-nav { flex:1; padding:14px 10px; display:flex; flex-direction:column; gap:3px; overflow-y:auto; }
.sidebar-nav::-webkit-scrollbar { width:2px; }
.nav-section-label { font-size:10px; font-weight:700; letter-spacing:.12em; color:var(--text-3); padding:10px 12px 5px; text-transform:uppercase; }
.nav-item { display:flex; align-items:center; gap:10px; padding:10px 12px; border-radius:10px; cursor:pointer; transition:all .2s; color:var(--text-2); font-size:13.5px; font-weight:400; position:relative; border:1px solid transparent; text-decoration:none; }
.nav-item:hover { background:var(--cyan-dim); color:var(--text); border-color:var(--border-glow); }
.nav-item-active { background:linear-gradient(135deg,rgba(0,210,255,.15),rgba(124,58,237,.1)) !important; color:var(--cyan) !important; border-color:rgba(0,210,255,.25) !important; box-shadow:inset 0 0 20px rgba(0,210,255,.05); }
.nav-active-bar { position:absolute; left:0; top:50%; transform:translateY(-50%); width:3px; height:60%; background:var(--cyan); border-radius:0 2px 2px 0; }
.nav-icon { width:20px; height:20px; flex-shrink:0; display:flex; align-items:center; justify-content:center; font-size:15px; }
.nav-label { flex:1; }
.nav-badge { margin-left:auto; background:var(--rose); color:#fff; font-size:10px; font-weight:700; padding:2px 7px; border-radius:20px; min-width:20px; text-align:center; }
.sidebar-footer { padding:14px 10px; border-top:1px solid var(--border); }
.user-card { display:flex; align-items:center; gap:10px; padding:10px 12px; background:var(--surface2); border-radius:10px; border:1px solid var(--border); cursor:pointer; transition:all .2s; }
.user-card:hover { border-color:var(--border-glow); }
.avatar { width:34px; height:34px; border-radius:50%; background:linear-gradient(135deg,var(--cyan),var(--violet)); display:flex; align-items:center; justify-content:center; font-weight:700; font-size:13px; color:#fff; flex-shrink:0; }
.user-name { font-size:13px; font-weight:500; color:var(--text); }
.user-role { font-size:11px; color:var(--text-2); }

/* ═══ TOPBAR EXTRA ═══ */
.topbar { height:64px; background:rgba(13,17,23,.9); backdrop-filter:blur(20px); border-bottom:1px solid var(--border); display:flex; align-items:center; padding:0 28px; gap:16px; position:sticky; top:0; z-index:50; }
.topbar-title { font-family:'Syne',sans-serif; font-weight:700; font-size:18px; flex:1; }
.topbar-actions { display:flex; align-items:center; gap:10px; }
.icon-btn { width:38px; height:38px; border-radius:10px; border:1px solid var(--border); background:var(--surface2); display:flex; align-items:center; justify-content:center; cursor:pointer; transition:all .2s; color:var(--text-2); position:relative; text-decoration:none; }
.icon-btn:hover { border-color:var(--border-glow); color:var(--cyan); box-shadow:0 0 20px rgba(0,210,255,.15); }
.notif-dot { position:absolute; top:7px; right:7px; width:7px; height:7px; background:var(--rose); border-radius:50%; border:1.5px solid var(--surface); }

/* ═══ MOBILE TOGGLE ═══ */
.mob-toggle { display:none; position:fixed; top:15px; left:14px; z-index:200; background:var(--surface); border:1px solid var(--border); border-radius:8px; width:38px; height:38px; flex-direction:column; align-items:center; justify-content:center; gap:5px; cursor:pointer; padding:0; }
.mob-toggle span { display:block; width:18px; height:2px; background:var(--text-2); border-radius:2px; transition:all .2s; }
.mob-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,.5); z-index:99; backdrop-filter:blur(2px); }
@media(max-width:768px) {
  .sidebar { transform:translateX(-100%); transition:transform .3s ease; }
  .sidebar.mob-open { transform:translateX(0); }
  .sidebar.mob-open ~ .mob-overlay { display:block; }
  .mob-toggle { display:flex; }
  .main { margin-left:0 !important; }
  .mob-overlay { display:none; }
  .sidebar.mob-open + * + .mob-overlay { display:block; }
}

</style>
</head>
<body>
<div class="app">
  
  <!-- ════════ SIDEBAR ════════ -->
  <aside class="sidebar" id="main-sidebar">
    <div class="sidebar-logo">
      <div class="logo-icon">🧠</div>
      <div>
        <div class="logo-text">StudyAI</div>
        <div class="logo-sub">Pro Plan</div>
      </div>
    </div>

    <nav class="sidebar-nav">
      <div class="nav-section-label">MAIN</div>
      
        <a href="dashboard.php" class="nav-item " style="">
          
          <span class="nav-icon">🏠</span>
          <span class="nav-label">Dashboard</span>
          
        </a>
        <a href="schedule.php" class="nav-item " style="">
          
          <span class="nav-icon">📅</span>
          <span class="nav-label">AI Schedule</span>
          
        </a>
        <a href="tasks.php" class="nav-item " style="">
          
          <span class="nav-icon">✅</span>
          <span class="nav-label">Tasks</span>
          <span class="nav-badge">3</span>
        </a>
        <a href="timer.php" class="nav-item " style="">
          
          <span class="nav-icon">⏱️</span>
          <span class="nav-label">Study Timer</span>
          
        </a>
        <a href="analytics.php" class="nav-item nav-item-active" style="">
          <span class="nav-active-bar"></span>
          <span class="nav-icon">📊</span>
          <span class="nav-label">Analytics</span>
          
        </a>
        <a href="cgpa-planner.php" class="nav-item " style="background:linear-gradient(135deg,rgba(0,210,255,.08),rgba(124,58,237,.08));border-color:rgba(0,210,255,.15);">
          
          <span class="nav-icon">🎓</span>
          <span class="nav-label">CGPA Planner</span>
          
        </a>
      <a href="career-guide.php" class="nav-item"><span class="nav-icon">🚀</span><span class="nav-label">Career Guide</span></a>
      <div class="nav-section-label" style="margin-top:12px">ACCOUNT</div>
      
        <a href="notifications.php" class="nav-item " style="">
          
          <span class="nav-icon">🔔</span>
          <span class="nav-label">Notifications</span>
          <span class="nav-badge">2</span>
        </a>
        <a href="profile-setup.php" class="nav-item " style="">
          
          <span class="nav-icon">👤</span>
          <span class="nav-label">Profile Setup</span>
          
        </a>
    </nav>

    <div class="sidebar-footer">
      <div class="user-card" onclick="handleLogout()" title="Click to logout" id="user-card">
        <div class="avatar" id="user-avatar">ST</div>
        <div>
          <div class="user-name" id="user-name-el">Student</div>
          <div class="user-role" id="user-role-el">Loading...</div>
        </div>
      </div>
    </div>
  </aside>
  <!-- ════════ END SIDEBAR ════════ -->

  <!-- ════════ MOBILE MENU TOGGLE ════════ -->
  <button class="mob-toggle" onclick="document.getElementById('main-sidebar').classList.toggle('mob-open')" title="Menu">
    <span></span><span></span><span></span>
  </button>
  <div class="mob-overlay" onclick="document.getElementById('main-sidebar').classList.remove('mob-open')"></div>

  <div class="main">
    
  <!-- ════════ TOPBAR ════════ -->
  <div class="topbar">
    <div class="topbar-title">Analytics</div>
    <div class="topbar-actions">
      <div class="icon-btn" title="Search" onclick="document.querySelector('.search-input')?.focus()">
        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
        </svg>
      </div>
      <a href="notifications.php" class="icon-btn" title="Notifications" style="text-decoration:none;color:var(--text-2);position:relative">
        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6 6 0 10-12 0v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0a3 3 0 01-6 0"/>
        </svg>
        <span class="notif-dot"></span>
      </a>
      <a href="profile-setup.php" style="text-decoration:none">
        <div class="avatar" style="width:34px;height:34px;font-size:13px;cursor:pointer" id="topbar-avatar">ST</div>
      </a>
    </div>
  </div>
  <!-- ════════ END TOPBAR ════════ -->

    <div class="page">

      <!-- STATS -->
      <div class="grid-4 mb-24 fade-up" id="analytics-stats"></div>

      <!-- CHARTS ROW -->
      <div class="grid-2 mb-24 fade-up-1">
        <div class="card">
          <div class="section-header">
            <div><div class="section-title">Weekly Study Hours</div><div class="section-sub">Hours per day this week</div></div>
          </div>
          <div id="bar-chart" style="display:flex;align-items:flex-end;gap:8px;height:140px;margin-bottom:8px"></div>
          <div style="display:flex;gap:8px" id="bar-labels"></div>
        </div>
        <div class="card">
          <div class="section-header">
            <div><div class="section-title">Productivity Score Trend</div><div class="section-sub">Daily score this week</div></div>
          </div>
          <div id="prod-chart" style="height:110px"></div>
          <div style="display:flex;margin-top:6px" id="prod-labels"></div>
        </div>
      </div>

      <!-- BOTTOM ROW -->
      <div class="grid-2 fade-up-2">
        <div class="card">
          <div class="section-header"><div><div class="section-title">Subject Breakdown</div><div class="section-sub">Time & progress per subject</div></div></div>
          <div id="subject-breakdown"></div>
        </div>
        <div class="card">
          <div class="section-header"><div><div class="section-title">Performance Insights</div></div></div>
          <div id="perf-insights"></div>
        </div>
      </div>

    </div>
  </div>
</div>


<script src="js/api.js"></script>
<script>
/* ── USER INFO ── */
(function(){
  try {
    var u = JSON.parse(sessionStorage.getItem('studyai_user') || '{}');
    var name = u.name || 'Student';
    var role = u.level || u.subject || 'Student';
    var ini  = name.split(' ').map(function(w){return w[0];}).join('').toUpperCase().slice(0,2) || 'ST';
    var el; 
    el = document.getElementById('user-name-el'); if(el) el.textContent = name;
    el = document.getElementById('user-role-el'); if(el) el.textContent = role;
    el = document.getElementById('user-avatar');  if(el) el.textContent = ini;
    el = document.getElementById('topbar-avatar');if(el) el.textContent = ini;
  } catch(e){}
})();

/* ── TOAST ── */
function showToast(msg, type) {
  var colors = {success:'#10b981',error:'#f43f5e',info:'#00d2ff',warn:'#f59e0b'};
  var c = colors[type||'success'] || colors.success;
  var t = document.createElement('div');
  t.style.cssText = 'position:fixed;bottom:24px;right:24px;background:#0d1117;border:1px solid '+c+';color:#f0f4f8;padding:12px 20px;border-radius:12px;font-size:14px;z-index:9999;animation:fadeUp .3s ease;box-shadow:0 8px 30px rgba(0,0,0,.5);max-width:340px;border-left:3px solid '+c+';font-family:DM Sans,sans-serif;';
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(function(){ t.style.opacity='0'; t.style.transition='opacity .3s'; setTimeout(function(){t.remove();},300); }, 3000);
}

/* ── DB HELPERS ── */
var DB = {
  get: function(k, def) { try { var v=JSON.parse(localStorage.getItem('sai_'+k)); return v!=null?v:def; } catch(e){ return def!=null?def:[]; } },
  set: function(k, v)   { localStorage.setItem('sai_'+k, JSON.stringify(v)); }
};

/* ── MINI LINE CHART ── */
function renderMiniChart(cid, data, color, height) {
  color = color||'#00d2ff'; height = height||70;
  var el=document.getElementById(cid); if(!el) return;
  var w=el.clientWidth||300, h=height;
  var max=Math.max.apply(null,data), min=Math.min.apply(null,data);
  var pts=data.map(function(v,i){
    var x=(i/(data.length-1))*w;
    var y=h-((v-min)/(max-min||1))*(h-10)-5;
    return x+','+y;
  }).join(' ');
  var dots=data.map(function(v,i){
    var x=(i/(data.length-1))*w, y=h-((v-min)/(max-min||1))*(h-10)-5;
    return '<circle cx="'+x+'" cy="'+y+'" r="3" fill="'+color+'" style="filter:drop-shadow(0 0 4px '+color+')"/>';
  }).join('');
  el.innerHTML='<svg viewBox="0 0 '+w+' '+h+'" width="100%" height="'+h+'" preserveAspectRatio="none"><defs><linearGradient id="cg'+cid+'" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="'+color+'" stop-opacity="0.3"/><stop offset="100%" stop-color="'+color+'" stop-opacity="0"/></linearGradient></defs><polygon points="0,'+h+' '+pts+' '+w+','+h+'" fill="url(#cg'+cid+')"/><polyline points="'+pts+'" fill="none" stroke="'+color+'" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="filter:drop-shadow(0 0 6px '+color+')"/>'+dots+'</svg>';
}

/* ── DONUT CHART ── */
function renderDonut(cid, value, total, size, c1, c2) {
  total=total||100; size=size||120; c1=c1||'#00d2ff'; c2=c2||'#7c3aed';
  var el=document.getElementById(cid); if(!el) return;
  var r=(size-14)/2, circ=2*Math.PI*r, dash=(value/total)*circ;
  el.innerHTML='<div style="position:relative;width:'+size+'px;height:'+size+'px;display:inline-flex;align-items:center;justify-content:center"><svg width="'+size+'" height="'+size+'" style="transform:rotate(-90deg)"><defs><linearGradient id="dg'+cid+'" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stop-color="'+c1+'"/><stop offset="100%" stop-color="'+c2+'"/></linearGradient></defs><circle cx="'+(size/2)+'" cy="'+(size/2)+'" r="'+r+'" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="10"/><circle cx="'+(size/2)+'" cy="'+(size/2)+'" r="'+r+'" fill="none" stroke="url(#dg'+cid+')" stroke-width="10" stroke-dasharray="'+dash+' '+circ+'" stroke-linecap="round" style="filter:drop-shadow(0 0 8px rgba(0,210,255,0.5));transition:stroke-dasharray 1s ease"/></svg><div style="position:absolute;text-align:center"><div style="font-family:Syne,sans-serif;font-size:22px;font-weight:800">'+value+'%</div><div style="font-size:11px;color:var(--text-2)">done</div></div></div>';
}

/* ── ANIMATE PROGRESS BARS ── */
function animateBars() {
  document.querySelectorAll('.progress-fill[data-pct]').forEach(function(el){
    setTimeout(function(){ el.style.width = el.dataset.pct+'%'; }, 300);
  });
}
document.addEventListener('DOMContentLoaded', animateBars);
</script>


<script>
async function loadAnalytics() {
  await requireAuth();
  const data = await API.getAnalytics();
  if (!data || !data.success) { showToast('Failed to load analytics','error'); return; }

  const weeklyHours = data.weeklyHours || [];
  const todayDay    = new Date().toLocaleDateString('en-US',{weekday:'short'});
  const weekHrs     = weeklyHours.map(d=>d.hours||0);
  const totalWeek   = weekHrs.reduce((a,b)=>a+b,0);
  const avgDaily    = weekHrs.length ? (totalWeek/7).toFixed(1) : 0;
  const streak      = data.streak || 0;
  const totalHours  = data.totalStudyHours || 0;
  const taskStats   = data.taskStats || {};

  // ── STATS ──────────────────────────────────────
  document.getElementById('analytics-stats').innerHTML=[
    { label:'Weekly Hours',    val:totalWeek.toFixed(1)+'h', sub:`Avg ${avgDaily}h/day`, icon:'📈', c:'var(--cyan)'    },
    { label:'Completion Rate', val:(taskStats.completion_rate||0)+'%', sub:`${taskStats.done||0} tasks done`, icon:'✅', c:'var(--emerald)' },
    { label:'Day Streak',      val:streak+'🔥', sub:'Keep it going!', icon:'⭐', c:'var(--amber)'   },
    { label:'Total Study Hrs', val:totalHours+'h', sub:'All time', icon:'📚', c:'var(--violet)' },
  ].map((s,i)=>`
    <div class="stat-card fade-up" style="--accent:${s.c};animation-delay:${i*.1}s">
      <div style="font-size:22px;margin-bottom:8px">${s.icon}</div>
      <div style="font-family:'Syne',sans-serif;font-weight:800;font-size:26px;color:${s.c}">${s.val}</div>
      <div style="font-size:13px;color:var(--text-2)">${s.label}</div>
      <div style="font-size:11px;color:var(--emerald);margin-top:4px">${s.sub}</div>
    </div>`).join('');

  // ── BAR CHART (weekly hours) ────────────────────
  const maxH = Math.max(...weekHrs, 1);
  document.getElementById('bar-chart').innerHTML = weeklyHours.map((d,i)=>`
    <div style="flex:1;display:flex;flex-direction:column;align-items:center;gap:6px;height:100%;justify-content:flex-end">
      <span style="font-size:11px;color:${d.day===todayDay?'var(--cyan)':'var(--violet)'};font-weight:600">${d.hours}h</span>
      <div style="width:100%;height:${Math.max((d.hours/maxH)*100,3)}%;border-radius:6px 6px 0 0;
        background:${d.day===todayDay?'linear-gradient(180deg,var(--cyan),rgba(0,210,255,.3))':'linear-gradient(180deg,rgba(124,58,237,.8),rgba(124,58,237,.2))'};
        transition:height 1s ease;box-shadow:${d.day===todayDay?'0 0 12px rgba(0,210,255,.3)':'none'};min-height:4px"></div>
    </div>`).join('');
  document.getElementById('bar-labels').innerHTML=weeklyHours.map(d=>`<div style="flex:1;text-align:center;font-size:11px;color:${d.day===todayDay?'var(--cyan)':'var(--text-3)'}">${d.day}</div>`).join('');

  // ── PRODUCTIVITY TREND CHART ───────────────────
  const prodTrend = (data.productivityTrend||[]).map(w=>w.hours||0);
  const prodLabels= (data.productivityTrend||[]).map(w=>w.week||'');
  setTimeout(()=>{
    if(prodTrend.length) renderMiniChart('prod-chart', prodTrend.length>1?prodTrend:[0,...prodTrend], 'var(--emerald)', 100);
    const labEl=document.getElementById('prod-labels');
    if(labEl) labEl.innerHTML=prodLabels.map(d=>`<div style="flex:1;text-align:center;font-size:11px;color:var(--text-3)">${d}</div>`).join('');
  },100);

  // ── SUBJECT BREAKDOWN ──────────────────────────
  const subColors = ['var(--emerald)','var(--cyan)','var(--amber)','var(--violet)','#ec4899'];
  const subBreak  = data.subjectBreakdown || [];
  const maxMins   = subBreak.length ? Math.max(...subBreak.map(s=>s.total_mins||0), 1) : 1;
  document.getElementById('subject-breakdown').innerHTML = subBreak.length ? subBreak.map((s,i)=>{
    const hrs = (s.total_mins/60).toFixed(1);
    const pct = Math.round((s.total_mins/maxMins)*100);
    const c   = subColors[i%subColors.length];
    return `<div style="margin-bottom:16px">
      <div style="display:flex;justify-content:space-between;margin-bottom:6px">
        <span style="font-size:14px;font-weight:500">${s.subject}</span>
        <span style="font-size:13px;color:var(--text-2)">${hrs}h · <span style="color:${c};font-weight:600">${pct}%</span></span>
      </div>
      <div style="height:8px;background:var(--surface2);border-radius:20px;overflow:hidden">
        <div style="height:100%;width:${pct}%;border-radius:20px;background:${c};box-shadow:0 0 10px ${c}55;transition:width 1.2s ease"></div>
      </div>
    </div>`;
  }).join('') : '<div style="color:var(--text-2);font-size:13px;text-align:center;padding:20px">No study sessions yet. Use the Timer to track sessions!</div>';

  // ── PERFORMANCE INSIGHTS ───────────────────────
  const bestSub = subBreak.length ? subBreak[0].subject : 'N/A';
  const weakSub = subBreak.length>1 ? subBreak[subBreak.length-1].subject : 'N/A';
  document.getElementById('perf-insights').innerHTML=[
    { lbl:'Best Subject',     val: bestSub,              icon:'🏆', c:'var(--amber)'   },
    { lbl:'Needs Attention',  val: weakSub,              icon:'⚠️', c:'var(--rose)'    },
    { lbl:'Current Streak',   val: streak+' Days',       icon:'🔥', c:'var(--emerald)' },
    { lbl:'Tasks Completed',  val: taskStats.done||0,    icon:'✅', c:'var(--cyan)'    },
    { lbl:'Schedule Done',    val: (data.scheduleCompletion||0)+'%', icon:'🗓️', c:'var(--violet)' },
    { lbl:'Total Study Time', val: totalHours+'h',       icon:'📚', c:'var(--emerald)' },
  ].map(i=>`
    <div style="display:flex;align-items:center;gap:12px;padding:10px 14px;background:var(--surface2);border-radius:10px;border:1px solid var(--border);margin-bottom:8px">
      <span style="font-size:18px">${i.icon}</span>
      <span style="font-size:13px;color:var(--text-2);flex:1">${i.lbl}</span>
      <span style="font-family:'Syne',sans-serif;font-weight:700;font-size:14px;color:${i.c}">${i.val}</span>
    </div>`).join('');

  // ── DONUT ──────────────────────────────────────
  setTimeout(()=>renderDonut('week-donut', taskStats.completion_rate||0), 300);
}

loadAnalytics();
</script>
</body>
</html>
