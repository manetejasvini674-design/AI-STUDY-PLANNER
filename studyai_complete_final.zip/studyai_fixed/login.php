<?php
require_once __DIR__ . "/config.php";
startSession();
if (isset($_SESSION["user_id"])) { header("Location: dashboard.php"); exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1.0"/>
  <title>Login – StudyAI</title>
  <style>
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;1,9..40,300&display=swap');

/* ===== RESET & ROOT ===== */
* { margin: 0; padding: 0; box-sizing: border-box; }
:root {
  --bg: #060910;
  --surface: #0d1117;
  --surface2: #111827;
  --border: rgba(255,255,255,0.06);
  --border-glow: rgba(0,210,255,0.2);
  --cyan: #00d2ff;
  --cyan-dim: rgba(0,210,255,0.12);
  --violet: #7c3aed;
  --violet-dim: rgba(124,58,237,0.15);
  --emerald: #10b981;
  --amber: #f59e0b;
  --rose: #f43f5e;
  --text: #f0f4f8;
  --text-2: #8b9db5;
  --text-3: #4a5568;
}
body { background: var(--bg); color: var(--text); font-family: 'DM Sans', sans-serif; overflow-x: hidden; }
::-webkit-scrollbar { width: 4px; }
::-webkit-scrollbar-track { background: var(--surface); }
::-webkit-scrollbar-thumb { background: var(--cyan); border-radius: 4px; }

/* ===== ANIMATIONS ===== */
@keyframes fadeUp    { from { opacity:0; transform:translateY(24px); } to { opacity:1; transform:translateY(0); } }
@keyframes fadeIn    { from { opacity:0; } to { opacity:1; } }
@keyframes float     { 0%,100% { transform:translateY(0); } 50% { transform:translateY(-8px); } }
@keyframes glowPulse { 0%,100% { box-shadow:0 0 20px rgba(0,210,255,.1); } 50% { box-shadow:0 0 40px rgba(0,210,255,.3); } }
@keyframes gradShift { 0%,100% { background-position:0% 50%; } 50% { background-position:100% 50%; } }
@keyframes barGrow   { from { width:0; } to { width:var(--w); } }
@keyframes countUp   { from { opacity:0; transform:scale(.7); } to { opacity:1; transform:scale(1); } }
@keyframes slideIn   { from { opacity:0; transform:translateX(-20px); } to { opacity:1; transform:translateX(0); } }
@keyframes bounce    { 0%,80%,100% { transform:scale(.6); opacity:.5; } 40% { transform:scale(1); opacity:1; } }
@keyframes spin      { from { transform:rotate(0deg); } to { transform:rotate(360deg); } }
@keyframes orbit     { from { transform:rotate(0deg) translateX(60px) rotate(0deg); } to { transform:rotate(360deg) translateX(60px) rotate(-360deg); } }

.fade-up   { animation: fadeUp .6s ease forwards; }
.fade-up-1 { animation: fadeUp .6s .1s ease forwards; opacity:0; }
.fade-up-2 { animation: fadeUp .6s .2s ease forwards; opacity:0; }
.fade-up-3 { animation: fadeUp .6s .3s ease forwards; opacity:0; }
.fade-up-4 { animation: fadeUp .6s .4s ease forwards; opacity:0; }
.slide-in  { animation: slideIn .5s ease forwards; }

/* ===== LAYOUT ===== */
.app { display:flex; min-height:100vh; }

/* ===== SIDEBAR ===== */
.sidebar {
  width:240px; min-height:100vh; background:var(--surface);
  border-right:1px solid var(--border); display:flex; flex-direction:column;
  position:fixed; left:0; top:0; bottom:0; z-index:100;
}
.sidebar-logo {
  padding:28px 24px; border-bottom:1px solid var(--border);
  display:flex; align-items:center; gap:12px;
}
.logo-icon {
  width:38px; height:38px; background:linear-gradient(135deg,var(--cyan),var(--violet));
  border-radius:10px; display:flex; align-items:center; justify-content:center;
  font-size:18px; animation:float 3s ease-in-out infinite; flex-shrink:0;
}
.logo-text {
  font-family:'Syne',sans-serif; font-weight:800; font-size:16px;
  background:linear-gradient(90deg,var(--cyan),var(--violet));
  -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text;
}
.logo-sub { font-size:10px; color:var(--text-3); margin-top:1px; }
.sidebar-nav { flex:1; padding:16px 12px; display:flex; flex-direction:column; gap:4px; overflow-y:auto; }
.nav-section-label {
  font-size:10px; font-weight:600; letter-spacing:.12em;
  color:var(--text-3); padding:12px 12px 6px; text-transform:uppercase;
}
.nav-item {
  display:flex; align-items:center; gap:10px; padding:10px 12px;
  border-radius:10px; cursor:pointer; transition:all .2s;
  color:var(--text-2); font-size:14px; font-weight:400; position:relative;
  border:1px solid transparent; text-decoration:none;
}
.nav-item:hover { background:var(--cyan-dim); color:var(--text); border-color:var(--border-glow); }
.nav-item.active {
  background:linear-gradient(135deg,rgba(0,210,255,.15),rgba(124,58,237,.1));
  color:var(--cyan); border-color:rgba(0,210,255,.25);
  box-shadow:inset 0 0 20px rgba(0,210,255,.05);
}
.nav-item.active::before {
  content:''; position:absolute; left:0; top:50%; transform:translateY(-50%);
  width:3px; height:60%; background:var(--cyan); border-radius:0 2px 2px 0;
}
.nav-icon { width:18px; height:18px; flex-shrink:0; display:flex; align-items:center; justify-content:center; }
.nav-badge {
  margin-left:auto; background:var(--rose); color:#fff;
  font-size:10px; font-weight:700; padding:2px 7px; border-radius:20px;
}
.sidebar-footer { padding:16px 12px; border-top:1px solid var(--border); }
.user-card {
  display:flex; align-items:center; gap:10px; padding:10px 12px;
  background:var(--surface2); border-radius:10px; border:1px solid var(--border); cursor:pointer; transition:all .2s;
}
.user-card:hover { border-color:var(--border-glow); }
.avatar {
  width:34px; height:34px; border-radius:50%;
  background:linear-gradient(135deg,var(--cyan),var(--violet));
  display:flex; align-items:center; justify-content:center;
  font-weight:700; font-size:14px; color:#fff; flex-shrink:0;
}
.avatar-lg { width:50px; height:50px; font-size:18px; }
.user-name  { font-size:13px; font-weight:500; color:var(--text); }
.user-role  { font-size:11px; color:var(--text-2); }

/* ===== MAIN ===== */
.main { margin-left:240px; flex:1; min-height:100vh; }

/* ===== TOPBAR ===== */
.topbar {
  height:64px; background:rgba(13,17,23,.8); backdrop-filter:blur(20px);
  border-bottom:1px solid var(--border); display:flex; align-items:center;
  padding:0 32px; gap:16px; position:sticky; top:0; z-index:50;
}
.topbar-title { font-family:'Syne',sans-serif; font-weight:700; font-size:18px; flex:1; }
.topbar-actions { display:flex; align-items:center; gap:10px; }
.icon-btn {
  width:38px; height:38px; border-radius:10px; border:1px solid var(--border);
  background:var(--surface2); display:flex; align-items:center; justify-content:center;
  cursor:pointer; transition:all .2s; color:var(--text-2); position:relative;
}
.icon-btn:hover { border-color:var(--border-glow); color:var(--cyan); box-shadow:0 0 20px rgba(0,210,255,.15); }
.notif-dot {
  position:absolute; top:7px; right:7px; width:7px; height:7px;
  background:var(--rose); border-radius:50%; border:1.5px solid var(--surface);
}

/* ===== PAGE ===== */
.page { padding:32px; animation:fadeIn .4s ease; }

/* ===== CARDS ===== */
.card {
  background:var(--surface); border:1px solid var(--border); border-radius:16px;
  padding:24px; transition:all .3s;
}
.card:hover { border-color:rgba(0,210,255,.15); box-shadow:0 4px 30px rgba(0,0,0,.3); }

/* ===== STAT CARD ===== */
.stat-card {
  background:var(--surface); border:1px solid var(--border); border-radius:16px;
  padding:22px; position:relative; overflow:hidden; transition:all .3s;
}
.stat-card::after {
  content:''; position:absolute; bottom:0; left:0; right:0; height:2px;
  background:var(--accent,var(--cyan)); transform:scaleX(0); transition:transform .3s; transform-origin:left;
}
.stat-card:hover::after { transform:scaleX(1); }
.stat-card:hover { border-color:var(--border-glow); transform:translateY(-2px); }
.stat-icon { width:42px; height:42px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:20px; margin-bottom:14px; }
.stat-value { font-family:'Syne',sans-serif; font-weight:800; font-size:28px; line-height:1; animation:countUp .5s ease; }
.stat-label { font-size:13px; color:var(--text-2); margin-top:4px; }
.stat-change { font-size:12px; margin-top:8px; display:flex; align-items:center; gap:4px; }
.stat-up   { color:var(--emerald); }
.stat-down { color:var(--rose); }

/* ===== SECTION HEADER ===== */
.section-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:20px; }
.section-title { font-family:'Syne',sans-serif; font-weight:700; font-size:18px; }
.section-sub   { font-size:13px; color:var(--text-2); margin-top:2px; }

/* ===== BUTTONS ===== */
.btn-primary {
  background:linear-gradient(135deg,var(--cyan),var(--violet));
  border:none; color:#fff; padding:10px 20px; border-radius:10px;
  cursor:pointer; font-size:14px; font-weight:500; font-family:'DM Sans',sans-serif;
  transition:all .2s; box-shadow:0 4px 15px rgba(0,210,255,.2); display:inline-flex; align-items:center; gap:6px;
}
.btn-primary:hover { transform:translateY(-1px); box-shadow:0 6px 25px rgba(0,210,255,.35); }
.btn-secondary {
  background:var(--surface2); border:1px solid var(--border); color:var(--text);
  padding:10px 20px; border-radius:10px; cursor:pointer; font-size:14px;
  font-family:'DM Sans',sans-serif; transition:all .2s; display:inline-flex; align-items:center; gap:6px;
}
.btn-secondary:hover { border-color:var(--border-glow); color:var(--cyan); }
.btn-ghost {
  background:none; border:1px solid var(--border); color:var(--text-2);
  padding:8px 16px; border-radius:8px; cursor:pointer; font-size:13px;
  font-family:'DM Sans',sans-serif; transition:all .2s; display:inline-flex; align-items:center; gap:6px;
}
.btn-ghost:hover { border-color:var(--border-glow); color:var(--cyan); }
.btn-hero {
  padding:14px 32px; border-radius:12px; font-size:15px; font-weight:600;
  cursor:pointer; font-family:'DM Sans',sans-serif; transition:all .3s;
}
.btn-hero-primary {
  background:linear-gradient(135deg,var(--cyan),var(--violet));
  border:none; color:#fff; box-shadow:0 8px 30px rgba(0,210,255,.3);
}
.btn-hero-primary:hover { transform:translateY(-2px); box-shadow:0 12px 40px rgba(0,210,255,.45); }
.btn-hero-secondary { background:transparent; border:1px solid var(--border); color:var(--text); }
.btn-hero-secondary:hover { border-color:var(--border-glow); color:var(--cyan); }
.btn-sm { padding:6px 14px; font-size:12px; border-radius:8px; }
.btn-icon {
  width:38px; height:38px; padding:0; border-radius:10px;
  display:inline-flex; align-items:center; justify-content:center;
}

/* ===== FORMS ===== */
.form-group { margin-bottom:16px; }
.input-label { font-size:13px; color:var(--text-2); margin-bottom:6px; display:block; }
.input-field {
  width:100%; background:var(--surface2); border:1px solid var(--border);
  border-radius:10px; padding:10px 14px; color:var(--text); font-size:14px;
  font-family:'DM Sans',sans-serif; transition:all .2s; outline:none;
}
.input-field:focus { border-color:var(--border-glow); box-shadow:0 0 0 3px rgba(0,210,255,.08); }
.input-field::placeholder { color:var(--text-3); }
.select-field {
  width:100%; background:var(--surface2); border:1px solid var(--border);
  border-radius:10px; padding:10px 14px; color:var(--text); font-size:14px;
  font-family:'DM Sans',sans-serif; transition:all .2s; outline:none; appearance:none; cursor:pointer;
}
.select-field:focus { border-color:var(--border-glow); }
select option { background:var(--surface2); color:var(--text); }

/* ===== PROGRESS ===== */
.progress-wrap   { margin-bottom:14px; }
.progress-header { display:flex; justify-content:space-between; margin-bottom:6px; font-size:13px; }
.progress-track  { height:6px; background:var(--surface2); border-radius:20px; overflow:hidden; }
.progress-fill {
  height:100%; border-radius:20px; transition:width 1.2s ease;
  background:linear-gradient(90deg, var(--pfrom, var(--cyan)), var(--pto, var(--violet)));
}

/* ===== GRIDS ===== */
.grid-4 { display:grid; grid-template-columns:repeat(4,1fr); gap:16px; }
.grid-3 { display:grid; grid-template-columns:repeat(3,1fr); gap:16px; }
.grid-2 { display:grid; grid-template-columns:repeat(2,1fr); gap:20px; }
.grid-13 { display:grid; grid-template-columns:1fr 3fr; gap:20px; }
.grid-31 { display:grid; grid-template-columns:3fr 1fr; gap:20px; }

/* ===== TAGS ===== */
.tag { display:inline-flex; align-items:center; gap:4px; padding:4px 10px; border-radius:6px; font-size:12px; font-weight:500; }

/* ===== TASK ITEM ===== */
.task-item {
  display:flex; align-items:center; gap:12px; padding:14px 16px;
  background:var(--surface2); border-radius:10px; border:1px solid var(--border);
  margin-bottom:8px; transition:all .2s; cursor:pointer;
}
.task-item:hover { border-color:var(--border-glow); background:rgba(0,210,255,.03); }
.task-check {
  width:20px; height:20px; border-radius:6px; border:2px solid var(--border-glow);
  display:flex; align-items:center; justify-content:center; flex-shrink:0; transition:all .2s;
}
.task-check.done { background:var(--emerald); border-color:var(--emerald); }
.task-name     { font-size:14px; font-weight:500; }
.task-name.done { text-decoration:line-through; color:var(--text-2); }
.task-meta     { font-size:12px; color:var(--text-2); margin-top:2px; }

/* ===== NOTIFICATIONS ===== */
.notif-item {
  display:flex; gap:12px; padding:14px 16px; border-radius:10px;
  border:1px solid var(--border); background:var(--surface2); margin-bottom:8px; transition:all .2s;
}
.notif-item:hover { border-color:var(--border-glow); }
.notif-item.unread { border-left:3px solid var(--cyan); }
.notif-dot-ui { width:38px; height:38px; border-radius:10px; flex-shrink:0; display:flex; align-items:center; justify-content:center; font-size:18px; }

/* ===== SCHEDULE ===== */
.schedule-block {
  border-radius:8px; padding:8px 12px; margin-bottom:4px; font-size:13px;
  font-weight:500; border-left:3px solid; transition:all .2s; cursor:pointer;
}
.schedule-block:hover { transform:translateX(3px); }

/* ===== AI THINKING ===== */
.ai-thinking { display:flex; gap:4px; align-items:center; }
.ai-dot { width:8px; height:8px; border-radius:50%; background:var(--cyan); animation:bounce 1.2s ease-in-out infinite; }
.ai-dot:nth-child(2) { animation-delay:.2s; background:var(--violet); }
.ai-dot:nth-child(3) { animation-delay:.4s; background:#ff6b9d; }

/* ===== KANBAN ===== */
.kanban-col {
  background:var(--surface); border:1px solid var(--border); border-radius:16px;
  padding:20px; min-height:400px;
}
.kanban-card {
  background:var(--surface2); border:1px solid var(--border); border-radius:12px;
  padding:14px; margin-bottom:8px; transition:all .2s; cursor:pointer;
}
.kanban-card:hover { border-color:rgba(0,210,255,.2); transform:translateY(-1px); box-shadow:0 4px 20px rgba(0,0,0,.3); }

/* ===== LANDING ===== */
.landing-nav {
  position:fixed; top:0; left:0; right:0; z-index:200;
  padding:16px 48px; display:flex; align-items:center; justify-content:space-between;
  background:rgba(6,9,16,.85); backdrop-filter:blur(20px);
  border-bottom:1px solid var(--border);
}
.landing-nav-link { font-size:14px; color:var(--text-2); cursor:pointer; transition:color .2s; text-decoration:none; }
.landing-nav-link:hover { color:var(--text); }
.hero { min-height:100vh; display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center; padding:40px; position:relative; overflow:hidden; }
.hero-bg { position:absolute; inset:0; overflow:hidden; z-index:0; }
.orb { position:absolute; border-radius:50%; filter:blur(80px); opacity:.15; }
.orb1 { width:600px; height:600px; background:var(--cyan); top:-200px; left:-200px; }
.orb2 { width:500px; height:500px; background:var(--violet); bottom:-150px; right:-150px; }
.orb3 { width:300px; height:300px; background:var(--emerald); bottom:100px; left:200px; animation:float 6s ease-in-out infinite; }
.hero-content { position:relative; z-index:1; max-width:800px; }
.hero-badge {
  display:inline-flex; align-items:center; gap:8px; padding:8px 16px;
  background:rgba(0,210,255,.1); border:1px solid rgba(0,210,255,.25);
  border-radius:20px; font-size:13px; color:var(--cyan); margin-bottom:32px;
  animation:glowPulse 2s ease-in-out infinite;
}
.hero-title { font-family:'Syne',sans-serif; font-weight:800; font-size:64px; line-height:1.05; margin-bottom:20px; letter-spacing:-2px; }
.gradient-text {
  background:linear-gradient(135deg,var(--cyan),var(--violet),#ff6b9d);
  background-size:200% auto; -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text;
  animation:gradShift 3s ease infinite;
}
.hero-sub { font-size:18px; color:var(--text-2); line-height:1.6; margin-bottom:40px; max-width:560px; margin-left:auto; margin-right:auto; }
.features-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:20px; margin-top:80px; text-align:left; }
.feature-card {
  background:rgba(13,17,23,.7); backdrop-filter:blur(20px); border:1px solid var(--border);
  border-radius:16px; padding:24px; transition:all .3s;
}
.feature-card:hover { border-color:var(--border-glow); transform:translateY(-4px); box-shadow:0 20px 40px rgba(0,0,0,.4); }
.feature-icon  { font-size:28px; margin-bottom:14px; }
.feature-title { font-family:'Syne',sans-serif; font-weight:700; font-size:16px; margin-bottom:8px; }
.feature-desc  { font-size:13px; color:var(--text-2); line-height:1.6; }

/* ===== AUTH ===== */
.auth-wrap { min-height:100vh; display:flex; align-items:center; justify-content:center; background:var(--bg); position:relative; overflow:hidden; }
.auth-card {
  background:var(--surface); border:1px solid var(--border); border-radius:20px;
  padding:40px; width:420px; position:relative; z-index:1; animation:fadeUp .5s ease;
}
.auth-title { font-family:'Syne',sans-serif; font-weight:800; font-size:28px; margin-bottom:8px; }
.auth-sub   { font-size:14px; color:var(--text-2); margin-bottom:32px; }
.auth-divider { display:flex; align-items:center; gap:12px; margin:20px 0; color:var(--text-3); font-size:12px; }
.auth-divider::before,.auth-divider::after { content:''; flex:1; height:1px; background:var(--border); }
.auth-link { color:var(--cyan); text-decoration:none; font-size:14px; }
.auth-link:hover { text-decoration:underline; }

/* ===== DASHBOARD PREVIEW (login page) ===== */
.dashboard-preview {
  background:var(--surface2); border:1px solid var(--border); border-radius:16px;
  padding:20px; cursor:pointer; transition:all .3s; position:relative; overflow:hidden;
  margin-top:20px;
}
.dashboard-preview::before {
  content:''; position:absolute; inset:0;
  background:linear-gradient(135deg,rgba(0,210,255,.05),rgba(124,58,237,.05));
  opacity:0; transition:opacity .3s;
}
.dashboard-preview:hover { border-color:var(--border-glow); transform:translateY(-3px); box-shadow:0 10px 40px rgba(0,210,255,.1); }
.dashboard-preview:hover::before { opacity:1; }
.preview-badge {
  display:inline-flex; align-items:center; gap:6px; padding:6px 12px;
  background:rgba(0,210,255,.1); border:1px solid rgba(0,210,255,.2);
  border-radius:20px; font-size:12px; color:var(--cyan); margin-bottom:12px;
}
.preview-mini-stat {
  background:var(--surface); border:1px solid var(--border); border-radius:10px;
  padding:12px; text-align:center;
}
.preview-mini-val { font-family:'Syne',sans-serif; font-weight:800; font-size:20px; }
.preview-mini-lbl { font-size:11px; color:var(--text-2); margin-top:2px; }
.preview-bar { height:5px; background:var(--surface); border-radius:20px; overflow:hidden; margin-top:6px; }
.preview-bar-fill { height:100%; border-radius:20px; background:linear-gradient(90deg,var(--cyan),var(--violet)); }

/* ===== TIMER ===== */
.timer-display {
  font-family:'Syne',sans-serif; font-size:72px; font-weight:800;
  background:linear-gradient(135deg,var(--cyan),var(--violet));
  -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text;
  letter-spacing:-2px; line-height:1;
}

/* ===== CGPA TOOL ===== */
.cgpa-card {
  background:var(--surface); border:1px solid var(--border); border-radius:16px;
  padding:28px; transition:all .3s;
}
.cgpa-result {
  background:linear-gradient(135deg,rgba(0,210,255,.08),rgba(124,58,237,.08));
  border:1px solid rgba(0,210,255,.2); border-radius:14px; padding:24px;
  animation:fadeUp .5s ease;
}
.cgpa-big { font-family:'Syne',sans-serif; font-weight:800; font-size:48px; background:linear-gradient(135deg,var(--cyan),var(--violet)); -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text; }
.subject-row { display:grid; grid-template-columns:2fr 1fr 1fr 38px; gap:10px; align-items:center; margin-bottom:10px; }
.subject-row-header { display:grid; grid-template-columns:2fr 1fr 1fr 38px; gap:10px; align-items:center; margin-bottom:8px; font-size:12px; color:var(--text-3); font-weight:600; letter-spacing:.05em; text-transform:uppercase; }
.remove-btn {
  width:34px; height:34px; border-radius:8px; background:rgba(244,63,94,.1); border:1px solid rgba(244,63,94,.2);
  color:var(--rose); cursor:pointer; display:flex; align-items:center; justify-content:center;
  transition:all .2s; font-size:16px; flex-shrink:0;
}
.remove-btn:hover { background:rgba(244,63,94,.2); }
.plan-item {
  display:flex; gap:14px; padding:14px 16px; background:var(--surface2); border:1px solid var(--border);
  border-radius:12px; margin-bottom:10px; animation:slideIn .4s ease;
}
.plan-item-icon { width:40px; height:40px; border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:18px; flex-shrink:0; }

/* ===== TOOLTIP ===== */
.tooltip-wrap { position:relative; }
.tooltip {
  position:absolute; bottom:calc(100% + 8px); left:50%; transform:translateX(-50%);
  background:var(--surface2); border:1px solid var(--border); border-radius:8px;
  padding:6px 10px; font-size:12px; white-space:nowrap; pointer-events:none; opacity:0; transition:opacity .2s; z-index:99;
}
.tooltip-wrap:hover .tooltip { opacity:1; }

/* ===== STEP INDICATOR ===== */
.step-bar { display:flex; gap:8px; margin-bottom:24px; }
.step-seg { flex:1; height:3px; border-radius:4px; transition:all .3s; }
.step-seg.active { background:linear-gradient(90deg,var(--cyan),var(--violet)); box-shadow:0 0 10px rgba(0,210,255,.3); }
.step-seg.inactive { background:var(--border); }

/* ===== MISC ===== */
.divider { height:1px; background:var(--border); margin:20px 0; }
.badge { display:inline-flex; align-items:center; padding:3px 10px; border-radius:20px; font-size:12px; font-weight:600; }
.glow-cyan { box-shadow:0 0 20px rgba(0,210,255,.2); }
.glow-violet { box-shadow:0 0 20px rgba(124,58,237,.2); }
.text-cyan { color:var(--cyan); }
.text-violet { color:var(--violet); }
.text-emerald { color:var(--emerald); }
.text-amber { color:var(--amber); }
.text-rose { color:var(--rose); }
.text-muted { color:var(--text-2); }
.fw-bold { font-weight:700; }
.fw-800 { font-family:'Syne',sans-serif; font-weight:800; }
.mt-8  { margin-top:8px; }
.mt-16 { margin-top:16px; }
.mt-24 { margin-top:24px; }
.mb-8  { margin-bottom:8px; }
.mb-16 { margin-bottom:16px; }
.mb-24 { margin-bottom:24px; }
.flex  { display:flex; }
.flex-center { display:flex; align-items:center; }
.flex-between { display:flex; align-items:center; justify-content:space-between; }
.flex-col { display:flex; flex-direction:column; }
.gap-8  { gap:8px; }
.gap-12 { gap:12px; }
.gap-16 { gap:16px; }
.gap-24 { gap:24px; }
.w-full { width:100%; }
.text-center { text-align:center; }

/* ===== MINI CHART SVG ===== */
.chart-svg { width:100%; overflow:visible; }

</style>
  <style>
    .login-layout { display:grid; grid-template-columns:1fr 1fr; min-height:100vh; }
    .login-left {
      display:flex; align-items:center; justify-content:center; padding:48px;
      position:relative; overflow:hidden;
    }
    .login-right {
      background:var(--surface); border-left:1px solid var(--border);
      display:flex; flex-direction:column; padding:48px; overflow-y:auto;
    }
    .preview-stats { display:grid; grid-template-columns:1fr 1fr; gap:10px; margin-bottom:14px; }
    .preview-progress { margin-bottom:14px; }
    .glance-arrow {
      display:flex; align-items:center; justify-content:center; gap:8px;
      font-size:13px; color:var(--cyan); margin-top:12px;
      animation:float 2s ease-in-out infinite;
    }
  </style>
</head>
<body>
<div class="login-layout">

  <!-- LEFT: AUTH FORM -->
  <div class="login-left">
    <div class="orb orb1" style="opacity:.08"></div>
    <div class="orb orb2" style="opacity:.08"></div>

    <div class="auth-card" style="width:100%;max-width:400px">
      <a href="index.php" style="display:flex;align-items:center;gap:10px;text-decoration:none;margin-bottom:28px">
        <div class="logo-icon" style="width:32px;height:32px;font-size:16px">🧠</div>
        <span class="logo-text">StudyAI</span>
      </a>

      <div class="auth-title">Welcome back 👋</div>
      <div class="auth-sub">Log in to continue your learning journey.</div>

      <form onsubmit="handleLogin(event)">
        <div class="form-group">
          <label class="input-label">Email Address</label>
          <input id="email" type="email" class="input-field" placeholder="you@example.com" required/>
        </div>
        <div class="form-group">
          <label class="input-label" style="display:flex;justify-content:space-between">
            <span>Password</span>
            <a href="#" class="auth-link" style="font-size:12px">Forgot password?</a>
          </label>
          <input id="password" type="password" class="input-field" placeholder="••••••••" required/>
        </div>

        <div style="display:flex;align-items:center;gap:8px;margin-bottom:20px">
          <input type="checkbox" id="remember" style="accent-color:var(--cyan)"/>
          <label for="remember" style="font-size:13px;color:var(--text-2)">Remember me</label>
        </div>

        <button type="submit" class="btn-primary w-full" style="width:100%;justify-content:center;padding:12px">
          Log In →
        </button>
      </form>

      <div class="auth-divider">or</div>

      <button onclick="demoLogin()" class="btn-secondary w-full" style="width:100%;justify-content:center;padding:12px">
        🚀 Try Demo Account
      </button>

      <p style="text-align:center;margin-top:20px;font-size:14px;color:var(--text-2)">
        Don't have an account? <a href="register.php" class="auth-link">Sign up free</a>
      </p>
    </div>
  </div>

  <!-- RIGHT: DASHBOARD PREVIEW -->
  <div class="login-right">
    <div style="margin-bottom:24px">
      <div style="font-family:'Syne',sans-serif;font-weight:800;font-size:22px;margin-bottom:6px">Your Study Command Center</div>
      <div style="color:var(--text-2);font-size:14px">Click to explore your personalized dashboard →</div>
    </div>

    <!-- CLICKABLE DASHBOARD PREVIEW -->
    <div class="dashboard-preview" onclick="goToDashboard()" id="dash-preview">
      <div class="preview-badge">
        <span style="animation:spin 3s linear infinite;display:inline-block">✦</span>
        Live Dashboard Preview
        <span style="margin-left:4px">→</span>
      </div>

      <div style="font-family:'Syne',sans-serif;font-weight:700;font-size:16px;margin-bottom:16px">
        📊 Today's Overview
      </div>

      <!-- MINI STATS -->
      <div class="preview-stats">
        <div class="preview-mini-stat">
          <div class="preview-mini-val text-cyan">6.5h</div>
          <div class="preview-mini-lbl">Study Hours</div>
        </div>
        <div class="preview-mini-stat">
          <div class="preview-mini-val text-emerald">12/15</div>
          <div class="preview-mini-lbl">Tasks Done</div>
        </div>
        <div class="preview-mini-stat">
          <div class="preview-mini-val" style="color:var(--violet)">87%</div>
          <div class="preview-mini-lbl">Productivity</div>
        </div>
        <div class="preview-mini-stat">
          <div class="preview-mini-val text-amber">14d</div>
          <div class="preview-mini-lbl">Next Exam</div>
        </div>
      </div>

      <!-- SUBJECT PROGRESS -->
      <div style="font-size:13px;font-weight:600;margin-bottom:12px;color:var(--text-2)">Subject Progress</div>
      <div class="preview-progress">
        <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:5px"><span>Mathematics</span><span class="text-emerald">88%</span></div>
        <div class="preview-bar"><div class="preview-bar-fill" id="pb1" style="width:0%"></div></div>
      </div>
      <div class="preview-progress">
        <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:5px"><span>Physics</span><span class="text-cyan">72%</span></div>
        <div class="preview-bar"><div class="preview-bar-fill" id="pb2" style="width:0%;background:linear-gradient(90deg,var(--cyan),var(--violet))"></div></div>
      </div>
      <div class="preview-progress">
        <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:5px"><span>Chemistry</span><span class="text-amber">55%</span></div>
        <div class="preview-bar"><div class="preview-bar-fill" id="pb3" style="width:0%;background:linear-gradient(90deg,var(--amber),var(--rose))"></div></div>
      </div>

      <!-- TASKS PREVIEW -->
      <div style="font-size:13px;font-weight:600;margin-bottom:10px;margin-top:16px;color:var(--text-2)">Upcoming Tasks</div>
      <div id="tasks-preview"></div>

      <!-- CLICK CTA -->
      <div class="glance-arrow">
        <span>Click to open full dashboard</span>
        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5l7 7-7 7"/></svg>
      </div>
    </div>

    <!-- EXTRA CARDS -->
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:16px">
      <div class="dashboard-preview" onclick="window.location='cgpa-planner.php'" style="padding:16px">
        <div style="font-size:24px;margin-bottom:8px">🎓</div>
        <div style="font-family:'Syne',sans-serif;font-weight:700;font-size:14px;margin-bottom:4px">CGPA Planner</div>
        <div style="font-size:12px;color:var(--text-2)">Boost your semester pointer with AI</div>
      </div>
      <div class="dashboard-preview" onclick="window.location='schedule.php'" style="padding:16px">
        <div style="font-size:24px;margin-bottom:8px">📅</div>
        <div style="font-family:'Syne',sans-serif;font-weight:700;font-size:14px;margin-bottom:4px">AI Schedule</div>
        <div style="font-size:12px;color:var(--text-2)">Your personalized timetable</div>
      </div>
    </div>
  </div>
</div>


<script src="js/api.js"></script>
<script>
/* ── USER INFO ── */
(function(){
  try {
    var u = JSON.parse(sessionStorage.getItem('studyai_user') || '{}');
    var name = u.name || 'Student';
    var role = u.level || u.subject || 'Student';
    var ini  = name.split(' ').map(function(w){return w[0];}).join('').toUpperCase().slice(0,2) || 'ST';
    var el; 
    el = document.getElementById('user-name-el'); if(el) el.textContent = name;
    el = document.getElementById('user-role-el'); if(el) el.textContent = role;
    el = document.getElementById('user-avatar');  if(el) el.textContent = ini;
    el = document.getElementById('topbar-avatar');if(el) el.textContent = ini;
  } catch(e){}
})();

/* ── TOAST ── */
function showToast(msg, type) {
  var colors = {success:'#10b981',error:'#f43f5e',info:'#00d2ff',warn:'#f59e0b'};
  var c = colors[type||'success'] || colors.success;
  var t = document.createElement('div');
  t.style.cssText = 'position:fixed;bottom:24px;right:24px;background:#0d1117;border:1px solid '+c+';color:#f0f4f8;padding:12px 20px;border-radius:12px;font-size:14px;z-index:9999;animation:fadeUp .3s ease;box-shadow:0 8px 30px rgba(0,0,0,.5);max-width:340px;border-left:3px solid '+c+';font-family:DM Sans,sans-serif;';
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(function(){ t.style.opacity='0'; t.style.transition='opacity .3s'; setTimeout(function(){t.remove();},300); }, 3000);
}

/* ── DB HELPERS ── */
var DB = {
  get: function(k, def) { try { var v=JSON.parse(localStorage.getItem('sai_'+k)); return v!=null?v:def; } catch(e){ return def!=null?def:[]; } },
  set: function(k, v)   { localStorage.setItem('sai_'+k, JSON.stringify(v)); }
};

/* ── MINI LINE CHART ── */
function renderMiniChart(cid, data, color, height) {
  color = color||'#00d2ff'; height = height||70;
  var el=document.getElementById(cid); if(!el) return;
  var w=el.clientWidth||300, h=height;
  var max=Math.max.apply(null,data), min=Math.min.apply(null,data);
  var pts=data.map(function(v,i){
    var x=(i/(data.length-1))*w;
    var y=h-((v-min)/(max-min||1))*(h-10)-5;
    return x+','+y;
  }).join(' ');
  var dots=data.map(function(v,i){
    var x=(i/(data.length-1))*w, y=h-((v-min)/(max-min||1))*(h-10)-5;
    return '<circle cx="'+x+'" cy="'+y+'" r="3" fill="'+color+'" style="filter:drop-shadow(0 0 4px '+color+')"/>';
  }).join('');
  el.innerHTML='<svg viewBox="0 0 '+w+' '+h+'" width="100%" height="'+h+'" preserveAspectRatio="none"><defs><linearGradient id="cg'+cid+'" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="'+color+'" stop-opacity="0.3"/><stop offset="100%" stop-color="'+color+'" stop-opacity="0"/></linearGradient></defs><polygon points="0,'+h+' '+pts+' '+w+','+h+'" fill="url(#cg'+cid+')"/><polyline points="'+pts+'" fill="none" stroke="'+color+'" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="filter:drop-shadow(0 0 6px '+color+')"/>'+dots+'</svg>';
}

/* ── DONUT CHART ── */
function renderDonut(cid, value, total, size, c1, c2) {
  total=total||100; size=size||120; c1=c1||'#00d2ff'; c2=c2||'#7c3aed';
  var el=document.getElementById(cid); if(!el) return;
  var r=(size-14)/2, circ=2*Math.PI*r, dash=(value/total)*circ;
  el.innerHTML='<div style="position:relative;width:'+size+'px;height:'+size+'px;display:inline-flex;align-items:center;justify-content:center"><svg width="'+size+'" height="'+size+'" style="transform:rotate(-90deg)"><defs><linearGradient id="dg'+cid+'" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stop-color="'+c1+'"/><stop offset="100%" stop-color="'+c2+'"/></linearGradient></defs><circle cx="'+(size/2)+'" cy="'+(size/2)+'" r="'+r+'" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="10"/><circle cx="'+(size/2)+'" cy="'+(size/2)+'" r="'+r+'" fill="none" stroke="url(#dg'+cid+')" stroke-width="10" stroke-dasharray="'+dash+' '+circ+'" stroke-linecap="round" style="filter:drop-shadow(0 0 8px rgba(0,210,255,0.5));transition:stroke-dasharray 1s ease"/></svg><div style="position:absolute;text-align:center"><div style="font-family:Syne,sans-serif;font-size:22px;font-weight:800">'+value+'%</div><div style="font-size:11px;color:var(--text-2)">done</div></div></div>';
}

/* ── ANIMATE PROGRESS BARS ── */
function animateBars() {
  document.querySelectorAll('.progress-fill[data-pct]').forEach(function(el){
    setTimeout(function(){ el.style.width = el.dataset.pct+'%'; }, 300);
  });
}
document.addEventListener('DOMContentLoaded', animateBars);
</script>

<script>
  // Animate preview bars on load
  setTimeout(() => {
    document.getElementById('pb1').style.cssText += 'width:88%;transition:width 1.2s ease';
    document.getElementById('pb2').style.cssText += 'width:72%;transition:width 1.2s ease';
    document.getElementById('pb3').style.cssText += 'width:55%;transition:width 1.2s ease';
  }, 400);

  // Preview tasks
  const previewTasks = [
    { name:'Thermodynamics Problem Set', sub:'Physics', time:'2:00 PM', done:false },
    { name:'Integration Practice', sub:'Math', time:'4:00 PM', done:true },
    { name:'Organic Chemistry Review', sub:'Chemistry', time:'6:00 PM', done:false },
  ];
  const tc = document.getElementById('tasks-preview');
  previewTasks.forEach(t => {
    tc.innerHTML += `
      <div style="display:flex;align-items:center;gap:10px;padding:8px 10px;background:var(--surface);border-radius:8px;margin-bottom:6px;border:1px solid var(--border)">
        <div style="width:16px;height:16px;border-radius:4px;border:2px solid ${t.done?'var(--emerald)':'rgba(0,210,255,0.3)'};background:${t.done?'var(--emerald)':'none'};display:flex;align-items:center;justify-content:center;flex-shrink:0">
          ${t.done?'<svg width="10" height="10" fill="none" stroke="white" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="3" d="M5 13l4 4L19 7"/></svg>':''}
        </div>
        <span style="font-size:12px;flex:1;${t.done?'text-decoration:line-through;color:var(--text-2)':''}">${t.name}</span>
        <span style="font-size:11px;color:var(--text-3)">${t.time}</span>
      </div>`;
  });

  function goToDashboard() { window.location.href = 'dashboard.php'; }

  async function handleLogin(e) {
    e.preventDefault();
    const btn = e.target.querySelector('button[type=submit]') || document.querySelector('.btn-primary');
    const email    = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    if (!email || !password) { showToast('Please enter email and password', 'error'); return; }
    if (btn) { btn.disabled = true; btn.textContent = 'Signing in...'; }
    const res = await API.login({ email, password });
    if (btn) { btn.disabled = false; btn.textContent = 'Sign In →'; }
    if (res && res.success) {
      sessionStorage.setItem('studyai_user', JSON.stringify(res.user));
      showToast('Welcome back! Loading dashboard...', 'success');
      setTimeout(() => window.location.href = 'dashboard.php', 900);
    } else {
      showToast(res?.error || 'Login failed', 'error');
    }
  }

  async function demoLogin() {
    const res = await API.login({ email: 'demo@studyai.com', password: 'password' });
    if (res && res.success) {
      sessionStorage.setItem('studyai_user', JSON.stringify(res.user));
      showToast('Demo account loaded!', 'info');
      setTimeout(() => window.location.href = 'dashboard.php', 800);
    } else {
      showToast('Demo login failed. Please register a new account.', 'warn');
    }
  }
</script>
</body>
</html>
