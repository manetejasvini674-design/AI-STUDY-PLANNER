<?php
require_once __DIR__ . "/config.php";
startSession();
if (!isset($_SESSION["user_id"])) { header("Location: login.php"); exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1.0"/>
  <title>CGPA Planner – StudyAI</title>
  <style>
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;1,9..40,300&display=swap');

/* ===== RESET & ROOT ===== */
* { margin: 0; padding: 0; box-sizing: border-box; }
:root {
  --bg: #060910;
  --surface: #0d1117;
  --surface2: #111827;
  --border: rgba(255,255,255,0.06);
  --border-glow: rgba(0,210,255,0.2);
  --cyan: #00d2ff;
  --cyan-dim: rgba(0,210,255,0.12);
  --violet: #7c3aed;
  --violet-dim: rgba(124,58,237,0.15);
  --emerald: #10b981;
  --amber: #f59e0b;
  --rose: #f43f5e;
  --text: #f0f4f8;
  --text-2: #8b9db5;
  --text-3: #4a5568;
}
body { background: var(--bg); color: var(--text); font-family: 'DM Sans', sans-serif; overflow-x: hidden; }
::-webkit-scrollbar { width: 4px; }
::-webkit-scrollbar-track { background: var(--surface); }
::-webkit-scrollbar-thumb { background: var(--cyan); border-radius: 4px; }

/* ===== ANIMATIONS ===== */
@keyframes fadeUp    { from { opacity:0; transform:translateY(24px); } to { opacity:1; transform:translateY(0); } }
@keyframes fadeIn    { from { opacity:0; } to { opacity:1; } }
@keyframes float     { 0%,100% { transform:translateY(0); } 50% { transform:translateY(-8px); } }
@keyframes glowPulse { 0%,100% { box-shadow:0 0 20px rgba(0,210,255,.1); } 50% { box-shadow:0 0 40px rgba(0,210,255,.3); } }
@keyframes gradShift { 0%,100% { background-position:0% 50%; } 50% { background-position:100% 50%; } }
@keyframes barGrow   { from { width:0; } to { width:var(--w); } }
@keyframes countUp   { from { opacity:0; transform:scale(.7); } to { opacity:1; transform:scale(1); } }
@keyframes slideIn   { from { opacity:0; transform:translateX(-20px); } to { opacity:1; transform:translateX(0); } }
@keyframes bounce    { 0%,80%,100% { transform:scale(.6); opacity:.5; } 40% { transform:scale(1); opacity:1; } }
@keyframes spin      { from { transform:rotate(0deg); } to { transform:rotate(360deg); } }
@keyframes orbit     { from { transform:rotate(0deg) translateX(60px) rotate(0deg); } to { transform:rotate(360deg) translateX(60px) rotate(-360deg); } }

.fade-up   { animation: fadeUp .6s ease forwards; }
.fade-up-1 { animation: fadeUp .6s .1s ease forwards; opacity:0; }
.fade-up-2 { animation: fadeUp .6s .2s ease forwards; opacity:0; }
.fade-up-3 { animation: fadeUp .6s .3s ease forwards; opacity:0; }
.fade-up-4 { animation: fadeUp .6s .4s ease forwards; opacity:0; }
.slide-in  { animation: slideIn .5s ease forwards; }

/* ===== LAYOUT ===== */
.app { display:flex; min-height:100vh; }

/* ===== SIDEBAR ===== */
.sidebar {
  width:240px; min-height:100vh; background:var(--surface);
  border-right:1px solid var(--border); display:flex; flex-direction:column;
  position:fixed; left:0; top:0; bottom:0; z-index:100;
}
.sidebar-logo {
  padding:28px 24px; border-bottom:1px solid var(--border);
  display:flex; align-items:center; gap:12px;
}
.logo-icon {
  width:38px; height:38px; background:linear-gradient(135deg,var(--cyan),var(--violet));
  border-radius:10px; display:flex; align-items:center; justify-content:center;
  font-size:18px; animation:float 3s ease-in-out infinite; flex-shrink:0;
}
.logo-text {
  font-family:'Syne',sans-serif; font-weight:800; font-size:16px;
  background:linear-gradient(90deg,var(--cyan),var(--violet));
  -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text;
}
.logo-sub { font-size:10px; color:var(--text-3); margin-top:1px; }
.sidebar-nav { flex:1; padding:16px 12px; display:flex; flex-direction:column; gap:4px; overflow-y:auto; }
.nav-section-label {
  font-size:10px; font-weight:600; letter-spacing:.12em;
  color:var(--text-3); padding:12px 12px 6px; text-transform:uppercase;
}
.nav-item {
  display:flex; align-items:center; gap:10px; padding:10px 12px;
  border-radius:10px; cursor:pointer; transition:all .2s;
  color:var(--text-2); font-size:14px; font-weight:400; position:relative;
  border:1px solid transparent; text-decoration:none;
}
.nav-item:hover { background:var(--cyan-dim); color:var(--text); border-color:var(--border-glow); }
.nav-item.active {
  background:linear-gradient(135deg,rgba(0,210,255,.15),rgba(124,58,237,.1));
  color:var(--cyan); border-color:rgba(0,210,255,.25);
  box-shadow:inset 0 0 20px rgba(0,210,255,.05);
}
.nav-item.active::before {
  content:''; position:absolute; left:0; top:50%; transform:translateY(-50%);
  width:3px; height:60%; background:var(--cyan); border-radius:0 2px 2px 0;
}
.nav-icon { width:18px; height:18px; flex-shrink:0; display:flex; align-items:center; justify-content:center; }
.nav-badge {
  margin-left:auto; background:var(--rose); color:#fff;
  font-size:10px; font-weight:700; padding:2px 7px; border-radius:20px;
}
.sidebar-footer { padding:16px 12px; border-top:1px solid var(--border); }
.user-card {
  display:flex; align-items:center; gap:10px; padding:10px 12px;
  background:var(--surface2); border-radius:10px; border:1px solid var(--border); cursor:pointer; transition:all .2s;
}
.user-card:hover { border-color:var(--border-glow); }
.avatar {
  width:34px; height:34px; border-radius:50%;
  background:linear-gradient(135deg,var(--cyan),var(--violet));
  display:flex; align-items:center; justify-content:center;
  font-weight:700; font-size:14px; color:#fff; flex-shrink:0;
}
.avatar-lg { width:50px; height:50px; font-size:18px; }
.user-name  { font-size:13px; font-weight:500; color:var(--text); }
.user-role  { font-size:11px; color:var(--text-2); }

/* ===== MAIN ===== */
.main { margin-left:240px; flex:1; min-height:100vh; }

/* ===== TOPBAR ===== */
.topbar {
  height:64px; background:rgba(13,17,23,.8); backdrop-filter:blur(20px);
  border-bottom:1px solid var(--border); display:flex; align-items:center;
  padding:0 32px; gap:16px; position:sticky; top:0; z-index:50;
}
.topbar-title { font-family:'Syne',sans-serif; font-weight:700; font-size:18px; flex:1; }
.topbar-actions { display:flex; align-items:center; gap:10px; }
.icon-btn {
  width:38px; height:38px; border-radius:10px; border:1px solid var(--border);
  background:var(--surface2); display:flex; align-items:center; justify-content:center;
  cursor:pointer; transition:all .2s; color:var(--text-2); position:relative;
}
.icon-btn:hover { border-color:var(--border-glow); color:var(--cyan); box-shadow:0 0 20px rgba(0,210,255,.15); }
.notif-dot {
  position:absolute; top:7px; right:7px; width:7px; height:7px;
  background:var(--rose); border-radius:50%; border:1.5px solid var(--surface);
}

/* ===== PAGE ===== */
.page { padding:32px; animation:fadeIn .4s ease; }

/* ===== CARDS ===== */
.card {
  background:var(--surface); border:1px solid var(--border); border-radius:16px;
  padding:24px; transition:all .3s;
}
.card:hover { border-color:rgba(0,210,255,.15); box-shadow:0 4px 30px rgba(0,0,0,.3); }

/* ===== STAT CARD ===== */
.stat-card {
  background:var(--surface); border:1px solid var(--border); border-radius:16px;
  padding:22px; position:relative; overflow:hidden; transition:all .3s;
}
.stat-card::after {
  content:''; position:absolute; bottom:0; left:0; right:0; height:2px;
  background:var(--accent,var(--cyan)); transform:scaleX(0); transition:transform .3s; transform-origin:left;
}
.stat-card:hover::after { transform:scaleX(1); }
.stat-card:hover { border-color:var(--border-glow); transform:translateY(-2px); }
.stat-icon { width:42px; height:42px; border-radius:12px; display:flex; align-items:center; justify-content:center; font-size:20px; margin-bottom:14px; }
.stat-value { font-family:'Syne',sans-serif; font-weight:800; font-size:28px; line-height:1; animation:countUp .5s ease; }
.stat-label { font-size:13px; color:var(--text-2); margin-top:4px; }
.stat-change { font-size:12px; margin-top:8px; display:flex; align-items:center; gap:4px; }
.stat-up   { color:var(--emerald); }
.stat-down { color:var(--rose); }

/* ===== SECTION HEADER ===== */
.section-header { display:flex; align-items:center; justify-content:space-between; margin-bottom:20px; }
.section-title { font-family:'Syne',sans-serif; font-weight:700; font-size:18px; }
.section-sub   { font-size:13px; color:var(--text-2); margin-top:2px; }

/* ===== BUTTONS ===== */
.btn-primary {
  background:linear-gradient(135deg,var(--cyan),var(--violet));
  border:none; color:#fff; padding:10px 20px; border-radius:10px;
  cursor:pointer; font-size:14px; font-weight:500; font-family:'DM Sans',sans-serif;
  transition:all .2s; box-shadow:0 4px 15px rgba(0,210,255,.2); display:inline-flex; align-items:center; gap:6px;
}
.btn-primary:hover { transform:translateY(-1px); box-shadow:0 6px 25px rgba(0,210,255,.35); }
.btn-secondary {
  background:var(--surface2); border:1px solid var(--border); color:var(--text);
  padding:10px 20px; border-radius:10px; cursor:pointer; font-size:14px;
  font-family:'DM Sans',sans-serif; transition:all .2s; display:inline-flex; align-items:center; gap:6px;
}
.btn-secondary:hover { border-color:var(--border-glow); color:var(--cyan); }
.btn-ghost {
  background:none; border:1px solid var(--border); color:var(--text-2);
  padding:8px 16px; border-radius:8px; cursor:pointer; font-size:13px;
  font-family:'DM Sans',sans-serif; transition:all .2s; display:inline-flex; align-items:center; gap:6px;
}
.btn-ghost:hover { border-color:var(--border-glow); color:var(--cyan); }
.btn-hero {
  padding:14px 32px; border-radius:12px; font-size:15px; font-weight:600;
  cursor:pointer; font-family:'DM Sans',sans-serif; transition:all .3s;
}
.btn-hero-primary {
  background:linear-gradient(135deg,var(--cyan),var(--violet));
  border:none; color:#fff; box-shadow:0 8px 30px rgba(0,210,255,.3);
}
.btn-hero-primary:hover { transform:translateY(-2px); box-shadow:0 12px 40px rgba(0,210,255,.45); }
.btn-hero-secondary { background:transparent; border:1px solid var(--border); color:var(--text); }
.btn-hero-secondary:hover { border-color:var(--border-glow); color:var(--cyan); }
.btn-sm { padding:6px 14px; font-size:12px; border-radius:8px; }
.btn-icon {
  width:38px; height:38px; padding:0; border-radius:10px;
  display:inline-flex; align-items:center; justify-content:center;
}

/* ===== FORMS ===== */
.form-group { margin-bottom:16px; }
.input-label { font-size:13px; color:var(--text-2); margin-bottom:6px; display:block; }
.input-field {
  width:100%; background:var(--surface2); border:1px solid var(--border);
  border-radius:10px; padding:10px 14px; color:var(--text); font-size:14px;
  font-family:'DM Sans',sans-serif; transition:all .2s; outline:none;
}
.input-field:focus { border-color:var(--border-glow); box-shadow:0 0 0 3px rgba(0,210,255,.08); }
.input-field::placeholder { color:var(--text-3); }
.select-field {
  width:100%; background:var(--surface2); border:1px solid var(--border);
  border-radius:10px; padding:10px 14px; color:var(--text); font-size:14px;
  font-family:'DM Sans',sans-serif; transition:all .2s; outline:none; appearance:none; cursor:pointer;
}
.select-field:focus { border-color:var(--border-glow); }
select option { background:var(--surface2); color:var(--text); }

/* ===== PROGRESS ===== */
.progress-wrap   { margin-bottom:14px; }
.progress-header { display:flex; justify-content:space-between; margin-bottom:6px; font-size:13px; }
.progress-track  { height:6px; background:var(--surface2); border-radius:20px; overflow:hidden; }
.progress-fill {
  height:100%; border-radius:20px; transition:width 1.2s ease;
  background:linear-gradient(90deg, var(--pfrom, var(--cyan)), var(--pto, var(--violet)));
}

/* ===== GRIDS ===== */
.grid-4 { display:grid; grid-template-columns:repeat(4,1fr); gap:16px; }
.grid-3 { display:grid; grid-template-columns:repeat(3,1fr); gap:16px; }
.grid-2 { display:grid; grid-template-columns:repeat(2,1fr); gap:20px; }
.grid-13 { display:grid; grid-template-columns:1fr 3fr; gap:20px; }
.grid-31 { display:grid; grid-template-columns:3fr 1fr; gap:20px; }

/* ===== TAGS ===== */
.tag { display:inline-flex; align-items:center; gap:4px; padding:4px 10px; border-radius:6px; font-size:12px; font-weight:500; }

/* ===== TASK ITEM ===== */
.task-item {
  display:flex; align-items:center; gap:12px; padding:14px 16px;
  background:var(--surface2); border-radius:10px; border:1px solid var(--border);
  margin-bottom:8px; transition:all .2s; cursor:pointer;
}
.task-item:hover { border-color:var(--border-glow); background:rgba(0,210,255,.03); }
.task-check {
  width:20px; height:20px; border-radius:6px; border:2px solid var(--border-glow);
  display:flex; align-items:center; justify-content:center; flex-shrink:0; transition:all .2s;
}
.task-check.done { background:var(--emerald); border-color:var(--emerald); }
.task-name     { font-size:14px; font-weight:500; }
.task-name.done { text-decoration:line-through; color:var(--text-2); }
.task-meta     { font-size:12px; color:var(--text-2); margin-top:2px; }

/* ===== NOTIFICATIONS ===== */
.notif-item {
  display:flex; gap:12px; padding:14px 16px; border-radius:10px;
  border:1px solid var(--border); background:var(--surface2); margin-bottom:8px; transition:all .2s;
}
.notif-item:hover { border-color:var(--border-glow); }
.notif-item.unread { border-left:3px solid var(--cyan); }
.notif-dot-ui { width:38px; height:38px; border-radius:10px; flex-shrink:0; display:flex; align-items:center; justify-content:center; font-size:18px; }

/* ===== SCHEDULE ===== */
.schedule-block {
  border-radius:8px; padding:8px 12px; margin-bottom:4px; font-size:13px;
  font-weight:500; border-left:3px solid; transition:all .2s; cursor:pointer;
}
.schedule-block:hover { transform:translateX(3px); }

/* ===== AI THINKING ===== */
.ai-thinking { display:flex; gap:4px; align-items:center; }
.ai-dot { width:8px; height:8px; border-radius:50%; background:var(--cyan); animation:bounce 1.2s ease-in-out infinite; }
.ai-dot:nth-child(2) { animation-delay:.2s; background:var(--violet); }
.ai-dot:nth-child(3) { animation-delay:.4s; background:#ff6b9d; }

/* ===== KANBAN ===== */
.kanban-col {
  background:var(--surface); border:1px solid var(--border); border-radius:16px;
  padding:20px; min-height:400px;
}
.kanban-card {
  background:var(--surface2); border:1px solid var(--border); border-radius:12px;
  padding:14px; margin-bottom:8px; transition:all .2s; cursor:pointer;
}
.kanban-card:hover { border-color:rgba(0,210,255,.2); transform:translateY(-1px); box-shadow:0 4px 20px rgba(0,0,0,.3); }

/* ===== LANDING ===== */
.landing-nav {
  position:fixed; top:0; left:0; right:0; z-index:200;
  padding:16px 48px; display:flex; align-items:center; justify-content:space-between;
  background:rgba(6,9,16,.85); backdrop-filter:blur(20px);
  border-bottom:1px solid var(--border);
}
.landing-nav-link { font-size:14px; color:var(--text-2); cursor:pointer; transition:color .2s; text-decoration:none; }
.landing-nav-link:hover { color:var(--text); }
.hero { min-height:100vh; display:flex; flex-direction:column; align-items:center; justify-content:center; text-align:center; padding:40px; position:relative; overflow:hidden; }
.hero-bg { position:absolute; inset:0; overflow:hidden; z-index:0; }
.orb { position:absolute; border-radius:50%; filter:blur(80px); opacity:.15; }
.orb1 { width:600px; height:600px; background:var(--cyan); top:-200px; left:-200px; }
.orb2 { width:500px; height:500px; background:var(--violet); bottom:-150px; right:-150px; }
.orb3 { width:300px; height:300px; background:var(--emerald); bottom:100px; left:200px; animation:float 6s ease-in-out infinite; }
.hero-content { position:relative; z-index:1; max-width:800px; }
.hero-badge {
  display:inline-flex; align-items:center; gap:8px; padding:8px 16px;
  background:rgba(0,210,255,.1); border:1px solid rgba(0,210,255,.25);
  border-radius:20px; font-size:13px; color:var(--cyan); margin-bottom:32px;
  animation:glowPulse 2s ease-in-out infinite;
}
.hero-title { font-family:'Syne',sans-serif; font-weight:800; font-size:64px; line-height:1.05; margin-bottom:20px; letter-spacing:-2px; }
.gradient-text {
  background:linear-gradient(135deg,var(--cyan),var(--violet),#ff6b9d);
  background-size:200% auto; -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text;
  animation:gradShift 3s ease infinite;
}
.hero-sub { font-size:18px; color:var(--text-2); line-height:1.6; margin-bottom:40px; max-width:560px; margin-left:auto; margin-right:auto; }
.features-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:20px; margin-top:80px; text-align:left; }
.feature-card {
  background:rgba(13,17,23,.7); backdrop-filter:blur(20px); border:1px solid var(--border);
  border-radius:16px; padding:24px; transition:all .3s;
}
.feature-card:hover { border-color:var(--border-glow); transform:translateY(-4px); box-shadow:0 20px 40px rgba(0,0,0,.4); }
.feature-icon  { font-size:28px; margin-bottom:14px; }
.feature-title { font-family:'Syne',sans-serif; font-weight:700; font-size:16px; margin-bottom:8px; }
.feature-desc  { font-size:13px; color:var(--text-2); line-height:1.6; }

/* ===== AUTH ===== */
.auth-wrap { min-height:100vh; display:flex; align-items:center; justify-content:center; background:var(--bg); position:relative; overflow:hidden; }
.auth-card {
  background:var(--surface); border:1px solid var(--border); border-radius:20px;
  padding:40px; width:420px; position:relative; z-index:1; animation:fadeUp .5s ease;
}
.auth-title { font-family:'Syne',sans-serif; font-weight:800; font-size:28px; margin-bottom:8px; }
.auth-sub   { font-size:14px; color:var(--text-2); margin-bottom:32px; }
.auth-divider { display:flex; align-items:center; gap:12px; margin:20px 0; color:var(--text-3); font-size:12px; }
.auth-divider::before,.auth-divider::after { content:''; flex:1; height:1px; background:var(--border); }
.auth-link { color:var(--cyan); text-decoration:none; font-size:14px; }
.auth-link:hover { text-decoration:underline; }

/* ===== DASHBOARD PREVIEW (login page) ===== */
.dashboard-preview {
  background:var(--surface2); border:1px solid var(--border); border-radius:16px;
  padding:20px; cursor:pointer; transition:all .3s; position:relative; overflow:hidden;
  margin-top:20px;
}
.dashboard-preview::before {
  content:''; position:absolute; inset:0;
  background:linear-gradient(135deg,rgba(0,210,255,.05),rgba(124,58,237,.05));
  opacity:0; transition:opacity .3s;
}
.dashboard-preview:hover { border-color:var(--border-glow); transform:translateY(-3px); box-shadow:0 10px 40px rgba(0,210,255,.1); }
.dashboard-preview:hover::before { opacity:1; }
.preview-badge {
  display:inline-flex; align-items:center; gap:6px; padding:6px 12px;
  background:rgba(0,210,255,.1); border:1px solid rgba(0,210,255,.2);
  border-radius:20px; font-size:12px; color:var(--cyan); margin-bottom:12px;
}
.preview-mini-stat {
  background:var(--surface); border:1px solid var(--border); border-radius:10px;
  padding:12px; text-align:center;
}
.preview-mini-val { font-family:'Syne',sans-serif; font-weight:800; font-size:20px; }
.preview-mini-lbl { font-size:11px; color:var(--text-2); margin-top:2px; }
.preview-bar { height:5px; background:var(--surface); border-radius:20px; overflow:hidden; margin-top:6px; }
.preview-bar-fill { height:100%; border-radius:20px; background:linear-gradient(90deg,var(--cyan),var(--violet)); }

/* ===== TIMER ===== */
.timer-display {
  font-family:'Syne',sans-serif; font-size:72px; font-weight:800;
  background:linear-gradient(135deg,var(--cyan),var(--violet));
  -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text;
  letter-spacing:-2px; line-height:1;
}

/* ===== CGPA TOOL ===== */
.cgpa-card {
  background:var(--surface); border:1px solid var(--border); border-radius:16px;
  padding:28px; transition:all .3s;
}
.cgpa-result {
  background:linear-gradient(135deg,rgba(0,210,255,.08),rgba(124,58,237,.08));
  border:1px solid rgba(0,210,255,.2); border-radius:14px; padding:24px;
  animation:fadeUp .5s ease;
}
.cgpa-big { font-family:'Syne',sans-serif; font-weight:800; font-size:48px; background:linear-gradient(135deg,var(--cyan),var(--violet)); -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text; }
.subject-row { display:grid; grid-template-columns:2fr 1fr 1fr 38px; gap:10px; align-items:center; margin-bottom:10px; }
.subject-row-header { display:grid; grid-template-columns:2fr 1fr 1fr 38px; gap:10px; align-items:center; margin-bottom:8px; font-size:12px; color:var(--text-3); font-weight:600; letter-spacing:.05em; text-transform:uppercase; }
.remove-btn {
  width:34px; height:34px; border-radius:8px; background:rgba(244,63,94,.1); border:1px solid rgba(244,63,94,.2);
  color:var(--rose); cursor:pointer; display:flex; align-items:center; justify-content:center;
  transition:all .2s; font-size:16px; flex-shrink:0;
}
.remove-btn:hover { background:rgba(244,63,94,.2); }
.plan-item {
  display:flex; gap:14px; padding:14px 16px; background:var(--surface2); border:1px solid var(--border);
  border-radius:12px; margin-bottom:10px; animation:slideIn .4s ease;
}
.plan-item-icon { width:40px; height:40px; border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:18px; flex-shrink:0; }

/* ===== TOOLTIP ===== */
.tooltip-wrap { position:relative; }
.tooltip {
  position:absolute; bottom:calc(100% + 8px); left:50%; transform:translateX(-50%);
  background:var(--surface2); border:1px solid var(--border); border-radius:8px;
  padding:6px 10px; font-size:12px; white-space:nowrap; pointer-events:none; opacity:0; transition:opacity .2s; z-index:99;
}
.tooltip-wrap:hover .tooltip { opacity:1; }

/* ===== STEP INDICATOR ===== */
.step-bar { display:flex; gap:8px; margin-bottom:24px; }
.step-seg { flex:1; height:3px; border-radius:4px; transition:all .3s; }
.step-seg.active { background:linear-gradient(90deg,var(--cyan),var(--violet)); box-shadow:0 0 10px rgba(0,210,255,.3); }
.step-seg.inactive { background:var(--border); }

/* ===== MISC ===== */
.divider { height:1px; background:var(--border); margin:20px 0; }
.badge { display:inline-flex; align-items:center; padding:3px 10px; border-radius:20px; font-size:12px; font-weight:600; }
.glow-cyan { box-shadow:0 0 20px rgba(0,210,255,.2); }
.glow-violet { box-shadow:0 0 20px rgba(124,58,237,.2); }
.text-cyan { color:var(--cyan); }
.text-violet { color:var(--violet); }
.text-emerald { color:var(--emerald); }
.text-amber { color:var(--amber); }
.text-rose { color:var(--rose); }
.text-muted { color:var(--text-2); }
.fw-bold { font-weight:700; }
.fw-800 { font-family:'Syne',sans-serif; font-weight:800; }
.mt-8  { margin-top:8px; }
.mt-16 { margin-top:16px; }
.mt-24 { margin-top:24px; }
.mb-8  { margin-bottom:8px; }
.mb-16 { margin-bottom:16px; }
.mb-24 { margin-bottom:24px; }
.flex  { display:flex; }
.flex-center { display:flex; align-items:center; }
.flex-between { display:flex; align-items:center; justify-content:space-between; }
.flex-col { display:flex; flex-direction:column; }
.gap-8  { gap:8px; }
.gap-12 { gap:12px; }
.gap-16 { gap:16px; }
.gap-24 { gap:24px; }
.w-full { width:100%; }
.text-center { text-align:center; }

/* ===== MINI CHART SVG ===== */
.chart-svg { width:100%; overflow:visible; }


/* ═══ SIDEBAR EXTRA ═══ */
.sidebar { width:240px; min-height:100vh; background:var(--surface); border-right:1px solid var(--border); display:flex; flex-direction:column; position:fixed; left:0; top:0; bottom:0; z-index:100; }
.sidebar-logo { padding:26px 20px; border-bottom:1px solid var(--border); display:flex; align-items:center; gap:12px; }
.logo-icon { width:38px; height:38px; background:linear-gradient(135deg,var(--cyan),var(--violet)); border-radius:10px; display:flex; align-items:center; justify-content:center; font-size:18px; animation:float 3s ease-in-out infinite; flex-shrink:0; text-decoration:none; }
.logo-text { font-family:'Syne',sans-serif; font-weight:800; font-size:16px; background:linear-gradient(90deg,var(--cyan),var(--violet)); -webkit-background-clip:text; -webkit-text-fill-color:transparent; background-clip:text; }
.logo-sub { font-size:10px; color:var(--text-3); margin-top:1px; }
.sidebar-nav { flex:1; padding:14px 10px; display:flex; flex-direction:column; gap:3px; overflow-y:auto; }
.sidebar-nav::-webkit-scrollbar { width:2px; }
.nav-section-label { font-size:10px; font-weight:700; letter-spacing:.12em; color:var(--text-3); padding:10px 12px 5px; text-transform:uppercase; }
.nav-item { display:flex; align-items:center; gap:10px; padding:10px 12px; border-radius:10px; cursor:pointer; transition:all .2s; color:var(--text-2); font-size:13.5px; font-weight:400; position:relative; border:1px solid transparent; text-decoration:none; }
.nav-item:hover { background:var(--cyan-dim); color:var(--text); border-color:var(--border-glow); }
.nav-item-active { background:linear-gradient(135deg,rgba(0,210,255,.15),rgba(124,58,237,.1)) !important; color:var(--cyan) !important; border-color:rgba(0,210,255,.25) !important; box-shadow:inset 0 0 20px rgba(0,210,255,.05); }
.nav-active-bar { position:absolute; left:0; top:50%; transform:translateY(-50%); width:3px; height:60%; background:var(--cyan); border-radius:0 2px 2px 0; }
.nav-icon { width:20px; height:20px; flex-shrink:0; display:flex; align-items:center; justify-content:center; font-size:15px; }
.nav-label { flex:1; }
.nav-badge { margin-left:auto; background:var(--rose); color:#fff; font-size:10px; font-weight:700; padding:2px 7px; border-radius:20px; min-width:20px; text-align:center; }
.sidebar-footer { padding:14px 10px; border-top:1px solid var(--border); }
.user-card { display:flex; align-items:center; gap:10px; padding:10px 12px; background:var(--surface2); border-radius:10px; border:1px solid var(--border); cursor:pointer; transition:all .2s; }
.user-card:hover { border-color:var(--border-glow); }
.avatar { width:34px; height:34px; border-radius:50%; background:linear-gradient(135deg,var(--cyan),var(--violet)); display:flex; align-items:center; justify-content:center; font-weight:700; font-size:13px; color:#fff; flex-shrink:0; }
.user-name { font-size:13px; font-weight:500; color:var(--text); }
.user-role { font-size:11px; color:var(--text-2); }

/* ═══ TOPBAR EXTRA ═══ */
.topbar { height:64px; background:rgba(13,17,23,.9); backdrop-filter:blur(20px); border-bottom:1px solid var(--border); display:flex; align-items:center; padding:0 28px; gap:16px; position:sticky; top:0; z-index:50; }
.topbar-title { font-family:'Syne',sans-serif; font-weight:700; font-size:18px; flex:1; }
.topbar-actions { display:flex; align-items:center; gap:10px; }
.icon-btn { width:38px; height:38px; border-radius:10px; border:1px solid var(--border); background:var(--surface2); display:flex; align-items:center; justify-content:center; cursor:pointer; transition:all .2s; color:var(--text-2); position:relative; text-decoration:none; }
.icon-btn:hover { border-color:var(--border-glow); color:var(--cyan); box-shadow:0 0 20px rgba(0,210,255,.15); }
.notif-dot { position:absolute; top:7px; right:7px; width:7px; height:7px; background:var(--rose); border-radius:50%; border:1.5px solid var(--surface); }

/* ═══ MOBILE TOGGLE ═══ */
.mob-toggle { display:none; position:fixed; top:15px; left:14px; z-index:200; background:var(--surface); border:1px solid var(--border); border-radius:8px; width:38px; height:38px; flex-direction:column; align-items:center; justify-content:center; gap:5px; cursor:pointer; padding:0; }
.mob-toggle span { display:block; width:18px; height:2px; background:var(--text-2); border-radius:2px; transition:all .2s; }
.mob-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,.5); z-index:99; backdrop-filter:blur(2px); }
@media(max-width:768px) {
  .sidebar { transform:translateX(-100%); transition:transform .3s ease; }
  .sidebar.mob-open { transform:translateX(0); }
  .sidebar.mob-open ~ .mob-overlay { display:block; }
  .mob-toggle { display:flex; }
  .main { margin-left:0 !important; }
  .mob-overlay { display:none; }
  .sidebar.mob-open + * + .mob-overlay { display:block; }
}

</style>
  <style>
    .grade-table { width:100%; border-collapse:separate; border-spacing:0 6px; }
    .grade-table th { font-size:11px; color:var(--text-3); font-weight:600; letter-spacing:.08em; text-transform:uppercase; padding:0 8px 8px; }
    .grade-input  { background:var(--surface); border:1px solid var(--border); border-radius:8px; padding:8px 12px; color:var(--text); font-size:13px; font-family:'DM Sans',sans-serif; outline:none; transition:all .2s; width:100%; }
    .grade-input:focus { border-color:var(--border-glow); box-shadow:0 0 0 3px rgba(0,210,255,.07); }
    .grade-row { display:grid; grid-template-columns:2fr 100px 130px 38px; gap:10px; align-items:center; margin-bottom:8px; animation:slideIn .3s ease; }
    .grade-header { display:grid; grid-template-columns:2fr 100px 130px 38px; gap:10px; align-items:center; margin-bottom:10px; padding:0 4px; }
    .result-panel { animation:fadeUp .5s ease; }
    .need-tag { display:inline-flex; align-items:center; gap:6px; padding:6px 14px; border-radius:8px; font-size:13px; font-weight:600; }
    .plan-day-header {
      display:flex; align-items:center; gap:10px; padding:12px 16px;
      background:linear-gradient(135deg,rgba(0,210,255,.08),rgba(124,58,237,.08));
      border:1px solid rgba(0,210,255,.15); border-radius:10px; margin-bottom:8px; cursor:pointer;
    }
    .plan-day-content { padding:0 16px 8px; display:none; }
    .plan-day-content.open { display:block; }
    .subject-plan-row {
      display:flex; gap:12px; align-items:flex-start; padding:10px 0;
      border-bottom:1px solid var(--border);
    }
    .hours-badge {
      background:var(--surface2); border:1px solid var(--border); border-radius:8px;
      padding:4px 10px; font-size:12px; font-weight:600; white-space:nowrap;
    }
    .difficulty-pill { padding:3px 8px; border-radius:20px; font-size:11px; font-weight:600; }
    .tab-btn { padding:8px 16px; border-radius:8px; border:1px solid var(--border); background:none; color:var(--text-2); cursor:pointer; font-size:13px; font-family:'DM Sans',sans-serif; transition:all .2s; }
    .tab-btn.active { background:var(--cyan-dim); color:var(--cyan); border-color:rgba(0,210,255,.25); }
    .pointer-ring { position:relative; display:inline-flex; align-items:center; justify-content:center; }
  </style>
</head>
<body>
<div class="app">
  
  <!-- ════════ SIDEBAR ════════ -->
  <aside class="sidebar" id="main-sidebar">
    <div class="sidebar-logo">
      <div class="logo-icon">🧠</div>
      <div>
        <div class="logo-text">StudyAI</div>
        <div class="logo-sub">Pro Plan</div>
      </div>
    </div>

    <nav class="sidebar-nav">
      <div class="nav-section-label">MAIN</div>
      
        <a href="dashboard.php" class="nav-item " style="">
          
          <span class="nav-icon">🏠</span>
          <span class="nav-label">Dashboard</span>
          
        </a>
        <a href="schedule.php" class="nav-item " style="">
          
          <span class="nav-icon">📅</span>
          <span class="nav-label">AI Schedule</span>
          
        </a>
        <a href="tasks.php" class="nav-item " style="">
          
          <span class="nav-icon">✅</span>
          <span class="nav-label">Tasks</span>
          <span class="nav-badge">3</span>
        </a>
        <a href="timer.php" class="nav-item " style="">
          
          <span class="nav-icon">⏱️</span>
          <span class="nav-label">Study Timer</span>
          
        </a>
        <a href="analytics.php" class="nav-item " style="">
          
          <span class="nav-icon">📊</span>
          <span class="nav-label">Analytics</span>
          
        </a>
        <a href="cgpa-planner.php" class="nav-item nav-item-active" style="background:linear-gradient(135deg,rgba(0,210,255,.08),rgba(124,58,237,.08));border-color:rgba(0,210,255,.15);">
          <span class="nav-active-bar"></span>
          <span class="nav-icon">🎓</span>
          <span class="nav-label">CGPA Planner</span>
          
        </a>
      <a href="career-guide.php" class="nav-item"><span class="nav-icon">🚀</span><span class="nav-label">Career Guide</span></a>
      <div class="nav-section-label" style="margin-top:12px">ACCOUNT</div>
      
        <a href="notifications.php" class="nav-item " style="">
          
          <span class="nav-icon">🔔</span>
          <span class="nav-label">Notifications</span>
          <span class="nav-badge">2</span>
        </a>
        <a href="profile-setup.php" class="nav-item " style="">
          
          <span class="nav-icon">👤</span>
          <span class="nav-label">Profile Setup</span>
          
        </a>
    </nav>

    <div class="sidebar-footer">
      <div class="user-card" onclick="handleLogout()" title="Click to logout" id="user-card">
        <div class="avatar" id="user-avatar">ST</div>
        <div>
          <div class="user-name" id="user-name-el">Student</div>
          <div class="user-role" id="user-role-el">Loading...</div>
        </div>
      </div>
    </div>
  </aside>
  <!-- ════════ END SIDEBAR ════════ -->

  <!-- ════════ MOBILE MENU TOGGLE ════════ -->
  <button class="mob-toggle" onclick="document.getElementById('main-sidebar').classList.toggle('mob-open')" title="Menu">
    <span></span><span></span><span></span>
  </button>
  <div class="mob-overlay" onclick="document.getElementById('main-sidebar').classList.remove('mob-open')"></div>

  <div class="main">
    
  <!-- ════════ TOPBAR ════════ -->
  <div class="topbar">
    <div class="topbar-title">CGPA / Pointer Planner</div>
    <div class="topbar-actions">
      <div class="icon-btn" title="Search" onclick="document.querySelector('.search-input')?.focus()">
        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/>
        </svg>
      </div>
      <a href="notifications.php" class="icon-btn" title="Notifications" style="text-decoration:none;color:var(--text-2);position:relative">
        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6 6 0 10-12 0v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0a3 3 0 01-6 0"/>
        </svg>
        <span class="notif-dot"></span>
      </a>
      <a href="profile-setup.php" style="text-decoration:none">
        <div class="avatar" style="width:34px;height:34px;font-size:13px;cursor:pointer" id="topbar-avatar">ST</div>
      </a>
    </div>
  </div>
  <!-- ════════ END TOPBAR ════════ -->

    <div class="page">

      <!-- HEADER -->
      <div style="margin-bottom:28px" class="fade-up">
        <div style="display:flex;align-items:center;gap:12px;margin-bottom:8px">
          <div style="width:42px;height:42px;border-radius:12px;background:linear-gradient(135deg,var(--cyan),var(--violet));display:flex;align-items:center;justify-content:center;font-size:20px">🎓</div>
          <div>
            <div class="section-title" style="font-size:22px">CGPA / Pointer Improvement Planner</div>
            <div class="section-sub">Enter your previous semester data → Get an accurate study plan to boost your next semester pointer</div>
          </div>
        </div>
        <div style="display:flex;gap:10px">
          <div style="display:inline-flex;align-items:center;gap:6px;padding:6px 14px;background:rgba(0,210,255,.08);border:1px solid rgba(0,210,255,.2);border-radius:20px;font-size:12px;color:var(--cyan)">
            <div class="ai-thinking"><div class="ai-dot" style="width:6px;height:6px"></div><div class="ai-dot" style="width:6px;height:6px"></div><div class="ai-dot" style="width:6px;height:6px"></div></div>
            AI-Powered Analysis
          </div>
          <div style="display:inline-flex;align-items:center;gap:6px;padding:6px 14px;background:rgba(124,58,237,.08);border:1px solid rgba(124,58,237,.2);border-radius:20px;font-size:12px;color:var(--violet)">
            🎯 Smart Study Allocation
          </div>
        </div>
      </div>

      <div class="grid-2" style="align-items:start">

        <!-- LEFT: INPUT PANEL -->
        <div style="display:flex;flex-direction:column;gap:16px">

          <!-- CURRENT CGPA -->
          <div class="cgpa-card fade-up-1">
            <div class="section-title" style="font-size:16px;margin-bottom:16px">📊 Current Semester Details</div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">
              <div class="form-group" style="margin-bottom:0">
                <label class="input-label">Current Semester</label>
                <select id="current-sem" class="select-field">
                  <option value="1">Semester 1</option>
                  <option value="2">Semester 2</option>
                  <option value="3" selected>Semester 3</option>
                  <option value="4">Semester 4</option>
                  <option value="5">Semester 5</option>
                  <option value="6">Semester 6</option>
                  <option value="7">Semester 7</option>
                  <option value="8">Semester 8</option>
                </select>
              </div>
              <div class="form-group" style="margin-bottom:0">
                <label class="input-label">Grading System</label>
                <select id="grading-system" class="select-field" onchange="updateGradeOptions()">
                  <option value="10">10-point CGPA (VTU/Mumbai/SPPU)</option>
                  <option value="4">4-point GPA (US System)</option>
                  <option value="percentage">Percentage (%)</option>
                </select>
              </div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
              <div class="form-group" style="margin-bottom:0">
                <label class="input-label">Current Overall CGPA</label>
                <input id="current-cgpa" type="number" class="input-field" placeholder="e.g. 6.8" step="0.01" min="0" max="10"/>
              </div>
              <div class="form-group" style="margin-bottom:0">
                <label class="input-label">Last Semester Pointer / SGPA</label>
                <input id="last-sgpa" type="number" class="input-field" placeholder="e.g. 6.2" step="0.01" min="0" max="10"/>
              </div>
            </div>
          </div>

          <!-- SUBJECTS TABLE -->
          <div class="cgpa-card fade-up-2">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
              <div class="section-title" style="font-size:16px">📚 Previous Semester Subjects & Grades</div>
              <button class="btn-ghost btn-sm" onclick="addSubjectRow()">＋ Add Subject</button>
            </div>

            <div class="grade-header">
              <span style="font-size:11px;color:var(--text-3);text-transform:uppercase;letter-spacing:.08em">Subject Name</span>
              <span style="font-size:11px;color:var(--text-3);text-transform:uppercase;letter-spacing:.08em">Credits</span>
              <span style="font-size:11px;color:var(--text-3);text-transform:uppercase;letter-spacing:.08em">Grade / Marks</span>
              <span></span>
            </div>
            <div id="subjects-container"></div>
          </div>

          <!-- TARGET -->
          <div class="cgpa-card fade-up-3">
            <div class="section-title" style="font-size:16px;margin-bottom:16px">🎯 Your Target</div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-bottom:16px">
              <div class="form-group" style="margin-bottom:0">
                <label class="input-label">Target CGPA After Next Sem</label>
                <input id="target-cgpa" type="number" class="input-field" placeholder="e.g. 7.5" step="0.01" min="0" max="10"/>
              </div>
              <div class="form-group" style="margin-bottom:0">
                <label class="input-label">Total Semesters in Course</label>
                <select id="total-sems" class="select-field">
                  <option value="6">6 Semesters (3 years)</option>
                  <option value="8" selected>8 Semesters (4 years)</option>
                  <option value="10">10 Semesters (5 years)</option>
                </select>
              </div>
            </div>
            <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px">
              <div class="form-group" style="margin-bottom:0">
                <label class="input-label">Available Daily Study Hours</label>
                <input id="daily-hours" type="number" class="input-field" placeholder="e.g. 6" min="1" max="16" value="6"/>
              </div>
              <div class="form-group" style="margin-bottom:0">
                <label class="input-label">Weeks Until Exam</label>
                <input id="weeks-to-exam" type="number" class="input-field" placeholder="e.g. 12" min="1" max="30" value="12"/>
              </div>
            </div>
            <div style="margin-top:16px">
              <label class="input-label">Preferred Study Time</label>
              <div style="display:flex;gap:8px;flex-wrap:wrap" id="study-time-pref">
                <button class="tab-btn active" onclick="togglePref(this)">🌅 Morning</button>
                <button class="tab-btn" onclick="togglePref(this)">☀️ Afternoon</button>
                <button class="tab-btn" onclick="togglePref(this)">🌙 Evening</button>
                <button class="tab-btn" onclick="togglePref(this)">🌃 Night</button>
              </div>
            </div>

            <button class="btn-primary" style="width:100%;justify-content:center;margin-top:20px;padding:13px;font-size:15px" onclick="generatePlan()">
              🤖 Generate AI Study Plan
            </button>
          </div>
        </div>

        <!-- RIGHT: RESULT PANEL -->
        <div id="result-panel" style="display:none">
          <div class="result-panel fade-up">

            <!-- POINTER REQUIREMENT -->
            <div class="cgpa-card" style="margin-bottom:16px;text-align:center;border-color:rgba(0,210,255,.2);background:linear-gradient(135deg,rgba(0,210,255,.05),rgba(124,58,237,.05))">
              <div style="font-size:13px;color:var(--text-2);margin-bottom:8px">You need to score this pointer next semester</div>
              <div class="cgpa-big" id="required-pointer">—</div>
              <div style="font-size:13px;color:var(--text-2);margin-top:4px" id="pointer-label">Required Semester Pointer</div>
              <div style="display:flex;justify-content:center;gap:10px;margin-top:16px" id="difficulty-indicator"></div>
              <div style="margin-top:16px" id="pointer-bar">
                <div style="display:flex;justify-content:space-between;font-size:12px;color:var(--text-2);margin-bottom:6px">
                  <span id="curr-lbl">Current: —</span><span id="tgt-lbl">Target: —</span>
                </div>
                <div style="height:8px;background:var(--surface2);border-radius:20px;overflow:hidden">
                  <div id="pointer-progress" style="height:100%;border-radius:20px;background:linear-gradient(90deg,var(--cyan),var(--violet));width:0%;transition:width 1.2s ease"></div>
                </div>
              </div>
            </div>

            <!-- SUBJECT ANALYSIS -->
            <div class="cgpa-card" style="margin-bottom:16px">
              <div class="section-title" style="font-size:16px;margin-bottom:16px">📈 Subject-wise Analysis</div>
              <div id="subject-analysis"></div>
            </div>

            <!-- TABS: PLAN VIEW -->
            <div class="cgpa-card" style="margin-bottom:16px">
              <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
                <div class="section-title" style="font-size:16px">📅 AI Study Plan</div>
                <div style="display:flex;gap:6px">
                  <button class="tab-btn active" onclick="switchPlanView('daily',this)">Daily</button>
                  <button class="tab-btn" onclick="switchPlanView('weekly',this)">Weekly</button>
                  <button class="tab-btn" onclick="switchPlanView('tips',this)">AI Tips</button>
                </div>
              </div>
              <div id="plan-daily"></div>
              <div id="plan-weekly" style="display:none"></div>
              <div id="plan-tips" style="display:none"></div>
            </div>

            <!-- ACTION BUTTONS -->
            <div style="display:flex;gap:10px">
              <button class="btn-primary" style="flex:1;justify-content:center" onclick="saveToSchedule()">💾 Save to Schedule</button>
              <button class="btn-secondary" onclick="printPlan()">🖨️ Export Plan</button>
            </div>
          </div>
        </div>

        <!-- RIGHT PLACEHOLDER before results -->
        <div id="right-placeholder" class="fade-up-2">
          <div class="cgpa-card" style="text-align:center;padding:48px 24px">
            <div style="font-size:64px;animation:float 3s ease-in-out infinite;margin-bottom:20px">🎓</div>
            <div style="font-family:'Syne',sans-serif;font-weight:700;font-size:20px;margin-bottom:12px">Smart CGPA Planner</div>
            <div style="color:var(--text-2);font-size:14px;line-height:1.7;max-width:300px;margin:0 auto">
              Fill in your previous semester subjects and grades on the left.<br/><br/>
              Our AI will calculate exactly what pointer you need next semester and build a custom study plan to achieve it.
            </div>
            <div style="margin-top:28px;display:flex;flex-direction:column;gap:12px">
              <div style="display:flex;align-items:center;gap:10px;padding:12px 16px;background:var(--surface2);border-radius:10px;border:1px solid var(--border);text-align:left">
                <span style="font-size:20px">📊</span>
                <div><div style="font-size:13px;font-weight:600">Accurate Calculation</div><div style="font-size:12px;color:var(--text-2)">Based on your actual grades & credits</div></div>
              </div>
              <div style="display:flex;align-items:center;gap:10px;padding:12px 16px;background:var(--surface2);border-radius:10px;border:1px solid var(--border);text-align:left">
                <span style="font-size:20px">⚡</span>
                <div><div style="font-size:13px;font-weight:600">Prioritized Study Plan</div><div style="font-size:12px;color:var(--text-2)">AI allocates time based on weak subjects</div></div>
              </div>
              <div style="display:flex;align-items:center;gap:10px;padding:12px 16px;background:var(--surface2);border-radius:10px;border:1px solid var(--border);text-align:left">
                <span style="font-size:20px">🎯</span>
                <div><div style="font-size:13px;font-weight:600">Day-by-Day Schedule</div><div style="font-size:12px;color:var(--text-2)">Exact hours per subject, per day</div></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<script src="js/api.js"></script>
<script>
/* ── USER INFO ── */
(function(){
  try {
    var u = JSON.parse(sessionStorage.getItem('studyai_user') || '{}');
    var name = u.name || 'Student';
    var role = u.level || u.subject || 'Student';
    var ini  = name.split(' ').map(function(w){return w[0];}).join('').toUpperCase().slice(0,2) || 'ST';
    var el; 
    el = document.getElementById('user-name-el'); if(el) el.textContent = name;
    el = document.getElementById('user-role-el'); if(el) el.textContent = role;
    el = document.getElementById('user-avatar');  if(el) el.textContent = ini;
    el = document.getElementById('topbar-avatar');if(el) el.textContent = ini;
  } catch(e){}
})();

/* ── TOAST ── */
function showToast(msg, type) {
  var colors = {success:'#10b981',error:'#f43f5e',info:'#00d2ff',warn:'#f59e0b'};
  var c = colors[type||'success'] || colors.success;
  var t = document.createElement('div');
  t.style.cssText = 'position:fixed;bottom:24px;right:24px;background:#0d1117;border:1px solid '+c+';color:#f0f4f8;padding:12px 20px;border-radius:12px;font-size:14px;z-index:9999;animation:fadeUp .3s ease;box-shadow:0 8px 30px rgba(0,0,0,.5);max-width:340px;border-left:3px solid '+c+';font-family:DM Sans,sans-serif;';
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(function(){ t.style.opacity='0'; t.style.transition='opacity .3s'; setTimeout(function(){t.remove();},300); }, 3000);
}

/* ── DB HELPERS ── */
var DB = {
  get: function(k, def) { try { var v=JSON.parse(localStorage.getItem('sai_'+k)); return v!=null?v:def; } catch(e){ return def!=null?def:[]; } },
  set: function(k, v)   { localStorage.setItem('sai_'+k, JSON.stringify(v)); }
};

/* ── MINI LINE CHART ── */
function renderMiniChart(cid, data, color, height) {
  color = color||'#00d2ff'; height = height||70;
  var el=document.getElementById(cid); if(!el) return;
  var w=el.clientWidth||300, h=height;
  var max=Math.max.apply(null,data), min=Math.min.apply(null,data);
  var pts=data.map(function(v,i){
    var x=(i/(data.length-1))*w;
    var y=h-((v-min)/(max-min||1))*(h-10)-5;
    return x+','+y;
  }).join(' ');
  var dots=data.map(function(v,i){
    var x=(i/(data.length-1))*w, y=h-((v-min)/(max-min||1))*(h-10)-5;
    return '<circle cx="'+x+'" cy="'+y+'" r="3" fill="'+color+'" style="filter:drop-shadow(0 0 4px '+color+')"/>';
  }).join('');
  el.innerHTML='<svg viewBox="0 0 '+w+' '+h+'" width="100%" height="'+h+'" preserveAspectRatio="none"><defs><linearGradient id="cg'+cid+'" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stop-color="'+color+'" stop-opacity="0.3"/><stop offset="100%" stop-color="'+color+'" stop-opacity="0"/></linearGradient></defs><polygon points="0,'+h+' '+pts+' '+w+','+h+'" fill="url(#cg'+cid+')"/><polyline points="'+pts+'" fill="none" stroke="'+color+'" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="filter:drop-shadow(0 0 6px '+color+')"/>'+dots+'</svg>';
}

/* ── DONUT CHART ── */
function renderDonut(cid, value, total, size, c1, c2) {
  total=total||100; size=size||120; c1=c1||'#00d2ff'; c2=c2||'#7c3aed';
  var el=document.getElementById(cid); if(!el) return;
  var r=(size-14)/2, circ=2*Math.PI*r, dash=(value/total)*circ;
  el.innerHTML='<div style="position:relative;width:'+size+'px;height:'+size+'px;display:inline-flex;align-items:center;justify-content:center"><svg width="'+size+'" height="'+size+'" style="transform:rotate(-90deg)"><defs><linearGradient id="dg'+cid+'" x1="0%" y1="0%" x2="100%" y2="0%"><stop offset="0%" stop-color="'+c1+'"/><stop offset="100%" stop-color="'+c2+'"/></linearGradient></defs><circle cx="'+(size/2)+'" cy="'+(size/2)+'" r="'+r+'" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="10"/><circle cx="'+(size/2)+'" cy="'+(size/2)+'" r="'+r+'" fill="none" stroke="url(#dg'+cid+')" stroke-width="10" stroke-dasharray="'+dash+' '+circ+'" stroke-linecap="round" style="filter:drop-shadow(0 0 8px rgba(0,210,255,0.5));transition:stroke-dasharray 1s ease"/></svg><div style="position:absolute;text-align:center"><div style="font-family:Syne,sans-serif;font-size:22px;font-weight:800">'+value+'%</div><div style="font-size:11px;color:var(--text-2)">done</div></div></div>';
}

/* ── ANIMATE PROGRESS BARS ── */
function animateBars() {
  document.querySelectorAll('.progress-fill[data-pct]').forEach(function(el){
    setTimeout(function(){ el.style.width = el.dataset.pct+'%'; }, 300);
  });
}
document.addEventListener('DOMContentLoaded', animateBars);
</script>


<script>
/* ====== DEFAULT SUBJECTS ====== */
const defaultSubjects = [
  { name:'Engineering Mathematics III', credits:4, grade:'6' },
  { name:'Data Structures & Algorithms',  credits:4, grade:'7' },
  { name:'Digital Electronics',           credits:3, grade:'5' },
  { name:'Object Oriented Programming',   credits:3, grade:'8' },
  { name:'Computer Organization',         credits:3, grade:'6' },
  { name:'Discrete Mathematics',          credits:3, grade:'5' },
];

let subjectData = JSON.parse(JSON.stringify(defaultSubjects));
let planData = null;
let selectedTime = 'Morning';

function renderSubjects() {
  const c = document.getElementById('subjects-container');
  c.innerHTML = subjectData.map((s,i)=>`
    <div class="grade-row">
      <input class="grade-input" placeholder="Subject name" value="${s.name}"
        oninput="subjectData[${i}].name=this.value"/>
      <input class="grade-input" type="number" placeholder="Credits" value="${s.credits}" min="1" max="6"
        oninput="subjectData[${i}].credits=+this.value" style="text-align:center"/>
      <input class="grade-input" type="number" placeholder="Grade/Marks" value="${s.grade}" min="0" max="10" step="0.5"
        oninput="subjectData[${i}].grade=this.value" style="text-align:center"/>
      <button class="remove-btn" onclick="removeSubject(${i})">×</button>
    </div>`).join('');
}

function addSubjectRow() {
  subjectData.push({ name:'', credits:3, grade:'' });
  renderSubjects();
  setTimeout(()=>{ const inputs=document.querySelectorAll('.grade-input'); inputs[inputs.length-3].focus(); },50);
}

function removeSubject(i) {
  if (subjectData.length <= 2) { showToast('Minimum 2 subjects required', 'warn'); return; }
  subjectData.splice(i,1);
  renderSubjects();
}

function togglePref(btn) {
  document.querySelectorAll('#study-time-pref .tab-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  selectedTime = btn.textContent.replace(/[^a-zA-Z]/g,'');
}

function updateGradeOptions() {
  const sys = document.getElementById('grading-system').value;
  const ph = sys==='10'?'0–10 (e.g. 7)': sys==='4'?'0–4 (e.g. 3.5)':'0–100 (e.g. 72)';
  document.querySelectorAll('.grade-input[placeholder*="Grade"]').forEach(el=>el.placeholder=ph);
}

/* ====== CGPA CALCULATION ====== */
function gradeToPoints(grade, system) {
  const g = parseFloat(grade);
  if (isNaN(g)) return null;
  if (system === '10') return Math.min(10, Math.max(0, g));
  if (system === '4')  return Math.min(4, Math.max(0, g));
  if (system === 'percentage') return (g/10); // convert to 10-scale
  return g;
}

function calcSGPA(subjects, system) {
  let totalPoints=0, totalCredits=0;
  subjects.forEach(s=>{
    const pts = gradeToPoints(s.grade, system);
    if (pts!==null && s.credits>0) { totalPoints+=pts*s.credits; totalCredits+=s.credits; }
  });
  return totalCredits>0 ? totalPoints/totalCredits : 0;
}

function requiredNextSGPA(currentCGPA, targetCGPA, currentSem, totalSems) {
  // CGPA = (sum of all SGPAs) / total sems
  // targetCGPA * totalSemsCompleted = currentCGPA*(currentSem-1) + requiredSGPA
  const semsCompleted = currentSem - 1;
  const required = (targetCGPA * currentSem) - (currentCGPA * semsCompleted);
  return required;
}

function getDifficultyLabel(gap, scale) {
  const ratio = gap / scale;
  if (ratio <= 0) return { label:'Already Achieved! 🎉', color:'var(--emerald)', bg:'rgba(16,185,129,.1)' };
  if (ratio <= 0.05) return { label:'Very Easy 😊', color:'var(--emerald)', bg:'rgba(16,185,129,.1)' };
  if (ratio <= 0.1)  return { label:'Achievable 💪', color:'var(--cyan)',    bg:'rgba(0,210,255,.1)' };
  if (ratio <= 0.2)  return { label:'Moderate Effort 📚', color:'var(--amber)', bg:'rgba(245,158,11,.1)' };
  if (ratio <= 0.35) return { label:'Hard Push 🔥', color:'var(--rose)',    bg:'rgba(244,63,94,.1)' };
  return { label:'Very Challenging ⚡', color:'var(--rose)', bg:'rgba(244,63,94,.1)', warn:true };
}

function generatePlan() {
  const sys        = document.getElementById('grading-system').value;
  const currCGPA   = parseFloat(document.getElementById('current-cgpa').value) || 0;
  const lastSGPA   = parseFloat(document.getElementById('last-sgpa').value) || calcSGPA(subjectData, sys);
  const targetCGPA = parseFloat(document.getElementById('target-cgpa').value);
  const currentSem = parseInt(document.getElementById('current-sem').value);
  const totalSems  = parseInt(document.getElementById('total-sems').value);
  const dailyHours = parseFloat(document.getElementById('daily-hours').value) || 6;
  const weeksLeft  = parseInt(document.getElementById('weeks-to-exam').value) || 12;
  const scale      = sys === '4' ? 4 : sys === 'percentage' ? 10 : 10;

  if (!targetCGPA) { showToast('Please enter your target CGPA', 'warn'); return; }
  if (subjectData.filter(s=>s.grade).length < 2) { showToast('Please fill at least 2 subjects with grades', 'warn'); return; }

  // Calculate required next semester pointer
  const required = requiredNextSGPA(currCGPA||lastSGPA, targetCGPA, currentSem, totalSems);
  const reqClamped = Math.max(0, Math.min(scale, required));
  const gap = reqClamped - (lastSGPA || currCGPA);
  const diff = getDifficultyLabel(gap, scale);

  // Subject weakness analysis
  const analyzed = subjectData.filter(s=>s.grade).map(s=>{
    const pts = gradeToPoints(s.grade, sys) || 0;
    const normalized = pts / scale;
    return { ...s, pts, normalized,
      weakness: normalized < 0.5 ? 'critical' : normalized < 0.65 ? 'weak' : normalized < 0.8 ? 'moderate' : 'strong',
      priority: normalized < 0.5 ? 5 : normalized < 0.65 ? 4 : normalized < 0.8 ? 2 : 1,
    };
  }).sort((a,b)=>b.priority-a.priority);

  // Allocate study hours based on priority & credits
  const totalWeight = analyzed.reduce((s,sub)=>s+sub.priority*sub.credits,0);
  const totalStudyHours = dailyHours * weeksLeft * 7;
  analyzed.forEach(s=>{
    s.allocatedHours = Math.round((s.priority*s.credits/totalWeight)*totalStudyHours);
    s.dailyMinutes   = Math.round((s.priority*s.credits/totalWeight)*dailyHours*60);
  });

  planData = { required: reqClamped, currCGPA, targetCGPA, diff, analyzed, dailyHours, weeksLeft, sys, scale, lastSGPA };

  // Show result
  document.getElementById('right-placeholder').style.display = 'none';
  document.getElementById('result-panel').style.display = 'block';

  // Fill required pointer
  document.getElementById('required-pointer').textContent = reqClamped.toFixed(2);
  document.getElementById('pointer-label').textContent = `Required Semester ${currentSem} Pointer (out of ${scale})`;
  document.getElementById('difficulty-indicator').innerHTML = `<span class="need-tag" style="background:${diff.bg};color:${diff.color}">${diff.label}</span>`;
  document.getElementById('curr-lbl').textContent = `Current CGPA: ${(currCGPA||lastSGPA).toFixed(2)}`;
  document.getElementById('tgt-lbl').textContent  = `Target: ${targetCGPA}`;
  setTimeout(()=>{
    document.getElementById('pointer-progress').style.width = Math.min(100, ((currCGPA||lastSGPA)/scale)*100) + '%';
  }, 400);

  if (diff.warn) {
    showToast('⚠️ This target is very challenging. Consider adjusting gradually!', 'warn');
  }

  renderSubjectAnalysis(analyzed, scale);
  renderDailyPlan(analyzed, dailyHours, weeksLeft);
  renderWeeklyPlan(analyzed, dailyHours);
  renderAITips(analyzed, gap, diff, dailyHours, weeksLeft);

  DB.set('cgpa_plan', planData);

  // Also save to backend
  const semLabel = document.getElementById('semester-label')?.value || 'Current Semester';
  const subjects_payload = rows.filter(r=>r.name&&r.grade).map(r=>({ name:r.name, credits:r.credits||3, grade:r.grade }));
  API.saveCGPA({ semester_label: semLabel, subjects: subjects_payload });
}

const weakColors = {
  critical:{ color:'var(--rose)',    bg:'rgba(244,63,94,.1)',   label:'Critical – Need Major Improvement' },
  weak:    { color:'var(--amber)',   bg:'rgba(245,158,11,.1)',  label:'Weak – Needs Extra Time' },
  moderate:{ color:'var(--cyan)',    bg:'rgba(0,210,255,.1)',   label:'Moderate – Regular Revision' },
  strong:  { color:'var(--emerald)', bg:'rgba(16,185,129,.1)',  label:'Strong – Maintain & Revise' },
};

function renderSubjectAnalysis(subjects, scale) {
  document.getElementById('subject-analysis').innerHTML = subjects.map(s=>{
    const wc = weakColors[s.weakness];
    const pct = Math.round(s.normalized*100);
    const targetPct = Math.min(100, pct + (100-pct)*0.6);
    return `
      <div style="padding:12px 0;border-bottom:1px solid var(--border)">
        <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:8px">
          <div>
            <div style="font-size:14px;font-weight:600">${s.name}</div>
            <div style="font-size:12px;color:var(--text-2);margin-top:2px">${s.credits} Credits · Grade: ${s.grade}/${scale}</div>
          </div>
          <span class="difficulty-pill" style="background:${wc.bg};color:${wc.color}">${wc.label}</span>
        </div>
        <div style="margin-bottom:6px">
          <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:4px">
            <span style="color:var(--text-2)">Current Performance</span>
            <span style="color:${wc.color};font-weight:600">${pct}%</span>
          </div>
          <div class="progress-track">
            <div class="progress-fill" style="width:${pct}%;--pfrom:${wc.color};--pto:${wc.color}88"></div>
          </div>
        </div>
        <div style="display:flex;align-items:center;gap:8px;margin-top:8px">
          <span style="font-size:12px;color:var(--text-2)">Recommended:</span>
          <span class="hours-badge" style="color:${wc.color};border-color:${wc.color}44">
            ${Math.floor(s.dailyMinutes/60)}h ${s.dailyMinutes%60}m / day
          </span>
          <span style="font-size:11px;color:var(--text-2)">${s.allocatedHours}h total over exam prep</span>
        </div>
      </div>`;
  }).join('');
}

function renderDailyPlan(subjects, dailyHours, weeksLeft) {
  const sessions = subjects.map(s=>({
    name: s.name.length>25 ? s.name.slice(0,25)+'…' : s.name,
    fullName: s.name,
    minutes: s.dailyMinutes,
    hours: (s.dailyMinutes/60).toFixed(1),
    color: weakColors[s.weakness].color,
    bg: weakColors[s.weakness].bg,
    weakness: s.weakness,
  }));

  const prefTime = document.querySelector('#study-time-pref .tab-btn.active')?.textContent.replace(/[^a-zA-Z]/g,'') || 'Morning';
  const timeSlots = { Morning:['7:00','9:00','11:00','1:00','3:00'], Afternoon:['12:00','2:00','4:00','6:00','8:00'], Evening:['4:00','6:00','8:00','10:00','12:00'], Night:['8:00','10:00','12:00','2:00','4:00'] };
  const slots = timeSlots[prefTime] || timeSlots.Morning;

  document.getElementById('plan-daily').innerHTML = `
    <div style="background:var(--surface2);border-radius:12px;padding:16px;margin-bottom:12px;border:1px solid var(--border)">
      <div style="font-size:13px;color:var(--text-2);margin-bottom:12px">📋 Daily Schedule Template (${dailyHours}h/day · ${prefTime} Focus)</div>
      ${sessions.map((s,i)=>`
        <div style="display:flex;gap:12px;padding:10px 0;${i<sessions.length-1?'border-bottom:1px solid var(--border)':''}">
          <div style="font-size:12px;color:var(--text-3);width:50px;flex-shrink:0;padding-top:2px">${slots[i%slots.length] || `${8+i}:00`}</div>
          <div style="flex:1;border-left:3px solid ${s.color};padding-left:12px;background:${s.bg};border-radius:0 8px 8px 0;padding:8px 12px">
            <div style="font-size:13px;font-weight:600;color:${s.color}">${s.fullName}</div>
            <div style="font-size:12px;color:var(--text-2);margin-top:2px">⏱ ${s.hours}h · Focus on ${s.weakness==='critical'?'fundamentals & practice':s.weakness==='weak'?'problem-solving':s.weakness==='moderate'?'revision & past papers':'maintenance revision'}</div>
          </div>
        </div>`).join('')}
    </div>
    <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px">
      <div style="background:var(--surface2);border-radius:10px;padding:14px;border:1px solid var(--border);text-align:center">
        <div style="font-family:'Syne',sans-serif;font-weight:800;font-size:22px;color:var(--cyan)">${dailyHours}h</div>
        <div style="font-size:12px;color:var(--text-2)">Daily Target</div>
      </div>
      <div style="background:var(--surface2);border-radius:10px;padding:14px;border:1px solid var(--border);text-align:center">
        <div style="font-family:'Syne',sans-serif;font-weight:800;font-size:22px;color:var(--violet)">${weeksLeft}w</div>
        <div style="font-size:12px;color:var(--text-2)">Prep Time</div>
      </div>
      <div style="background:var(--surface2);border-radius:10px;padding:14px;border:1px solid var(--border);text-align:center">
        <div style="font-family:'Syne',sans-serif;font-weight:800;font-size:22px;color:var(--emerald)">${(dailyHours*weeksLeft*7).toFixed(0)}h</div>
        <div style="font-size:12px;color:var(--text-2)">Total Hours</div>
      </div>
    </div>`;
}

function renderWeeklyPlan(subjects, dailyHours) {
  const days = ['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'];
  const dayHours = [1,1,1,1,1,0.5,0.5].map(f=>dailyHours*f);
  const weekPlan = days.map((day,di)=>{
    const available = dayHours[di]*60;
    let remaining = available, sessions=[];
    subjects.forEach(s=>{
      if (remaining <= 5) return;
      const alloc = Math.min(s.dailyMinutes, remaining);
      if (alloc > 10) { sessions.push({...s, alloc}); remaining -= alloc; }
    });
    return { day, sessions, total: Math.round((available-remaining)/60*10)/10 };
  });

  const colorMap = { critical:'var(--rose)', weak:'var(--amber)', moderate:'var(--cyan)', strong:'var(--emerald)' };
  document.getElementById('plan-weekly').innerHTML = weekPlan.map((d,i)=>`
    <div style="margin-bottom:8px">
      <div class="plan-day-header" onclick="toggleDay(${i})">
        <span style="font-size:16px">${['🔵','🟣','🟡','🔴','🟢','⚪','🔵'][i]}</span>
        <div style="flex:1">
          <div style="font-size:14px;font-weight:600">${d.day}</div>
          <div style="font-size:12px;color:var(--text-2)">${d.sessions.length} subjects · ${d.total}h planned</div>
        </div>
        <span style="font-size:12px;color:var(--cyan)">▼</span>
      </div>
      <div class="plan-day-content" id="day-${i}">
        ${d.sessions.map(s=>`
          <div class="subject-plan-row">
            <div style="width:4px;height:40px;background:${colorMap[s.weakness]||'var(--cyan)'};border-radius:2px;flex-shrink:0"></div>
            <div style="flex:1">
              <div style="font-size:13px;font-weight:600">${s.fullName}</div>
              <div style="font-size:12px;color:var(--text-2);margin-top:2px">${s.weakness==='critical'?'📌 Practice problems + concept clarity':s.weakness==='weak'?'📖 Formula revision + mock questions':s.weakness==='moderate'?'✍️ Revision + past papers':'⚡ Quick revision only'}</div>
            </div>
            <span class="hours-badge">${Math.floor(s.alloc/60)}h ${s.alloc%60}m</span>
          </div>`).join('')}
      </div>
    </div>`).join('');
}

function toggleDay(i) {
  const el = document.getElementById('day-'+i);
  el.classList.toggle('open');
}

function renderAITips(subjects, gap, diff, dailyHours, weeksLeft) {
  const critical = subjects.filter(s=>s.weakness==='critical');
  const weak     = subjects.filter(s=>s.weakness==='weak');
  const strong   = subjects.filter(s=>s.weakness==='strong');

  const tips = [
    { icon:'🎯', color:'var(--cyan)',    title:'Your #1 Priority',
      desc: critical.length ? `Focus 40% of your time on: <strong>${critical.map(s=>s.name).join(', ')}</strong>. These subjects have the highest impact on your CGPA improvement.` : 'Your performance is balanced. Focus on consistency across all subjects.' },
    { icon:'⏰', color:'var(--violet)',  title:'Optimal Study Schedule',
      desc:`Study ${dailyHours}h daily. Split sessions: 90 min focused + 10 min break (Pomodoro). ${dailyHours>=6 ? 'Your hours are excellent.' : 'Try adding 1-2 more hours on weekends.'}` },
    { icon:'📝', color:'var(--amber)',   title:'Past Paper Strategy',
      desc:`Spend last ${Math.max(2,Math.round(weeksLeft*0.25))} weeks exclusively on past exam papers. Solve minimum 5 years of papers per subject. This alone can improve your grade by 1-2 points.` },
    { icon:'🔄', color:'var(--emerald)', title:'Spaced Repetition',
      desc:`Revise each topic after: 1 day → 3 days → 7 days → 14 days. Use this for ${weak.length>0?weak.map(s=>s.name).slice(0,2).join(' and '):'all subjects'} especially.` },
    { icon:'💪', color:'var(--rose)',    title:'Weak Subject Recovery',
      desc: weak.length+critical.length > 0 ? `For ${[...critical,...weak].map(s=>s.name.split(' ')[0]).slice(0,3).join(', ')}: Start from basics, watch concept videos, then practice. Don't skip fundamentals.` : 'Great! No critical weak subjects. Maintain your strong subjects with weekly revision.' },
    { icon:'🌙', color:'var(--cyan)',    title:'Study-Sleep Balance',
      desc:`Sleep 7-8 hours minimum. Memory consolidation happens during sleep. Late-night cramming is 40% less effective. Schedule difficult subjects for your peak focus time.` },
  ];

  if (strong.length > 0) {
    tips.push({ icon:'⭐', color:'var(--emerald)', title:'Leverage Your Strengths',
      desc:`${strong.map(s=>s.name.split(' ')[0]).join(', ')} are your strong subjects. Spend only 15% time here – use saved time to boost weak subjects.` });
  }

  document.getElementById('plan-tips').innerHTML = tips.map(t=>`
    <div class="plan-item">
      <div class="plan-item-icon" style="background:${t.color}18">${t.icon}</div>
      <div>
        <div style="font-size:14px;font-weight:600;margin-bottom:4px">${t.title}</div>
        <div style="font-size:13px;color:var(--text-2);line-height:1.6">${t.desc}</div>
      </div>
    </div>`).join('');
}

function switchPlanView(view, btn) {
  ['daily','weekly','tips'].forEach(v=>{
    document.getElementById('plan-'+v).style.display = v===view?'block':'none';
  });
  document.querySelectorAll('.cgpa-card .tab-btn').forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
}

function saveToSchedule() {
  if (!planData) { showToast('Generate a plan first!', 'warn'); return; }
  showToast('Plan saved! Opening Schedule page...', 'success');
  setTimeout(()=>window.location.href='schedule.php', 1000);
}

function printPlan() { window.print(); }

requireAuth().then(() => renderSubjects());
</script>
</body>
</html>
