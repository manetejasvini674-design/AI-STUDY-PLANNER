// =====================================================
// StudyAI - API Client (shared across all pages)
// File: js/api.js
// =====================================================

const API = {
  base: 'api/',

  async request(endpoint, method = 'GET', body = null) {
    const opts = {
      method,
      credentials: 'include',
      headers: { 'Content-Type': 'application/json' }
    };
    if (body) opts.body = JSON.stringify(body);
    try {
      const res = await fetch(API.base + endpoint, opts);
      const data = await res.json();
      if (res.status === 401) {
        window.location.href = 'login.php';
        return null;
      }
      return data;
    } catch (e) {
      console.error('API Error:', e);
      showToast('Network error. Please check connection.', 'error');
      return null;
    }
  },

  // Auth
  login:    (d)  => API.request('auth.php?action=login', 'POST', d),
  register: (d)  => API.request('auth.php?action=register', 'POST', d),
  logout:   ()   => API.request('auth.php?action=logout', 'POST'),
  checkAuth:()   => API.request('auth.php?action=check'),

  // Dashboard
  getDashboard: () => API.request('dashboard.php'),

  // Tasks
  getTasks:    (s)    => API.request('tasks.php' + (s ? `?status=${s}` : '')),
  createTask:  (d)    => API.request('tasks.php', 'POST', d),
  updateTask:  (d)    => API.request('tasks.php', 'PUT', d),
  deleteTask:  (id)   => API.request(`tasks.php?id=${id}`, 'DELETE'),

  // Schedule
  getSchedule:      (date) => API.request(`schedule.php?date=${date}`),
  getWeekSchedule:  ()     => API.request('schedule.php?week=1'),
  generateSchedule: ()     => API.request('schedule.php?action=generate', 'POST', {}),
  completeSession:  (id)   => API.request('schedule.php', 'PUT', { id }),
  clearSchedule:    ()     => API.request('schedule.php', 'DELETE'),

  // Analytics
  getAnalytics: () => API.request('analytics.php?type=overview'),
  logSession:   (d) => API.request('analytics.php', 'POST', d),

  // Notifications
  getNotifications: () => API.request('notifications.php'),
  markRead:     (id)  => API.request('notifications.php', 'PUT', { id }),
  markAllRead:  ()    => API.request('notifications.php', 'PUT', {}),
  deleteNotif:  (id)  => API.request(`notifications.php?id=${id}`, 'DELETE'),
  clearNotifs:  ()    => API.request('notifications.php', 'DELETE'),

  // Profile
  getProfile:   ()  => API.request('profile.php'),
  setupProfile: (d) => API.request('profile.php?action=setup', 'POST', d),
  updateProfile:(d) => API.request('profile.php', 'PUT', d),
  deleteSubject:(id)=> API.request(`profile.php?id=${id}`, 'DELETE'),
  addSubject:   (d) => API.request('profile.php?action=add_subject', 'POST', d),

  // CGPA
  getCGPA:  (sem) => API.request('cgpa.php' + (sem ? `?semester=${sem}` : '')),
  saveCGPA: (d)   => API.request('cgpa.php', 'POST', d),
  deleteCGPA:(id) => API.request(`cgpa.php?id=${id}`, 'DELETE'),

  // Career Guide – AI powered
  getCareerData:    ()  => API.request('career.php?action=student_data'),
  analyzeCareer:    (d) => API.request('career.php', 'POST', { type: 'full',    extra: d || {} }),
  generateRoadmap:  (d) => API.request('career.php', 'POST', { type: 'roadmap', extra: d || {} }),
  careerChat:       (d) => API.request('career.php', 'POST', { type: 'chat',    extra: d || {} }),
  careerQuiz:       (d) => API.request('career.php', 'POST', { type: 'full',    extra: d || {} }),
};

// ── GLOBAL TOAST ──────────────────────────────────────
function showToast(msg, type = 'success') {
  const colors = { success:'#10b981', error:'#f43f5e', info:'#00d2ff', warn:'#f59e0b' };
  const c = colors[type] || colors.success;
  const t = document.createElement('div');
  t.style.cssText = `position:fixed;bottom:24px;right:24px;background:#0d1117;border:1px solid ${c};color:#f0f4f8;padding:12px 20px;border-radius:12px;font-size:14px;z-index:9999;animation:fadeUp .3s ease;box-shadow:0 8px 30px rgba(0,0,0,.5);max-width:340px;border-left:3px solid ${c};font-family:'DM Sans',sans-serif;`;
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => { t.style.opacity='0'; t.style.transition='opacity .3s'; setTimeout(()=>t.remove(),300); }, 3000);
}

// ── USER INFO POPULATOR ───────────────────────────────
function populateUserInfo(user) {
  if (!user) return;
  const name     = user.name || 'Student';
  const initials = user.avatar_initials || user.initials || name.split(' ').map(w=>w[0]).join('').toUpperCase().slice(0,2);
  const role     = user.course || user.semester || 'Student';
  ['user-name-el','user-name'].forEach(id => {
    const el = document.getElementById(id); if (el) el.textContent = name;
  });
  ['user-role-el','user-role'].forEach(id => {
    const el = document.getElementById(id); if (el) el.textContent = role;
  });
  ['user-avatar','topbar-avatar'].forEach(id => {
    const el = document.getElementById(id); if (el) el.textContent = initials;
  });
  // Store in sessionStorage for quick access
  sessionStorage.setItem('studyai_user', JSON.stringify(user));
}

// ── AUTH GUARD (call on protected pages) ─────────────
async function requireAuth() {
  // Check session storage first (fast)
  const cached = sessionStorage.getItem('studyai_user');
  if (cached) {
    try { populateUserInfo(JSON.parse(cached)); } catch(e){}
  }
  // Verify with server
  const res = await API.checkAuth();
  if (!res || !res.loggedIn) {
    window.location.href = 'login.php';
    return null;
  }
  populateUserInfo(res.user);
  return res.user;
}

// ── MINI LINE CHART ───────────────────────────────────
function renderMiniChart(cid, data, color, height) {
  color = color || '#00d2ff'; height = height || 70;
  const el = document.getElementById(cid); if (!el) return;
  const w = el.clientWidth || 300, h = height;
  const max = Math.max(...data), min = Math.min(...data);
  const pts = data.map((v,i) => {
    const x = (i/(data.length-1))*w;
    const y = h - ((v-min)/(max-min||1))*(h-10) - 5;
    return `${x},${y}`;
  }).join(' ');
  const dots = data.map((v,i) => {
    const x=(i/(data.length-1))*w, y=h-((v-min)/(max-min||1))*(h-10)-5;
    return `<circle cx="${x}" cy="${y}" r="3" fill="${color}" style="filter:drop-shadow(0 0 4px ${color})"/>`;
  }).join('');
  el.innerHTML = `<svg viewBox="0 0 ${w} ${h}" width="100%" height="${h}" preserveAspectRatio="none">
    <defs><linearGradient id="cg${cid}" x1="0" y1="0" x2="0" y2="1">
    <stop offset="0%" stop-color="${color}" stop-opacity="0.3"/>
    <stop offset="100%" stop-color="${color}" stop-opacity="0"/>
    </linearGradient></defs>
    <polygon points="0,${h} ${pts} ${w},${h}" fill="url(#cg${cid})"/>
    <polyline points="${pts}" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="filter:drop-shadow(0 0 6px ${color})"/>
    ${dots}</svg>`;
}

// ── BAR CHART ─────────────────────────────────────────
function renderBarChart(cid, data, maxVal) {
  const el = document.getElementById(cid); if (!el) return;
  const max = maxVal || Math.max(...data.map(d=>d.value||d.hours||0), 1);
  el.innerHTML = data.map(d => {
    const val = d.value || d.hours || 0;
    const pct = Math.round((val / max) * 100);
    const isToday = d.isToday || false;
    return `<div style="display:flex;flex-direction:column;align-items:center;gap:4px;flex:1">
      <div style="font-size:11px;color:var(--text-2)">${val}h</div>
      <div style="width:100%;background:var(--surface2);border-radius:6px;height:${el.style.height||'120px'};display:flex;align-items:flex-end">
        <div style="width:100%;height:${pct}%;background:${isToday?'linear-gradient(180deg,var(--cyan),var(--violet))':'rgba(0,210,255,.3)'};border-radius:6px;transition:height 1s ease;${isToday?'box-shadow:0 0 12px rgba(0,210,255,.4)':''}"></div>
      </div>
      <div style="font-size:11px;color:${isToday?'var(--cyan)':'var(--text-3)'};font-weight:${isToday?700:400}">${d.day||d.label||''}</div>
    </div>`;
  }).join('');
}

// ── DONUT CHART ───────────────────────────────────────
function renderDonut(cid, value, total, size, c1, c2) {
  total=total||100; size=size||120; c1=c1||'#00d2ff'; c2=c2||'#7c3aed';
  const el=document.getElementById(cid); if(!el) return;
  const r=(size-14)/2, circ=2*Math.PI*r, dash=(value/total)*circ;
  el.innerHTML=`<div style="position:relative;width:${size}px;height:${size}px;display:inline-flex;align-items:center;justify-content:center">
    <svg width="${size}" height="${size}" style="transform:rotate(-90deg)">
      <defs><linearGradient id="dg${cid}" x1="0%" y1="0%" x2="100%" y2="0%">
        <stop offset="0%" stop-color="${c1}"/><stop offset="100%" stop-color="${c2}"/></linearGradient></defs>
      <circle cx="${size/2}" cy="${size/2}" r="${r}" fill="none" stroke="rgba(255,255,255,0.05)" stroke-width="10"/>
      <circle cx="${size/2}" cy="${size/2}" r="${r}" fill="none" stroke="url(#dg${cid})" stroke-width="10"
        stroke-dasharray="${dash} ${circ}" stroke-linecap="round"
        style="filter:drop-shadow(0 0 8px rgba(0,210,255,0.5));transition:stroke-dasharray 1s ease"/>
    </svg>
    <div style="position:absolute;text-align:center">
      <div style="font-family:'Syne',sans-serif;font-size:22px;font-weight:800">${value}%</div>
      <div style="font-size:11px;color:var(--text-2)">done</div>
    </div></div>`;
}

// ── ANIMATE PROGRESS BARS ─────────────────────────────
function animateBars() {
  document.querySelectorAll('.progress-fill[data-pct]').forEach(el => {
    setTimeout(() => el.style.width = el.dataset.pct + '%', 300);
  });
}
document.addEventListener('DOMContentLoaded', animateBars);

// ── LOGOUT HANDLER ────────────────────────────────────
async function handleLogout() {
  await API.logout();
  sessionStorage.clear();
  window.location.href = 'login.php';
}

// ── DATE HELPERS ──────────────────────────────────────
function formatDate(d) {
  if (!d) return '';
  return new Date(d).toLocaleDateString('en-US', { month:'short', day:'numeric', year:'numeric' });
}
function formatTime(t) {
  if (!t) return '';
  const [h,m] = t.split(':');
  const hr = parseInt(h);
  return `${hr > 12 ? hr-12 : hr || 12}:${m} ${hr >= 12 ? 'PM' : 'AM'}`;
}
function daysLeft(dateStr) {
  if (!dateStr) return null;
  const diff = new Date(dateStr) - new Date();
  return Math.ceil(diff / (1000*60*60*24));
}
