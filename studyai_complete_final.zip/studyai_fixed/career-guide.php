<?php
require_once __DIR__ . "/config.php";
startSession();
if (!isset($_SESSION["user_id"])) { header("Location: login.php"); exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width,initial-scale=1.0"/>
  <title>Career Guide – StudyAI</title>
  <style>
@import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;500;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;1,9..40,300&display=swap');
*{margin:0;padding:0;box-sizing:border-box;}
:root{--bg:#060910;--surface:#0d1117;--surface2:#111827;--border:rgba(255,255,255,0.06);--border-glow:rgba(0,210,255,0.2);--cyan:#00d2ff;--cyan-dim:rgba(0,210,255,0.12);--violet:#7c3aed;--violet-dim:rgba(124,58,237,0.15);--emerald:#10b981;--amber:#f59e0b;--rose:#f43f5e;--text:#f0f4f8;--text-2:#8b9db5;--text-3:#4a5568;}
body{background:var(--bg);color:var(--text);font-family:'DM Sans',sans-serif;overflow-x:hidden;}
::-webkit-scrollbar{width:4px;}::-webkit-scrollbar-track{background:var(--surface);}::-webkit-scrollbar-thumb{background:var(--cyan);border-radius:4px;}
@keyframes fadeUp{from{opacity:0;transform:translateY(24px)}to{opacity:1;transform:translateY(0)}}
@keyframes fadeIn{from{opacity:0}to{opacity:1}}
@keyframes float{0%,100%{transform:translateY(0)}50%{transform:translateY(-8px)}}
@keyframes glowPulse{0%,100%{box-shadow:0 0 20px rgba(0,210,255,.1)}50%{box-shadow:0 0 40px rgba(0,210,255,.3)}}
@keyframes bounce{0%,80%,100%{transform:scale(.6);opacity:.5}40%{transform:scale(1);opacity:1}}
@keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}}
.fade-up{animation:fadeUp .6s ease forwards;}.fade-up-1{animation:fadeUp .6s .1s ease forwards;opacity:0;}.fade-up-2{animation:fadeUp .6s .2s ease forwards;opacity:0;}.fade-up-3{animation:fadeUp .6s .3s ease forwards;opacity:0;}
.app{display:flex;min-height:100vh;}
.sidebar{width:240px;min-height:100vh;background:var(--surface);border-right:1px solid var(--border);display:flex;flex-direction:column;position:fixed;left:0;top:0;bottom:0;z-index:100;}
.sidebar-logo{padding:26px 20px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:12px;}
.logo-icon{width:38px;height:38px;background:linear-gradient(135deg,var(--cyan),var(--violet));border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:18px;animation:float 3s ease-in-out infinite;flex-shrink:0;text-decoration:none;}
.logo-text{font-family:'Syne',sans-serif;font-weight:800;font-size:16px;background:linear-gradient(90deg,var(--cyan),var(--violet));-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text;}
.logo-sub{font-size:10px;color:var(--text-3);margin-top:1px;}
.sidebar-nav{flex:1;padding:14px 10px;display:flex;flex-direction:column;gap:3px;overflow-y:auto;}
.sidebar-nav::-webkit-scrollbar{width:2px;}
.nav-section-label{font-size:10px;font-weight:700;letter-spacing:.12em;color:var(--text-3);padding:10px 12px 5px;text-transform:uppercase;}
.nav-item{display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:10px;cursor:pointer;transition:all .2s;color:var(--text-2);font-size:13.5px;font-weight:400;position:relative;border:1px solid transparent;text-decoration:none;}
.nav-item:hover{background:var(--cyan-dim);color:var(--text);border-color:var(--border-glow);}
.nav-item-active{background:linear-gradient(135deg,rgba(0,210,255,.15),rgba(124,58,237,.1))!important;color:var(--cyan)!important;border-color:rgba(0,210,255,.25)!important;box-shadow:inset 0 0 20px rgba(0,210,255,.05);}
.nav-active-bar{position:absolute;left:0;top:50%;transform:translateY(-50%);width:3px;height:60%;background:var(--cyan);border-radius:0 2px 2px 0;}
.nav-icon{width:20px;height:20px;flex-shrink:0;display:flex;align-items:center;justify-content:center;font-size:15px;}
.nav-label{flex:1;}.nav-badge{margin-left:auto;background:var(--rose);color:#fff;font-size:10px;font-weight:700;padding:2px 7px;border-radius:20px;min-width:20px;text-align:center;}
.sidebar-footer{padding:14px 10px;border-top:1px solid var(--border);}
.user-card{display:flex;align-items:center;gap:10px;padding:10px 12px;background:var(--surface2);border-radius:10px;border:1px solid var(--border);cursor:pointer;transition:all .2s;}
.user-card:hover{border-color:var(--border-glow);}
.avatar{width:34px;height:34px;border-radius:50%;background:linear-gradient(135deg,var(--cyan),var(--violet));display:flex;align-items:center;justify-content:center;font-weight:700;font-size:13px;color:#fff;flex-shrink:0;}
.user-name{font-size:13px;font-weight:500;color:var(--text);}.user-role{font-size:11px;color:var(--text-2);}
.main{margin-left:240px;flex:1;min-height:100vh;}
.topbar{height:64px;background:rgba(13,17,23,.9);backdrop-filter:blur(20px);border-bottom:1px solid var(--border);display:flex;align-items:center;padding:0 28px;gap:16px;position:sticky;top:0;z-index:50;}
.topbar-title{font-family:'Syne',sans-serif;font-weight:700;font-size:18px;flex:1;}
.topbar-actions{display:flex;align-items:center;gap:10px;}
.icon-btn{width:38px;height:38px;border-radius:10px;border:1px solid var(--border);background:var(--surface2);display:flex;align-items:center;justify-content:center;cursor:pointer;transition:all .2s;color:var(--text-2);position:relative;text-decoration:none;}
.icon-btn:hover{border-color:var(--border-glow);color:var(--cyan);box-shadow:0 0 20px rgba(0,210,255,.15);}
.notif-dot{position:absolute;top:7px;right:7px;width:7px;height:7px;background:var(--rose);border-radius:50%;border:1.5px solid var(--surface);}
.page{padding:32px;animation:fadeIn .4s ease;}
.card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:24px;transition:all .3s;}
.card:hover{border-color:rgba(0,210,255,.15);box-shadow:0 4px 30px rgba(0,0,0,.3);}
.btn-primary{background:linear-gradient(135deg,var(--cyan),var(--violet));border:none;color:#fff;padding:10px 20px;border-radius:10px;cursor:pointer;font-size:14px;font-weight:500;font-family:'DM Sans',sans-serif;transition:all .2s;box-shadow:0 4px 15px rgba(0,210,255,.2);display:inline-flex;align-items:center;gap:6px;}
.btn-primary:hover{transform:translateY(-1px);box-shadow:0 6px 25px rgba(0,210,255,.35);}
.btn-secondary{background:var(--surface2);border:1px solid var(--border);color:var(--text);padding:10px 20px;border-radius:10px;cursor:pointer;font-size:14px;font-family:'DM Sans',sans-serif;transition:all .2s;display:inline-flex;align-items:center;gap:6px;}
.btn-secondary:hover{border-color:var(--border-glow);color:var(--cyan);}
.btn-sm{padding:6px 14px;font-size:12px;border-radius:8px;}
.select-field{background:var(--surface2);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:14px;font-family:'DM Sans',sans-serif;transition:all .2s;outline:none;appearance:none;cursor:pointer;}
.select-field:focus{border-color:var(--border-glow);}
select option{background:var(--surface2);color:var(--text);}
.input-field{width:100%;background:var(--surface2);border:1px solid var(--border);border-radius:10px;padding:10px 14px;color:var(--text);font-size:14px;font-family:'DM Sans',sans-serif;transition:all .2s;outline:none;}
.input-field:focus{border-color:var(--border-glow);box-shadow:0 0 0 3px rgba(0,210,255,.08);}
.input-field::placeholder{color:var(--text-3);}
.ai-thinking{display:flex;gap:4px;align-items:center;}
.ai-dot{width:8px;height:8px;border-radius:50%;background:var(--cyan);animation:bounce 1.2s ease-in-out infinite;}
.ai-dot:nth-child(2){animation-delay:.2s;background:var(--violet);}
.ai-dot:nth-child(3){animation-delay:.4s;background:#ff6b9d;}
.cg-hero{background:linear-gradient(135deg,rgba(0,210,255,.06),rgba(124,58,237,.06));border:1px solid rgba(0,210,255,.15);border-radius:20px;padding:36px;margin-bottom:24px;position:relative;overflow:hidden;}
.cg-hero::before{content:'';position:absolute;right:-60px;top:-60px;width:280px;height:280px;background:radial-gradient(circle,rgba(0,210,255,.08) 0%,transparent 70%);border-radius:50%;}
.track-card{background:var(--surface);border:1px solid var(--border);border-radius:16px;padding:24px;transition:all .3s;cursor:pointer;position:relative;overflow:hidden;}
.track-card::after{content:'';position:absolute;bottom:0;left:0;right:0;height:3px;background:var(--tc,var(--cyan));transform:scaleX(0);transition:transform .3s;transform-origin:left;}
.track-card:hover{border-color:var(--tc,var(--border-glow));transform:translateY(-3px);box-shadow:0 12px 40px rgba(0,0,0,.35);}
.track-card:hover::after{transform:scaleX(1);}
.skill-tag{display:inline-flex;align-items:center;padding:4px 10px;border-radius:6px;font-size:11px;font-weight:600;margin:3px;}
.salary-badge{display:inline-flex;align-items:center;gap:4px;padding:6px 12px;border-radius:8px;font-size:12px;font-weight:700;}
.roadmap-step{display:flex;gap:16px;padding:16px 0;border-bottom:1px solid var(--border);}
.roadmap-step:last-child{border-bottom:none;}
.step-num{width:36px;height:36px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-weight:800;font-size:14px;flex-shrink:0;font-family:'Syne',sans-serif;}
.step-line{position:absolute;left:17px;top:52px;bottom:0;width:2px;background:var(--border);}
.resource-row{display:flex;align-items:center;gap:14px;padding:12px 14px;background:var(--surface2);border-radius:10px;border:1px solid var(--border);margin-bottom:8px;transition:all .2s;text-decoration:none;}
.resource-row:hover{border-color:var(--border-glow);}
.tab-nav{display:flex;gap:8px;margin-bottom:20px;flex-wrap:wrap;}
.tab-btn-cg{padding:9px 18px;border-radius:10px;border:1px solid var(--border);background:var(--surface2);color:var(--text-2);cursor:pointer;font-size:13px;font-family:'DM Sans',sans-serif;transition:all .2s;}
.tab-btn-cg.active{background:linear-gradient(135deg,rgba(0,210,255,.15),rgba(124,58,237,.1));color:var(--cyan);border-color:rgba(0,210,255,.3);}
.quiz-opt{display:flex;align-items:center;gap:12px;padding:14px 16px;background:var(--surface2);border:1px solid var(--border);border-radius:10px;margin-bottom:8px;cursor:pointer;transition:all .2s;font-size:14px;}
.quiz-opt:hover{border-color:var(--border-glow);background:var(--cyan-dim);}
.demand-bar{height:8px;border-radius:20px;background:var(--surface2);overflow:hidden;margin-top:4px;}
.demand-fill{height:100%;border-radius:20px;transition:width 1.2s ease;}
.chat-bubble-ai{background:var(--surface2);border:1px solid var(--border);border-radius:14px 14px 14px 4px;padding:12px 16px;max-width:85%;font-size:14px;line-height:1.6;color:var(--text-2);}
.chat-bubble-user{background:linear-gradient(135deg,var(--cyan),var(--violet));color:#fff;border-radius:14px 14px 4px 14px;padding:10px 16px;max-width:80%;font-size:14px;line-height:1.5;}
.fav-banner{background:linear-gradient(135deg,rgba(245,158,11,.07),rgba(236,72,153,.05));border:1px solid rgba(245,158,11,.2);border-radius:16px;padding:20px 24px;margin-bottom:20px;}
.mob-toggle{display:none;position:fixed;top:15px;left:14px;z-index:200;background:var(--surface);border:1px solid var(--border);border-radius:8px;width:38px;height:38px;flex-direction:column;align-items:center;justify-content:center;gap:5px;cursor:pointer;padding:0;}
.mob-toggle span{display:block;width:18px;height:2px;background:var(--text-2);border-radius:2px;}
.mob-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:99;}
@media(max-width:768px){
  .sidebar{transform:translateX(-100%);transition:transform .3s ease;}
  .sidebar.mob-open{transform:translateX(0);}
  .mob-toggle{display:flex;}
  .main{margin-left:0!important;}
  .page{padding:16px;}
  .rg2{grid-template-columns:1fr!important;}
}
  </style>
</head>
<body>
<div class="app">

<!-- ════ SIDEBAR ════ -->
<aside class="sidebar" id="main-sidebar">
  <div class="sidebar-logo">
    <a href="dashboard.php" class="logo-icon">🧠</a>
    <div><div class="logo-text">StudyAI</div><div class="logo-sub">Smart Learning</div></div>
  </div>
  <nav class="sidebar-nav">
    <div class="nav-section-label">MAIN</div>
    <a href="dashboard.php" class="nav-item"><span class="nav-icon">🏠</span><span class="nav-label">Dashboard</span></a>
    <a href="schedule.php"  class="nav-item"><span class="nav-icon">📅</span><span class="nav-label">AI Schedule</span></a>
    <a href="tasks.php"     class="nav-item"><span class="nav-icon">✅</span><span class="nav-label">Tasks</span></a>
    <a href="timer.php"     class="nav-item"><span class="nav-icon">⏱️</span><span class="nav-label">Study Timer</span></a>
    <a href="analytics.php" class="nav-item"><span class="nav-icon">📊</span><span class="nav-label">Analytics</span></a>
    <a href="cgpa-planner.php" class="nav-item" style="background:linear-gradient(135deg,rgba(0,210,255,.08),rgba(124,58,237,.08));border-color:rgba(0,210,255,.15);">
      <span class="nav-icon">🎓</span><span class="nav-label">CGPA Planner</span>
    </a>
    <a href="career-guide.php" class="nav-item nav-item-active">
      <span class="nav-active-bar"></span>
      <span class="nav-icon">🚀</span><span class="nav-label">Career Guide</span>
    </a>
    <div class="nav-section-label" style="margin-top:12px">ACCOUNT</div>
    <a href="notifications.php" class="nav-item"><span class="nav-icon">🔔</span><span class="nav-label">Notifications</span></a>
    <a href="profile-setup.php" class="nav-item"><span class="nav-icon">👤</span><span class="nav-label">Profile Setup</span></a>
  </nav>
  <div class="sidebar-footer">
    <div class="user-card" onclick="handleLogout()" title="Click to logout" id="user-card">
      <div class="avatar" id="user-avatar">ST</div>
      <div><div class="user-name" id="user-name-el">Student</div><div class="user-role" id="user-role-el">Loading...</div></div>
    </div>
  </div>
</aside>

<button class="mob-toggle" onclick="document.getElementById('main-sidebar').classList.toggle('mob-open')"><span></span><span></span><span></span></button>
<div class="mob-overlay" onclick="document.getElementById('main-sidebar').classList.remove('mob-open')"></div>

<div class="main">
  <div class="topbar">
    <div class="topbar-title">🚀 Career Guide</div>
    <div class="topbar-actions">
      <div class="icon-btn" title="Refresh AI Analysis" onclick="refreshAll()" id="refresh-btn">
        <svg width="15" height="15" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15"/></svg>
      </div>
      <a href="notifications.php" class="icon-btn" style="text-decoration:none;color:var(--text-2)">
        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6 6 0 10-12 0v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0a3 3 0 01-6 0"/></svg>
        <span class="notif-dot"></span>
      </a>
      <a href="profile-setup.php" style="text-decoration:none">
        <div class="avatar" style="width:34px;height:34px;font-size:13px;cursor:pointer" id="topbar-avatar">ST</div>
      </a>
    </div>
  </div>

  <div class="page">

    <!-- HERO -->
    <div class="cg-hero fade-up">
      <div style="display:flex;align-items:center;gap:16px;margin-bottom:16px;position:relative;z-index:1">
        <div style="width:56px;height:56px;border-radius:16px;background:linear-gradient(135deg,var(--cyan),var(--violet));display:flex;align-items:center;justify-content:center;font-size:26px;flex-shrink:0">🚀</div>
        <div>
          <div style="font-family:'Syne',sans-serif;font-weight:800;font-size:26px;margin-bottom:4px">Career Guide <span style="background:linear-gradient(135deg,var(--cyan),var(--violet));-webkit-background-clip:text;-webkit-text-fill-color:transparent;background-clip:text">&amp; Roadmap</span></div>
          <div style="color:var(--text-2);font-size:14px">AI-powered career paths tailored to your subjects, study data and favourites</div>
        </div>
      </div>
      <div style="display:flex;gap:10px;flex-wrap:wrap;position:relative;z-index:1">
        <div style="display:inline-flex;align-items:center;gap:6px;padding:6px 14px;background:rgba(0,210,255,.1);border:1px solid rgba(0,210,255,.2);border-radius:20px;font-size:12px;color:var(--cyan)"><span style="animation:spin 3s linear infinite;display:inline-block">✦</span> AI-Powered</div>
        <div style="display:inline-flex;align-items:center;gap:6px;padding:6px 14px;background:rgba(16,185,129,.1);border:1px solid rgba(16,185,129,.2);border-radius:20px;font-size:12px;color:var(--emerald)">📈 2026 Data</div>
        <div style="display:inline-flex;align-items:center;gap:6px;padding:6px 14px;background:rgba(124,58,237,.1);border:1px solid rgba(124,58,237,.2);border-radius:20px;font-size:12px;color:var(--violet)">🗺️ Step-by-Step Roadmaps</div>
        <div id="fav-hero-badge" style="display:none;align-items:center;gap:6px;padding:6px 14px;background:rgba(245,158,11,.1);border:1px solid rgba(245,158,11,.25);border-radius:20px;font-size:12px;color:var(--amber)">⭐ Personalised for Your Favourites</div>
      </div>
    </div>

    <!-- FAVOURITE SUBJECTS BANNER -->
    <div id="fav-banner" class="fav-banner fade-up-1" style="display:none">
      <div style="display:flex;align-items:center;gap:12px;margin-bottom:12px">
        <span style="font-size:20px">⭐</span>
        <div style="font-family:'Syne',sans-serif;font-weight:700;font-size:15px">Career Suggestions Based on Your Favourite Subjects</div>
        <div style="margin-left:auto"><button class="btn-primary btn-sm" onclick="buildFavBanner()">🔄 Refresh</button></div>
      </div>
      <div id="fav-banner-content">
        <div class="ai-thinking"><div class="ai-dot"></div><div class="ai-dot"></div><div class="ai-dot"></div></div>
      </div>
    </div>

    <!-- TABS -->
    <div class="tab-nav fade-up-2">
      <button class="tab-btn-cg active" onclick="showTab('ai-analysis',this)">🤖 AI Analysis</button>
      <button class="tab-btn-cg" onclick="showTab('tracks',this)">🎯 Career Tracks</button>
      <button class="tab-btn-cg" onclick="showTab('roadmap',this)">🗺️ Roadmap</button>
      <button class="tab-btn-cg" onclick="showTab('skills',this)">⚡ Skills &amp; Certs</button>
      <button class="tab-btn-cg" onclick="showTab('chat',this)">💬 Ask CareerAI</button>
      <button class="tab-btn-cg" onclick="showTab('quiz',this)">🧠 Career Quiz</button>
      <button class="tab-btn-cg" onclick="showTab('resources',this)">📚 Resources</button>
    </div>

    <!-- TAB: AI ANALYSIS -->
    <div id="tab-ai-analysis" class="tab-content fade-up-3">
      <div id="ai-analysis-content">
        <div style="text-align:center;padding:60px 20px">
          <div class="ai-thinking" style="justify-content:center;margin-bottom:16px"><div class="ai-dot"></div><div class="ai-dot"></div><div class="ai-dot"></div></div>
          <div style="font-family:'Syne',sans-serif;font-weight:700;font-size:18px;margin-bottom:8px">Analysing Your Academic Profile</div>
          <div style="color:var(--text-2);font-size:14px">Reading your subjects, favourites, study hours and CGPA data...</div>
        </div>
      </div>
    </div>

    <!-- TAB: TRACKS -->
    <div id="tab-tracks" class="tab-content" style="display:none">
      <div style="margin-bottom:20px">
        <input id="track-search" oninput="filterTracks(this.value)" placeholder="🔍  Search career tracks..." class="input-field" style="width:320px;max-width:100%"/>
      </div>
      <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px" class="rg2" id="tracks-grid"></div>
    </div>

    <!-- TAB: ROADMAP -->
    <div id="tab-roadmap" class="tab-content" style="display:none">
      <div style="display:flex;gap:12px;margin-bottom:20px;align-items:center;flex-wrap:wrap">
        <span style="font-size:14px;color:var(--text-2)">Select career:</span>
        <select id="roadmap-select" class="select-field" style="width:270px" onchange="renderRoadmap(this.value)">
          <option value="software">💻 Software Engineer</option>
          <option value="datascience">📊 Data Scientist</option>
          <option value="cybersecurity">🔐 Cybersecurity Analyst</option>
          <option value="aiml">🤖 AI / ML Engineer</option>
          <option value="fullstack">🌐 Full Stack Developer</option>
          <option value="product">🎯 Product Manager</option>
          <option value="cloud">☁️ Cloud Architect</option>
          <option value="devops">⚙️ DevOps Engineer</option>
          <option value="uiux">🎨 UI/UX Designer</option>
        </select>
        <button class="btn-primary btn-sm" onclick="generateAIRoadmap()">✨ AI Personalise</button>
      </div>
      <div style="display:grid;grid-template-columns:2fr 1fr;gap:20px;align-items:start" class="rg2">
        <div class="card">
          <div id="roadmap-title" style="font-family:'Syne',sans-serif;font-weight:700;font-size:18px;margin-bottom:20px"></div>
          <div id="roadmap-steps"></div>
        </div>
        <div style="display:flex;flex-direction:column;gap:14px">
          <div class="card" id="career-stats-card"></div>
          <div class="card" id="top-companies-card"></div>
        </div>
      </div>
    </div>

    <!-- TAB: SKILLS -->
    <div id="tab-skills" class="tab-content" style="display:none">
      <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:16px" class="rg2" id="skills-grid"></div>
    </div>

    <!-- TAB: CHAT -->
    <div id="tab-chat" class="tab-content" style="display:none">
      <div style="display:grid;grid-template-columns:2fr 1fr;gap:20px;align-items:start" class="rg2">
        <div class="card" style="padding:0;overflow:hidden">
          <div style="padding:18px 22px;border-bottom:1px solid var(--border);display:flex;align-items:center;gap:10px">
            <div style="width:36px;height:36px;border-radius:10px;background:linear-gradient(135deg,var(--cyan),var(--violet));display:flex;align-items:center;justify-content:center;font-size:16px">🤖</div>
            <div>
              <div style="font-family:'Syne',sans-serif;font-weight:700;font-size:15px">CareerAI Assistant</div>
              <div style="font-size:11px;color:var(--emerald);display:flex;align-items:center;gap:4px"><span style="width:6px;height:6px;border-radius:50%;background:var(--emerald);display:inline-block;animation:pulse 2s infinite"></span>Online – Claude AI</div>
            </div>
          </div>
          <div id="chat-messages" style="height:360px;overflow-y:auto;padding:18px;display:flex;flex-direction:column;gap:12px">
            <div style="display:flex;gap:10px;align-items:flex-start">
              <div style="width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,var(--cyan),var(--violet));display:flex;align-items:center;justify-content:center;font-size:12px;flex-shrink:0">🤖</div>
              <div class="chat-bubble-ai">Hi! I'm CareerAI 👋 I've analysed your study profile and I'm ready to give personalised career advice. Ask me anything — careers, skills, salaries, or how to get started!</div>
            </div>
          </div>
          <div style="padding:14px 18px;border-top:1px solid var(--border);display:flex;gap:10px">
            <input id="chat-input" onkeydown="if(event.key==='Enter')sendChat()" placeholder="Ask about careers, skills, roadmaps..." class="input-field" style="flex:1"/>
            <button onclick="sendChat()" class="btn-primary btn-sm">Send →</button>
          </div>
        </div>
        <div style="display:flex;flex-direction:column;gap:12px">
          <div class="card">
            <div style="font-family:'Syne',sans-serif;font-weight:700;font-size:14px;margin-bottom:10px">💡 Quick Questions</div>
            <div id="chat-suggestions" style="display:flex;flex-direction:column;gap:6px"></div>
          </div>
          <div class="card">
            <div style="font-family:'Syne',sans-serif;font-weight:700;font-size:14px;margin-bottom:10px">📊 Your Context</div>
            <div style="font-size:12px;color:var(--text-2);line-height:1.8" id="chat-profile-summary">Loading...</div>
          </div>
        </div>
      </div>
    </div>

    <!-- TAB: QUIZ -->
    <div id="tab-quiz" class="tab-content" style="display:none">
      <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;align-items:start" class="rg2">
        <div class="card" id="quiz-panel">
          <div style="font-family:'Syne',sans-serif;font-weight:700;font-size:18px;margin-bottom:6px">🧠 Career Fit Quiz</div>
          <div style="font-size:13px;color:var(--text-2);margin-bottom:20px">Answer 5 quick questions to discover your best-fit career path</div>
          <div id="quiz-content"></div>
        </div>
        <div class="card" id="quiz-result-panel" style="display:none;animation:fadeUp .5s ease"></div>
      </div>
    </div>

    <!-- TAB: RESOURCES -->
    <div id="tab-resources" class="tab-content" style="display:none">
      <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:20px" class="rg2" id="resources-grid"></div>
    </div>

  </div>
</div>
</div>

<script src="js/api.js"></script>
<script>
/* ═══════════ STATE ═══════════ */
var studentData  = null;
var aiCareerData = null;
var favSubjects  = [];
var chatHistory  = [];
var quizAnswers  = [];
var quizStep     = 0;

/* ═══════════ STATIC DATA ═══════════ */
var TRACKS = [
  {id:'software',     icon:'💻',title:'Software Engineer',       sub:'Build apps, systems and software products.',            color:'var(--cyan)',   bg:'rgba(0,210,255,.08)',  salary:'₹8L–₹45L', demand:92,skills:['DSA','OOP','System Design','Git','Agile'],     tags:['Backend','Frontend','Mobile']},
  {id:'datascience',  icon:'📊',title:'Data Scientist',          sub:'Analyse data and build predictive models.',             color:'var(--violet)', bg:'rgba(124,58,237,.08)', salary:'₹7L–₹40L', demand:88,skills:['Python','ML','SQL','Statistics','Tableau'],   tags:['Analytics','ML','Visualization']},
  {id:'aiml',         icon:'🤖',title:'AI / ML Engineer',        sub:'Build intelligent systems and deep learning models.',   color:'#ec4899',      bg:'rgba(236,72,153,.08)', salary:'₹12L–₹60L',demand:95,skills:['Python','TensorFlow','PyTorch','Math','LLMs'],  tags:['Deep Learning','NLP','Vision']},
  {id:'cybersecurity',icon:'🔐',title:'Cybersecurity Analyst',   sub:'Protect systems from threats and vulnerabilities.',     color:'var(--rose)',   bg:'rgba(244,63,94,.08)',  salary:'₹6L–₹35L', demand:85,skills:['Networking','Linux','SIEM','Pen Testing'],    tags:['Blue Team','Red Team','Cloud Sec']},
  {id:'cloud',        icon:'☁️',title:'Cloud Architect',         sub:'Design and manage cloud infrastructure at scale.',      color:'#38bdf8',      bg:'rgba(56,189,248,.08)', salary:'₹10L–₹50L',demand:90,skills:['AWS','Azure','GCP','Kubernetes','Terraform'],  tags:['AWS','Azure','DevOps']},
  {id:'devops',       icon:'⚙️',title:'DevOps Engineer',         sub:'Automate CI/CD pipelines and infrastructure.',         color:'var(--amber)',  bg:'rgba(245,158,11,.08)', salary:'₹8L–₹42L', demand:87,skills:['Docker','K8s','Jenkins','Linux','Python'],    tags:['CI/CD','Infrastructure','Automation']},
  {id:'fullstack',    icon:'🌐',title:'Full Stack Developer',    sub:'Build complete web applications front to back.',        color:'var(--emerald)',bg:'rgba(16,185,129,.08)', salary:'₹6L–₹38L', demand:86,skills:['React','Node.js','MongoDB','REST API','CSS'],  tags:['React','Node.js','Web']},
  {id:'product',      icon:'🎯',title:'Product Manager',         sub:'Define product strategy and drive execution.',          color:'#a78bfa',      bg:'rgba(167,139,250,.08)',salary:'₹12L–₹55L',demand:80,skills:['Roadmapping','Agile','Analytics','UX','SQL'],  tags:['Strategy','B2B','SaaS']},
  {id:'uiux',         icon:'🎨',title:'UI/UX Designer',          sub:'Create beautiful, user-centered digital experiences.', color:'#f472b6',      bg:'rgba(244,114,182,.08)',salary:'₹5L–₹30L', demand:78,skills:['Figma','User Research','Prototyping','CSS'],  tags:['Web','Mobile','Design']},
];

var ROADMAPS = {
  software:    {title:'💻 Software Engineer',      salary:'₹8L–₹45L/yr', demand:92, growth:'+22% by 2030', companies:['Google','Microsoft','Amazon','Infosys','TCS','Razorpay'],       steps:[{phase:'Foundation',dur:'Sem 1–2',icon:'📐',color:'var(--cyan)',   tasks:['Master DSA (Arrays, LinkedList, Trees, Graphs)','Learn C++ or Java for competitive programming','Build 2–3 basic projects','Practice 100+ LeetCode Easy problems']},{phase:'Core Skills',dur:'Sem 3–4',icon:'⚙️',color:'var(--violet)', tasks:['Web Dev: HTML, CSS, JavaScript, React','Backend: Node.js + REST APIs','Databases: MySQL + MongoDB','Git & GitHub workflows']},{phase:'Advanced',dur:'Sem 5–6',icon:'🚀',color:'var(--emerald)',tasks:['System Design fundamentals','Docker & basic DevOps','Full-stack capstone project','Contribute to open-source']},{phase:'Job Ready',dur:'Final',icon:'🏆',color:'var(--amber)',  tasks:['250+ LeetCode problems','Target FAANG/Product companies','Build polished GitHub portfolio','Network on LinkedIn']}]},
  datascience: {title:'📊 Data Scientist',         salary:'₹7L–₹40L/yr', demand:88, growth:'+35% by 2030', companies:['Flipkart','Amazon','Walmart Labs','Mu Sigma','Fractal'],         steps:[{phase:'Math & Python',dur:'3–4 mo',icon:'🔢',color:'var(--cyan)',   tasks:['Linear Algebra, Statistics, Probability','Python: NumPy, Pandas, Matplotlib','SQL for data analysis','Kaggle beginner courses']},{phase:'Machine Learning',dur:'4–6 mo',icon:'🧠',color:'var(--violet)', tasks:['Supervised & Unsupervised Learning','Scikit-learn, XGBoost, Random Forest','Feature Engineering','Complete Kaggle competitions']},{phase:'Deep Learning',dur:'3–4 mo',icon:'🔬',color:'var(--emerald)',tasks:['Neural Networks, CNNs, Transformers','TensorFlow / PyTorch','NLP basics','Build 3 end-to-end ML projects']},{phase:'Deployment',dur:'2–3 mo',icon:'🚀',color:'var(--amber)',  tasks:['Flask/FastAPI for model serving','Docker containerisation','MLflow experiment tracking','Deploy to AWS/GCP']}]},
  cybersecurity:{title:'🔐 Cybersecurity Analyst', salary:'₹6L–₹35L/yr', demand:85, growth:'+31% by 2030', companies:['Wipro','HCL','Cisco','Palo Alto','Deloitte','EY'],               steps:[{phase:'Fundamentals',dur:'3 mo',icon:'🌐',color:'var(--cyan)',   tasks:['Networking: TCP/IP, DNS, HTTP, Firewalls','Linux & Windows admin','CompTIA Network+ cert','Home lab with VirtualBox']},{phase:'Security Core',dur:'4 mo',icon:'🛡️',color:'var(--rose)',    tasks:['CompTIA Security+ cert','Cryptography & PKI','Vulnerability Scanning (Nmap, Nessus)','OWASP Top 10']},{phase:'Specialisation',dur:'4 mo',icon:'⚔️',color:'var(--violet)', tasks:['Penetration Testing: Metasploit, Burp Suite','CEH cert','SIEM tools: Splunk, IBM QRadar','Incident Response & Forensics']},{phase:'Expert',dur:'Ongoing',icon:'🏆',color:'var(--amber)',  tasks:['OSCP certification','Bug bounty programs','CTF portfolio','Target CERT-In, DRDO, MNCs']}]},
  aiml:        {title:'🤖 AI / ML Engineer',       salary:'₹12L–₹60L/yr',demand:95, growth:'+40% by 2030', companies:['Google DeepMind','OpenAI','Microsoft','NVIDIA','Anthropic'],    steps:[{phase:'Foundation',dur:'4 mo',icon:'📐',color:'var(--cyan)',   tasks:['Advanced Math: Calculus, Linear Algebra, Probability','Python mastery: NumPy, Pandas','Classical ML algorithms','Andrew Ng ML course']},{phase:'Deep Learning',dur:'4 mo',icon:'🧠',color:'#ec4899',       tasks:['Neural Networks from scratch','CNN, RNN/LSTM, Transformers','PyTorch deep dive','Replicate 3 research papers']},{phase:'Modern AI',dur:'3 mo',icon:'✨',color:'var(--violet)', tasks:['LLMs: GPT, BERT, fine-tuning','Diffusion models basics','Reinforcement Learning fundamentals','Hugging Face ecosystem']},{phase:'Production AI',dur:'3 mo',icon:'🚀',color:'var(--emerald)',tasks:['MLOps: CI/CD for ML','Kubernetes for distributed training','Build GenAI app end-to-end','Publish research or Kaggle GM']}]},
  fullstack:   {title:'🌐 Full Stack Developer',   salary:'₹6L–₹38L/yr', demand:86, growth:'+25% by 2030', companies:['Startups','Zomato','Meesho','Freshworks','Postman'],             steps:[{phase:'Frontend',dur:'3 mo',icon:'🎨',color:'var(--cyan)',   tasks:['HTML5, CSS3, Flexbox, Grid','JavaScript ES6+: async/await, closures','React.js: hooks, state management','Tailwind CSS']},{phase:'Backend',dur:'3 mo',icon:'⚙️',color:'var(--violet)', tasks:['Node.js + Express REST APIs','SQL (PostgreSQL) + NoSQL (MongoDB)','Auth: JWT, OAuth, sessions','API security & rate limiting']},{phase:'DevOps',dur:'2 mo',icon:'🐳',color:'var(--emerald)',tasks:['Git workflow, CI/CD GitHub Actions','Docker containerisation','Deploy to Vercel / Railway / AWS','Environment management']},{phase:'Portfolio',dur:'2 mo',icon:'🏆',color:'var(--amber)',  tasks:['Build 3 full-stack apps','Add tests (Jest, Cypress)','Open-source contributions','Technical blog']}]},
  product:     {title:'🎯 Product Manager',         salary:'₹12L–₹55L/yr',demand:80, growth:'+18% by 2030', companies:['Google','Flipkart','Razorpay','CRED','PhonePe','Adobe'],         steps:[{phase:'Foundations',dur:'2 mo',icon:'📚',color:'var(--cyan)',   tasks:['Read "Inspired" by Marty Cagan','Learn Agile, Scrum, Kanban','User research & interview techniques','Analytics basics: Google Analytics, Mixpanel']},{phase:'PM Skills',dur:'3 mo',icon:'🎯',color:'var(--violet)', tasks:['Write PRDs and user stories','Wireframing with Figma','A/B testing and experimentation','SQL for product metrics']},{phase:'Launch',dur:'3 mo',icon:'🚀',color:'var(--emerald)',tasks:['Build a personal product','Join a startup as intern PM','FAANG PM case studies','Build GTM & pricing strategy skills']},{phase:'Senior PM',dur:'Ongoing',icon:'🏆',color:'var(--amber)',  tasks:['P&L ownership mindset','Stakeholder communication','Build PM network','Target APM: Google, Microsoft, Flipkart']}]},
  cloud:       {title:'☁️ Cloud Architect',         salary:'₹10L–₹50L/yr',demand:90, growth:'+28% by 2030', companies:['AWS','Azure','Google Cloud','Accenture','Wipro','Rackspace'],    steps:[{phase:'Linux & Networking',dur:'2 mo',icon:'🖥️',color:'var(--cyan)',   tasks:['Linux command line mastery','Networking: VPCs, subnets, load balancers','Scripting: Bash + Python automation','Virtualisation basics']},{phase:'Core Cloud',dur:'3 mo',icon:'☁️',color:'var(--violet)', tasks:['AWS Cloud Practitioner cert','Core services: EC2, S3, RDS, Lambda, IAM','Azure Fundamentals AZ-900','Cloud cost optimisation']},{phase:'Advanced Cloud',dur:'4 mo',icon:'⚡',color:'#38bdf8',       tasks:['AWS Solutions Architect SAA-C03','Terraform, CloudFormation','Kubernetes & EKS/GKE','Microservices patterns']},{phase:'Expert',dur:'3 mo',icon:'🏆',color:'var(--amber)',  tasks:['AWS Solutions Architect Professional','Multi-cloud strategy','FinOps cost management','Cloud Security CSPM']}]},
  devops:      {title:'⚙️ DevOps Engineer',         salary:'₹8L–₹42L/yr', demand:87, growth:'+24% by 2030', companies:['ThoughtWorks','Atlassian','HashiCorp','Netflix','Swiggy'],        steps:[{phase:'Linux & Scripting',dur:'2 mo',icon:'🐧',color:'var(--cyan)',   tasks:['Linux administration & shell scripting','Python for automation','Git advanced: branching, hooks','Networking fundamentals']},{phase:'CI/CD & Containers',dur:'3 mo',icon:'🐳',color:'var(--violet)', tasks:['Docker: build, run, compose','Jenkins & GitHub Actions pipelines','Nginx, reverse proxy','Artifact management: Nexus']},{phase:'Orchestration',dur:'3 mo',icon:'⚓',color:'var(--emerald)',tasks:['Kubernetes: pods, services, Helm','Terraform infrastructure provisioning','Ansible configuration management','AWS/GCP services']},{phase:'Observability',dur:'2 mo',icon:'📡',color:'var(--amber)',  tasks:['Prometheus + Grafana monitoring','ELK Stack logging','Incident management & SRE','CKA (Kubernetes) cert']}]},
  uiux:        {title:'🎨 UI/UX Designer',          salary:'₹5L–₹30L/yr', demand:78, growth:'+20% by 2030', companies:['Swiggy','Meesho','Razorpay','Adobe','Hotstar','ThoughtWorks'],   steps:[{phase:'Design Basics',dur:'2 mo',icon:'🎨',color:'#f472b6',      tasks:['Principles of design: typography, colour, layout','Figma fundamentals','Study 50+ great interfaces','Wireframing & prototyping basics']},{phase:'UX Process',dur:'3 mo',icon:'🔍',color:'var(--violet)', tasks:['User research methods & interviews','Creating user personas & journey maps','Information architecture & flows','Usability testing basics']},{phase:'Portfolio',dur:'3 mo',icon:'🖼️',color:'var(--cyan)',   tasks:['Design 3 case study projects','Build Behance & Dribbble portfolio','Learn design handoff with Figma','Practice interaction animations']},{phase:'Job Ready',dur:'2 mo',icon:'🏆',color:'var(--amber)',  tasks:['Apply for UX internships','Practice whiteboard challenges','Build personal portfolio site','Target product companies']}]},
};

var SKILLS_DATA = [
  {cat:'Programming Languages',icon:'💻',color:'var(--cyan)',  skills:[{name:'Python',level:95,cert:'PCEP/PCAP'},{name:'JavaScript',level:88,cert:'JSNAD (Node.js)'},{name:'Java',level:82,cert:'OCA/OCP (Oracle)'},{name:'C++',level:75,cert:'Competitive Programming'}]},
  {cat:'Cloud & DevOps',       icon:'☁️',color:'#38bdf8',   skills:[{name:'AWS',level:90,cert:'AWS SAA-C03 (Must Have)'},{name:'Docker/K8s',level:85,cert:'CKA / CKAD'},{name:'Terraform',level:78,cert:'Terraform Associate'},{name:'Azure',level:72,cert:'AZ-104'}]},
  {cat:'Data & AI',            icon:'🧠',color:'var(--violet)',skills:[{name:'Machine Learning',level:88,cert:'DeepLearning.AI Specialization'},{name:'SQL',level:92,cert:'Google Data Analytics'},{name:'TensorFlow',level:80,cert:'TensorFlow Developer'},{name:'Power BI',level:75,cert:'PL-300 Microsoft'}]},
  {cat:'Security',             icon:'🔐',color:'var(--rose)', skills:[{name:'CompTIA Sec+',level:88,cert:'Security+ SY0-701'},{name:'Pen Testing',level:82,cert:'CEH / OSCP'},{name:'SIEM/SOC',level:75,cert:'Splunk Core Certified'},{name:'Cloud Sec',level:70,cert:'AWS Security Specialty'}]},
];

var QUIZ_QUESTIONS = [
  {q:'What activity sounds most exciting to you?',        opts:['Building apps & coding systems','Analysing data to find patterns','Protecting systems from hackers','Managing people & setting product direction']},
  {q:'Which subject do you enjoy most?',                  opts:['Mathematics & Logic','Statistics & Probability','Networking & System Security','Business & Economics']},
  {q:'What kind of work environment do you prefer?',      opts:['Writing code all day','Doing analysis & experiments','Monitoring & securing systems','Meetings, strategy & planning']},
  {q:'Which tool excites you most?',                      opts:['VS Code & GitHub','Jupyter Notebook & Kaggle','Kali Linux & Wireshark','Figma & Notion']},
  {q:'What is your long-term dream?',                     opts:['Join FAANG as a SWE','Work at a data-driven company','Work in govt/defence cyber','Launch my own product']},
];

var RESOURCES = [
  {cat:'🎓 Free Platforms',    color:'var(--cyan)',   items:[{name:'CS50 – Harvard',link:'https://cs50.harvard.edu',type:'Course',desc:'Best intro to CS'},{name:'The Odin Project',link:'https://theodinproject.com',type:'Track',desc:'Full stack for free'},{name:'Kaggle Learn',link:'https://kaggle.com/learn',type:'Course',desc:'ML micro-courses'},{name:'TryHackMe',link:'https://tryhackme.com',type:'Platform',desc:'Hands-on cybersecurity'}]},
  {cat:'📜 Top Certifications',color:'var(--violet)', items:[{name:'AWS Solutions Architect',link:'https://aws.amazon.com/certification',type:'Cert',desc:'Most valuable cloud cert'},{name:'Google Data Analytics',link:'https://grow.google/certificates',type:'Cert',desc:'Beginner-friendly data cert'},{name:'CompTIA Security+',link:'https://comptia.org',type:'Cert',desc:'Gold standard entry cybersecurity'},{name:'Meta Front-End Developer',link:'https://coursera.org',type:'Cert',desc:'Industry-recognized React cert'}]},
  {cat:'📹 YouTube Channels',  color:'var(--emerald)',items:[{name:'Traversy Media',link:'https://youtube.com/@TraversyMedia',type:'Channel',desc:'Best web dev tutorials'},{name:'3Blue1Brown',link:'https://youtube.com/@3blue1brown',type:'Channel',desc:'Math & ML visualised'},{name:'NetworkChuck',link:'https://youtube.com/@NetworkChuck',type:'Channel',desc:'Networking & cybersecurity'},{name:'Fireship',link:'https://youtube.com/@Fireship',type:'Channel',desc:'100 seconds tech overviews'}]},
  {cat:'💼 Job Platforms',     color:'var(--amber)',  items:[{name:'LinkedIn Jobs',link:'https://linkedin.com/jobs',type:'Jobs',desc:'Network + apply'},{name:'AngelList / Wellfound',link:'https://wellfound.com',type:'Jobs',desc:'Startup jobs'},{name:'Internshala',link:'https://internshala.com',type:'Intern',desc:'Best for Indian students'},{name:'HackerEarth',link:'https://hackerearth.com',type:'Compete',desc:'Hiring via coding competitions'}]},
];

/* ═══════════ TAB NAV ═══════════ */
function showTab(name, btn) {
  document.querySelectorAll('.tab-content').forEach(function(el){ el.style.display='none'; });
  var t = document.getElementById('tab-'+name);
  if(t) t.style.display='block';
  document.querySelectorAll('.tab-btn-cg').forEach(function(b){ b.classList.remove('active'); });
  if(btn) btn.classList.add('active');
  if(name==='roadmap')   renderRoadmap(document.getElementById('roadmap-select').value);
  if(name==='skills')    renderSkills();
  if(name==='quiz')    { renderQuiz(); }
  if(name==='resources') renderResources();
  if(name==='tracks')    renderTracks();
  if(name==='chat')      initChat();
}

/* ═══════════ PAGE INIT ═══════════ */
async function initPage() {
  var user = await requireAuth();
  if(!user) return;

  // Load student data
  try {
    var res = await API.request('career.php?action=student_data');
    if(res && res.success) {
      studentData = res.data;
      var raw = studentData.user ? studentData.user.favorite_subjects : null;
      if(raw) {
        try { favSubjects = typeof raw === 'string' ? JSON.parse(raw) : (Array.isArray(raw) ? raw : []); }
        catch(e) { favSubjects = []; }
      }
    }
  } catch(e) { console.warn('Could not load student data'); }

  // Show favourite badge if applicable
  if(favSubjects.length > 0) {
    var hb = document.getElementById('fav-hero-badge');
    if(hb) hb.style.display = 'inline-flex';
    var fb = document.getElementById('fav-banner');
    if(fb) fb.style.display = 'block';
    buildFavBanner();
  }

  await doAIAnalysis();
  renderTracks();
  renderResources();
  renderQuiz();
  renderRoadmap('software');
}

/* ═══════════ FAVOURITE BANNER ═══════════ */
var FAV_TRACK_MAP = {
  mathematics:['software','datascience','aiml','cloud'],
  math:       ['software','datascience','aiml'],
  physics:    ['software','aiml','cloud','devops'],
  chemistry:  ['datascience'],
  biology:    ['datascience'],
  'computer science':['software','aiml','cybersecurity','fullstack'],
  programming:['software','fullstack','aiml'],
  english:    ['product','uiux'],
  economics:  ['product','datascience'],
  history:    ['product'],
  commerce:   ['product','datascience'],
  accounts:   ['datascience'],
  statistics: ['datascience','aiml'],
  networking: ['cybersecurity','cloud','devops'],
  design:     ['uiux','fullstack','product'],
};

function buildFavBanner() {
  var content = document.getElementById('fav-banner-content');
  if(!content || favSubjects.length === 0) return;

  // Score each track
  var scores = {};
  favSubjects.forEach(function(sub) {
    var sl = sub.toLowerCase();
    Object.keys(FAV_TRACK_MAP).forEach(function(key) {
      if(sl.includes(key) || key.includes(sl.split(' ')[0])) {
        FAV_TRACK_MAP[key].forEach(function(trackId) {
          scores[trackId] = (scores[trackId] || 0) + 1;
        });
      }
    });
  });

  // Default if nothing matched
  if(Object.keys(scores).length === 0) {
    scores = {software:2, datascience:1, product:1};
  }

  var sorted = Object.keys(scores).sort(function(a,b){ return scores[b]-scores[a]; }).slice(0,3);
  var trackMap = {};
  TRACKS.forEach(function(t){ trackMap[t.id] = t; });

  var subLabels = favSubjects.map(function(s){
    return '<span style="background:rgba(245,158,11,.15);color:var(--amber);padding:2px 8px;border-radius:6px;font-size:11px;font-weight:600">⭐ '+s+'</span>';
  }).join(' ');

  var html = '<div style="font-size:12px;color:var(--text-2);margin-bottom:14px">Based on your favourite subjects: '+subLabels+'</div>';
  html += '<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px" class="rg2">';
  sorted.forEach(function(id, i) {
    var t = trackMap[id] || TRACKS[0];
    var matchPct = Math.min(96, 68 + scores[id]*9);
    html += '<div onclick="goRoadmap(\''+t.id+'\')" style="background:var(--surface);border:1px solid '+(i===0?'rgba(245,158,11,.35)':'var(--border)')+';border-radius:12px;padding:16px;cursor:pointer;transition:all .3s" onmouseover="this.style.transform=\'translateY(-2px)\';this.style.borderColor=\''+t.color+'\'" onmouseout="this.style.transform=\'\';this.style.borderColor=\''+(i===0?'rgba(245,158,11,.35)':'var(--border)')+'\'">'
      +'<div style="display:flex;align-items:center;gap:8px;margin-bottom:10px">'
        +'<span style="font-size:22px">'+t.icon+'</span>'
        +'<div>'
          +'<div style="font-family:\'Syne\',sans-serif;font-weight:700;font-size:14px">'+t.title+'</div>'
          +'<div style="font-size:11px;color:'+t.color+'">'+matchPct+'% match</div>'
        +'</div>'
        +(i===0?'<span style="margin-left:auto;font-size:10px;padding:3px 8px;background:rgba(245,158,11,.15);color:var(--amber);border-radius:10px;font-weight:700;white-space:nowrap">Best Fit ⭐</span>':'')
      +'</div>'
      +'<div style="height:4px;background:var(--surface2);border-radius:20px;overflow:hidden;margin-bottom:8px"><div style="height:100%;width:'+matchPct+'%;background:'+t.color+';border-radius:20px;transition:width 1s ease"></div></div>'
      +'<div style="font-size:11px;color:var(--text-2)">Salary: <span style="color:'+t.color+';font-weight:700">'+t.salary+'</span></div>'
      +'<div style="font-size:11px;color:var(--text-3);margin-top:4px">Demand: <span style="color:var(--emerald)">'+t.demand+'%</span></div>'
    +'</div>';
  });
  html += '</div>';
  content.innerHTML = html;
}

/* ═══════════ AI ANALYSIS ═══════════ */
async function doAIAnalysis() {
  var container = document.getElementById('ai-analysis-content');
  if(!container) return;
  container.innerHTML = '<div style="text-align:center;padding:60px 20px"><div class="ai-thinking" style="justify-content:center;margin-bottom:16px"><div class="ai-dot"></div><div class="ai-dot"></div><div class="ai-dot"></div></div><div style="font-family:\'Syne\',sans-serif;font-weight:700;font-size:18px;margin-bottom:8px">Analysing Your Profile</div><div style="color:var(--text-2);font-size:14px">Reading your subjects, favourites, study hours and CGPA data…</div></div>';
  try {
    var res = await API.request('career.php', 'POST', {type:'full', extra:{favorite_subjects: favSubjects}});
    if(!res || !res.success) throw new Error('API failed');
    aiCareerData = res.data;
    renderAIAnalysis(aiCareerData);
    renderTracks(); // re-render to add AI match badges
  } catch(e) {
    container.innerHTML = '<div style="text-align:center;padding:40px"><div style="font-size:40px;margin-bottom:12px">⚠️</div><div style="color:var(--text-2);margin-bottom:16px">Could not load AI analysis.<br>Please ensure your profile &amp; subjects are set up.</div><button class="btn-primary" onclick="doAIAnalysis()">Try Again</button><br><br><a href="profile-setup.php" style="color:var(--cyan);font-size:13px">Set up profile →</a></div>';
  }
}

function refreshAll() {
  var btn = document.getElementById('refresh-btn');
  if(btn) btn.style.animation = 'spin 1s linear infinite';
  doAIAnalysis().then(function(){ if(btn) btn.style.animation=''; });
  if(favSubjects.length > 0) buildFavBanner();
}

function renderAIAnalysis(data) {
  var el = document.getElementById('ai-analysis-content');
  if(!el || !data) return;
  var careers  = data.top_careers || [];
  var insights = data.study_insights || [];
  var actions  = data.immediate_actions || [];
  var favNote  = favSubjects.length>0 ? ' · ⭐ '+favSubjects.join(', ') : '';

  el.innerHTML =
    '<div style="background:linear-gradient(135deg,rgba(0,210,255,.08),rgba(124,58,237,.08));border:1px solid rgba(0,210,255,.2);border-radius:16px;padding:22px;margin-bottom:22px">'
      +'<div style="display:flex;align-items:center;gap:12px;margin-bottom:10px">'
        +'<div style="width:38px;height:38px;border-radius:10px;background:linear-gradient(135deg,var(--cyan),var(--violet));display:flex;align-items:center;justify-content:center;font-size:17px">🤖</div>'
        +'<div style="font-family:\'Syne\',sans-serif;font-weight:700;font-size:15px">AI Career Analysis</div>'
        +'<div style="margin-left:auto;font-size:11px;padding:3px 10px;background:rgba(0,210,255,.15);border:1px solid rgba(0,210,255,.2);border-radius:20px;color:var(--cyan)">Your data'+favNote+'</div>'
      +'</div>'
      +'<p style="font-size:14px;color:var(--text-2);line-height:1.7">'+(data.ai_summary||'Analysis based on your study profile.')+'</p>'
    +'</div>'

    +'<div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:22px" class="rg2">'
      +'<div class="card"><div style="font-family:\'Syne\',sans-serif;font-weight:700;font-size:15px;margin-bottom:10px">📊 Your Study Profile</div>'
        +'<p style="font-size:13px;color:var(--text-2);line-height:1.6;margin-bottom:12px">'+(data.study_personality||'Dedicated and consistent learner.')+'</p>'
        +'<div>'+(data.strongest_subjects||[]).map(function(s){ return '<span style="padding:4px 10px;border-radius:6px;background:rgba(0,210,255,.1);color:var(--cyan);font-size:12px;font-weight:600;display:inline-block;margin:2px">'+s+'</span>'; }).join('')
          +(favSubjects.length>0 ? favSubjects.map(function(s){ return '<span style="padding:4px 10px;border-radius:6px;background:rgba(245,158,11,.12);color:var(--amber);font-size:12px;font-weight:600;display:inline-block;margin:2px">⭐ '+s+'</span>'; }).join('') : '')
        +'</div></div>'
      +'<div class="card"><div style="font-family:\'Syne\',sans-serif;font-weight:700;font-size:15px;margin-bottom:12px">⚡ Key Metrics</div>'
        +'<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">'
          +insights.map(function(ins){ return '<div style="background:var(--surface2);border-radius:10px;padding:12px;border:1px solid var(--border)"><div style="font-size:18px;margin-bottom:4px">'+ins.icon+'</div><div style="font-family:\'Syne\',sans-serif;font-weight:700;font-size:16px;color:var(--cyan)">'+ins.value+'</div><div style="font-size:11px;color:var(--text-2)">'+ins.label+'</div></div>'; }).join('')
        +'</div></div>'
    +'</div>'

    +'<div style="font-family:\'Syne\',sans-serif;font-weight:700;font-size:16px;margin-bottom:14px">🎯 AI-Matched Career Paths</div>'
    +'<div style="display:grid;grid-template-columns:repeat(2,1fr);gap:14px;margin-bottom:22px" class="rg2">'
      +careers.map(function(c,i){
        return '<div class="card" style="cursor:pointer;border-color:'+(i===0?c.color+'44':'var(--border)')+'"'
          +' onclick="goRoadmap(\''+(c.id||'software')+'\')"'
          +' onmouseover="this.style.borderColor=\''+c.color+'66\'"'
          +' onmouseout="this.style.borderColor=\''+(i===0?c.color+'44':'var(--border)')+'\'">'
          +'<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:10px">'
            +'<div style="display:flex;align-items:center;gap:10px"><div style="font-size:26px">'+(c.icon||'💼')+'</div>'
              +'<div><div style="font-family:\'Syne\',sans-serif;font-weight:700;font-size:15px">'+(c.title||'Career')+'</div>'
              +'<div style="font-size:12px;color:var(--text-2)">'+(c.salary||'')+'</div></div>'
            +'</div>'
            +'<div style="text-align:center"><div style="font-family:\'Syne\',sans-serif;font-weight:800;font-size:20px;color:'+c.color+'">'+(c.match_score||80)+'%</div><div style="font-size:10px;color:var(--text-3)">match</div></div>'
          +'</div>'
          +'<div style="height:4px;background:var(--surface2);border-radius:20px;overflow:hidden;margin-bottom:8px"><div style="height:100%;width:'+(c.match_score||80)+'%;background:'+c.color+';border-radius:20px;transition:width 1.2s ease;box-shadow:0 0 8px '+c.color+'55"></div></div>'
          +'<p style="font-size:12px;color:var(--text-2);line-height:1.5;margin-bottom:8px">'+(c.match_reason||'')+'</p>'
          +'<div style="display:flex;flex-wrap:wrap;gap:4px;margin-bottom:8px">'+(c.key_skills||[]).map(function(s){ return '<span style="font-size:11px;padding:3px 8px;background:'+c.color+'15;color:'+c.color+';border-radius:5px;font-weight:500">'+s+'</span>'; }).join('')+'</div>'
          +'<div style="display:flex;justify-content:space-between;align-items:center">'
            +'<span style="font-size:11px;color:var(--text-2)">Demand: <span style="color:'+c.color+';font-weight:600">'+(c.demand||85)+'%</span></span>'
            +'<button onclick="event.stopPropagation();goRoadmap(\''+(c.id||'software')+'\')" style="background:none;border:1px solid '+c.color+'44;color:'+c.color+';padding:5px 10px;border-radius:7px;cursor:pointer;font-size:12px;font-family:\'DM Sans\',sans-serif">View Roadmap →</button>'
          +'</div>'
        +'</div>';
      }).join('')
    +'</div>'

    +'<div class="card"><div style="font-family:\'Syne\',sans-serif;font-weight:700;font-size:15px;margin-bottom:12px">⚡ Start Today</div>'
      +actions.map(function(a,i){ return '<div style="display:flex;gap:12px;align-items:flex-start;padding:10px 0;'+(i<actions.length-1?'border-bottom:1px solid var(--border)':'')+'"><div style="width:24px;height:24px;border-radius:50%;background:linear-gradient(135deg,var(--cyan),var(--violet));display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;color:#fff;flex-shrink:0">'+(i+1)+'</div><div style="font-size:13px;color:var(--text-2);line-height:1.5">'+a+'</div></div>'; }).join('')
    +'</div>';
}

/* ═══════════ TRACKS TAB ═══════════ */
function renderTracks() {
  var grid = document.getElementById('tracks-grid');
  if(!grid) return;
  var aiMatchIds = (aiCareerData && aiCareerData.top_careers) ? aiCareerData.top_careers.map(function(c){ return (c.id||'').toLowerCase(); }) : [];
  var html = '';
  TRACKS.forEach(function(t) {
    var isAI  = aiMatchIds.indexOf(t.id) !== -1;
    var isFav = favSubjects.length>0 && checkFavMatch(t.id);
    var aiScore = isAI ? (aiCareerData.top_careers.find(function(c){ return c.id===t.id; })||{}).match_score : null;
    html += '<div class="track-card" style="--tc:'+t.color+(isAI||isFav?';border-color:'+t.color+'33':'')+'" onclick="goRoadmap(\''+t.id+'\')">'
      +'<div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:4px">'
        +'<div style="width:52px;height:52px;border-radius:14px;background:'+t.bg+';display:flex;align-items:center;justify-content:center;font-size:24px">'+t.icon+'</div>'
        +'<div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px">'
          +(isFav?'<span style="font-size:10px;padding:3px 8px;background:rgba(245,158,11,.12);color:var(--amber);border-radius:10px;font-weight:700">⭐ Fav</span>':'')
          +(isAI ?'<span style="font-size:10px;padding:3px 8px;background:var(--cyan-dim);color:var(--cyan);border-radius:10px;font-weight:700">🤖 '+(aiScore||'')+'%</span>':'')
          +'<span style="font-size:10px;padding:3px 8px;background:rgba(16,185,129,.1);color:var(--emerald);border-radius:10px">'+t.demand+'%</span>'
        +'</div>'
      +'</div>'
      +'<div style="font-family:\'Syne\',sans-serif;font-weight:700;font-size:16px;margin:12px 0 6px">'+t.title+'</div>'
      +'<div style="font-size:13px;color:var(--text-2);line-height:1.5;margin-bottom:12px">'+t.sub+'</div>'
      +'<div style="margin-bottom:12px">'+t.skills.map(function(s){ return '<span class="skill-tag" style="background:'+t.bg+';color:'+t.color+'">'+s+'</span>'; }).join('')+'</div>'
      +'<div style="display:flex;justify-content:space-between;align-items:center;padding-top:12px;border-top:1px solid var(--border)">'
        +'<span class="salary-badge" style="background:'+t.bg+';color:'+t.color+'">💰 '+t.salary+'</span>'
        +'<div style="text-align:right"><div style="font-size:10px;color:var(--text-3);margin-bottom:3px">Market Demand</div><div class="demand-bar" style="width:70px"><div class="demand-fill" style="width:'+t.demand+'%;background:'+t.color+'"></div></div></div>'
      +'</div>'
    +'</div>';
  });
  grid.innerHTML = html;
}

function checkFavMatch(trackId) {
  var map={software:['math','physics','computer','programming'],datascience:['math','statistics','chemistry','biology','economics'],aiml:['math','physics','computer','statistics'],cybersecurity:['networking','computer','physics','math'],cloud:['computer','math','physics','networking'],devops:['computer','math','programming','networking'],fullstack:['computer','programming','math','design'],product:['economics','commerce','business','english','history'],uiux:['design','english','computer']};
  var keys=map[trackId]||[];
  return favSubjects.some(function(f){ var fl=f.toLowerCase(); return keys.some(function(k){ return fl.includes(k)||k.includes(fl.split(' ')[0]); }); });
}

function filterTracks(q) {
  document.querySelectorAll('.track-card').forEach(function(el){
    el.style.display=el.textContent.toLowerCase().includes(q.toLowerCase())?'':'none';
  });
}

function goRoadmap(id) {
  var roadmapBtn = null;
  document.querySelectorAll('.tab-btn-cg').forEach(function(b){ if(b.textContent.includes('Roadmap')) roadmapBtn=b; });
  showTab('roadmap', roadmapBtn);
  var sel=document.getElementById('roadmap-select');
  if(sel && ROADMAPS[id]) sel.value=id;
  renderRoadmap(id);
}

/* ═══════════ ROADMAP TAB ═══════════ */
function renderRoadmap(id) {
  var rm=ROADMAPS[id]; if(!rm) return;
  var titleEl=document.getElementById('roadmap-title');
  var stepsEl=document.getElementById('roadmap-steps');
  var statsEl=document.getElementById('career-stats-card');
  var compEl =document.getElementById('top-companies-card');
  if(!stepsEl) return;
  if(titleEl) titleEl.textContent=rm.title;
  var html='';
  rm.steps.forEach(function(s,i){
    html+='<div class="roadmap-step" style="position:relative">'
      +'<div style="position:relative">'
        +'<div class="step-num" style="background:'+s.color+'22;color:'+s.color+'">'+(i+1)+'</div>'
        +(i<rm.steps.length-1?'<div class="step-line"></div>':'')
      +'</div>'
      +'<div style="flex:1;padding-bottom:16px">'
        +'<div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">'
          +'<span style="font-size:17px">'+s.icon+'</span>'
          +'<span style="font-family:\'Syne\',sans-serif;font-weight:700;font-size:15px;color:'+s.color+'">'+s.phase+'</span>'
          +'<span style="font-size:11px;color:var(--text-3);border:1px solid var(--border);padding:2px 8px;border-radius:20px">'+s.dur+'</span>'
        +'</div>'
        +'<div>'+s.tasks.map(function(t){ return '<div style="display:flex;gap:8px;align-items:flex-start;padding:4px 0;font-size:13px;color:var(--text-2)"><span style="color:'+s.color+';flex-shrink:0;margin-top:1px">▸</span>'+t+'</div>'; }).join('')+'</div>'
      +'</div>'
    +'</div>';
  });
  stepsEl.innerHTML=html;
  if(statsEl) statsEl.innerHTML='<div style="font-family:\'Syne\',sans-serif;font-weight:700;font-size:15px;margin-bottom:14px">📈 Market Stats</div>'
    +[{l:'Avg Salary',v:rm.salary,i:'💰',c:'var(--emerald)'},{l:'Job Demand',v:rm.demand+'%',i:'📊',c:'var(--cyan)'},{l:'Growth 2030',v:rm.growth,i:'🚀',c:'var(--violet)'}].map(function(s){
      return '<div style="display:flex;align-items:center;gap:10px;padding:10px 12px;background:var(--surface2);border-radius:10px;border:1px solid var(--border);margin-bottom:6px"><span>'+s.i+'</span><div style="flex:1;font-size:12px;color:var(--text-2)">'+s.l+'</div><span style="font-weight:700;font-size:13px;color:'+s.c+'">'+s.v+'</span></div>';
    }).join('');
  if(compEl) compEl.innerHTML='<div style="font-family:\'Syne\',sans-serif;font-weight:700;font-size:15px;margin-bottom:12px">🏢 Top Hirers</div>'
    +rm.companies.map(function(c){ return '<div style="display:flex;align-items:center;gap:10px;padding:8px 12px;background:var(--surface2);border-radius:8px;border:1px solid var(--border);margin-bottom:6px;font-size:13px"><span>🏢</span>'+c+'</div>'; }).join('');
}

async function generateAIRoadmap() {
  var sel=document.getElementById('roadmap-select');
  var title=sel?sel.options[sel.selectedIndex].text.replace(/^[^ ]+ /,''):'Software Engineer';
  var stepsEl=document.getElementById('roadmap-steps');
  var titleEl=document.getElementById('roadmap-title');
  if(stepsEl) stepsEl.innerHTML='<div style="text-align:center;padding:40px"><div class="ai-thinking" style="justify-content:center;margin-bottom:10px"><div class="ai-dot"></div><div class="ai-dot"></div><div class="ai-dot"></div></div><div style="color:var(--text-2);font-size:13px">Generating AI roadmap for '+title+'...</div></div>';
  try {
    var res=await API.request('career.php','POST',{type:'roadmap',extra:{career:title,favorite_subjects:favSubjects}});
    var d=(res&&res.data)?res.data:null; if(!d) throw new Error('No data');
    if(titleEl) titleEl.innerHTML=title+' Roadmap <span style="font-size:13px;font-weight:400;color:var(--text-2)">· AI Match: <span style="color:var(--cyan)">'+(d.match_score||85)+'%</span></span>';
    var html='<div style="font-size:13px;color:var(--text-2);background:rgba(0,210,255,.05);border:1px solid rgba(0,210,255,.15);border-radius:10px;padding:10px 14px;margin-bottom:14px">🤖 '+(d.match_reason||'Personalised based on your study data')+'</div>';
    (d.phases||[]).forEach(function(p,i){
      html+='<div style="display:flex;gap:16px;margin-bottom:18px">'
        +'<div style="display:flex;flex-direction:column;align-items:center">'
          +'<div style="width:38px;height:38px;border-radius:12px;background:'+(p.color||'var(--cyan)')+'22;display:flex;align-items:center;justify-content:center;font-size:17px;flex-shrink:0">'+(p.icon||'📌')+'</div>'
          +(i<(d.phases.length-1)?'<div style="width:2px;flex:1;background:'+(p.color||'var(--cyan)')+'33;margin:4px 0;min-height:16px"></div>':'')
        +'</div>'
        +'<div style="flex:1">'
          +'<div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">'
            +'<span style="font-family:\'Syne\',sans-serif;font-weight:700;font-size:14px;color:'+(p.color||'var(--cyan)')+'">'+p.phase+'</span>'
            +'<span style="font-size:11px;padding:2px 8px;background:'+(p.color||'var(--cyan)')+'18;color:'+(p.color||'var(--cyan)')+';border-radius:10px">'+p.duration+'</span>'
          +'</div>'
          +(p.tasks||[]).map(function(t){ return '<div style="font-size:13px;color:var(--text-2);padding:3px 0;display:flex;gap:6px"><span style="color:'+(p.color||'var(--cyan)')+';flex-shrink:0">▸</span>'+t+'</div>'; }).join('')
        +'</div>'
      +'</div>';
    });
    if(d.personalized_tip) html+='<div style="background:rgba(245,158,11,.08);border:1px solid rgba(245,158,11,.2);border-radius:12px;padding:12px;margin-top:6px;font-size:13px;color:var(--amber)">💡 <strong>Tip:</strong> '+d.personalized_tip+'</div>';
    if(stepsEl) stepsEl.innerHTML=html;
    var statsEl=document.getElementById('career-stats-card');
    var compEl=document.getElementById('top-companies-card');
    if(statsEl&&d.salary_range) statsEl.innerHTML='<div style="font-family:\'Syne\',sans-serif;font-weight:700;font-size:15px;margin-bottom:12px">📈 Market Stats</div><div style="font-family:\'Syne\',sans-serif;font-weight:800;font-size:20px;color:var(--emerald);margin-bottom:10px">'+d.salary_range+'</div><div>'+(d.key_skills||[]).map(function(s){ return '<span style="font-size:11px;padding:4px 10px;background:var(--cyan-dim);color:var(--cyan);border-radius:6px;font-weight:500;display:inline-block;margin:2px">'+s+'</span>'; }).join('')+'</div>';
    if(compEl&&d.top_companies) compEl.innerHTML='<div style="font-family:\'Syne\',sans-serif;font-weight:700;font-size:15px;margin-bottom:12px">🏢 Top Hirers</div>'+(d.top_companies||[]).map(function(c){ return '<div style="display:flex;align-items:center;gap:10px;padding:8px 12px;background:var(--surface2);border-radius:8px;border:1px solid var(--border);margin-bottom:6px;font-size:13px"><span>🏢</span>'+c+'</div>'; }).join('');
  } catch(e) {
    renderRoadmap(document.getElementById('roadmap-select').value||'software');
    showToast('Using local roadmap (AI unavailable)','info');
  }
}

/* ═══════════ SKILLS TAB ═══════════ */
function renderSkills() {
  var grid=document.getElementById('skills-grid'); if(!grid) return;
  grid.innerHTML=SKILLS_DATA.map(function(cat){
    return '<div class="card"><div style="display:flex;align-items:center;gap:10px;margin-bottom:16px"><span style="font-size:22px">'+cat.icon+'</span><span style="font-family:\'Syne\',sans-serif;font-weight:700;font-size:16px;color:'+cat.color+'">'+cat.cat+'</span></div>'
      +cat.skills.map(function(s){
        return '<div style="margin-bottom:14px">'
          +'<div style="display:flex;justify-content:space-between;margin-bottom:3px"><span style="font-size:14px;font-weight:600">'+s.name+'</span><span style="font-size:12px;font-weight:700;color:'+cat.color+'">'+s.level+'%</span></div>'
          +'<div style="height:6px;background:var(--surface2);border-radius:20px;overflow:hidden;margin-bottom:4px"><div style="height:100%;width:'+s.level+'%;border-radius:20px;background:'+cat.color+';transition:width 1.2s ease"></div></div>'
          +'<div style="font-size:11px;color:var(--text-2)">🏆 <span style="color:'+cat.color+'">'+s.cert+'</span></div>'
        +'</div>';
      }).join('')+'</div>';
  }).join('');
}

/* ═══════════ CHAT TAB ═══════════ */
function initChat() {
  var sugEl=document.getElementById('chat-suggestions');
  if(sugEl && !sugEl.dataset.init) {
    sugEl.dataset.init='1';
    var qs=['What career suits my subjects?','How do I become a software engineer?','What salary can I expect?','Which certification should I get first?','Suggest a 6-month plan for me'];
    if(favSubjects.length>0) qs.unshift('Best career for someone who loves '+favSubjects[0]+'?');
    sugEl.innerHTML=qs.slice(0,5).map(function(q){
      return '<button onclick="quickChat(\''+q.replace(/'/g,"\\'")+'\')" style="text-align:left;background:var(--surface2);border:1px solid var(--border);border-radius:8px;padding:8px 12px;color:var(--text-2);cursor:pointer;font-size:12px;font-family:\'DM Sans\',sans-serif;width:100%;transition:all .2s" onmouseover="this.style.borderColor=\'rgba(0,210,255,.3)\';this.style.color=\'var(--cyan)\'" onmouseout="this.style.borderColor=\'var(--border)\';this.style.color=\'var(--text-2)\'">'+q+'</button>';
    }).join('');
  }
  var pSumEl=document.getElementById('chat-profile-summary');
  if(pSumEl && studentData) {
    var subs=(studentData.subjects||[]).map(function(s){ return s.name; }).join(', ')||'None set';
    var hrs=(studentData.stats&&studentData.stats.total_study_hours)||0;
    var streak=(studentData.stats&&studentData.stats.current_streak)||0;
    pSumEl.innerHTML='📚 <strong style="color:var(--text)">'+subs+'</strong><br>'
      +(favSubjects.length>0?'⭐ Favs: <strong style="color:var(--amber)">'+favSubjects.join(', ')+'</strong><br>':'')
      +'⏱️ Total: <strong style="color:var(--cyan)">'+hrs+'h</strong> · 🔥 <strong style="color:var(--rose)">'+streak+' day streak</strong><br>'
      +'🎓 <strong style="color:var(--text)">'+(studentData.user&&studentData.user.course||'Not set')+'</strong>';
  }
}

function quickChat(msg){ document.getElementById('chat-input').value=msg; sendChat(); }

async function sendChat() {
  var inp=document.getElementById('chat-input');
  var msg=inp?inp.value.trim():''; if(!msg) return;
  var chatEl=document.getElementById('chat-messages'); if(!chatEl) return;
  chatEl.innerHTML+='<div style="display:flex;justify-content:flex-end;margin-bottom:10px;animation:fadeUp .3s ease"><div class="chat-bubble-user">'+esc(msg)+'</div></div>';
  inp.value=''; chatEl.scrollTop=chatEl.scrollHeight;
  var tid='t'+Date.now();
  chatEl.innerHTML+='<div id="'+tid+'" style="display:flex;gap:10px;align-items:flex-start;margin-bottom:10px"><div style="width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,var(--cyan),var(--violet));display:flex;align-items:center;justify-content:center;font-size:12px;flex-shrink:0">🤖</div><div class="chat-bubble-ai"><div class="ai-thinking"><div class="ai-dot"></div><div class="ai-dot"></div><div class="ai-dot"></div></div></div></div>';
  chatEl.scrollTop=chatEl.scrollHeight;
  chatHistory.push({role:'user',content:msg});
  try {
    var res=await API.request('career.php','POST',{type:'chat',extra:{message:msg,history:chatHistory.slice(-6),favorite_subjects:favSubjects}});
    var reply=(res&&res.data&&res.data.message)?res.data.message:'I could not process that. Please try again.';
    chatHistory.push({role:'assistant',content:reply});
    var te=document.getElementById(tid); if(te) te.remove();
    chatEl.innerHTML+='<div style="display:flex;gap:10px;align-items:flex-start;margin-bottom:10px;animation:fadeUp .3s ease"><div style="width:28px;height:28px;border-radius:50%;background:linear-gradient(135deg,var(--cyan),var(--violet));display:flex;align-items:center;justify-content:center;font-size:12px;flex-shrink:0">🤖</div><div class="chat-bubble-ai">'+fmtAI(reply)+'</div></div>';
  } catch(e) {
    var te2=document.getElementById(tid); if(te2) te2.remove();
    chatEl.innerHTML+='<div style="display:flex;gap:10px;margin-bottom:10px"><div style="width:28px;height:28px;border-radius:50%;background:var(--surface2);display:flex;align-items:center;justify-content:center;font-size:12px;flex-shrink:0">🤖</div><div class="chat-bubble-ai" style="color:var(--rose)">Error. Please try again.</div></div>';
  }
  chatEl.scrollTop=chatEl.scrollHeight;
}
function esc(s){ return s.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function fmtAI(s){ return s.replace(/\*\*(.*?)\*\*/g,'<strong>$1</strong>').replace(/^- (.+)$/gm,'<div style="display:flex;gap:6px"><span style="color:var(--cyan)">▸</span><span>$1</span></div>').replace(/\n\n/g,'<br><br>').replace(/\n/g,'<br>'); }

/* ═══════════ QUIZ TAB ═══════════ */
function renderQuiz() {
  if(quizStep>=QUIZ_QUESTIONS.length){ showQuizResult(); return; }
  var q=QUIZ_QUESTIONS[quizStep];
  var pct=Math.round((quizStep/QUIZ_QUESTIONS.length)*100);
  var el=document.getElementById('quiz-content'); if(!el) return;
  el.innerHTML='<div style="margin-bottom:14px"><div style="display:flex;justify-content:space-between;font-size:12px;color:var(--text-2);margin-bottom:6px"><span>Question '+(quizStep+1)+' of '+QUIZ_QUESTIONS.length+'</span><span style="color:var(--cyan)">'+pct+'%</span></div><div style="height:5px;background:var(--surface2);border-radius:20px;overflow:hidden"><div style="height:100%;width:'+pct+'%;border-radius:20px;background:linear-gradient(90deg,var(--cyan),var(--violet));transition:width .5s"></div></div></div>'
    +'<div style="font-size:16px;font-weight:600;margin-bottom:16px;line-height:1.5">'+q.q+'</div>'
    +q.opts.map(function(o,i){ return '<div class="quiz-opt" onclick="answerQ('+i+')"><span style="width:26px;height:26px;border-radius:50%;background:var(--surface);border:1px solid var(--border);display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;flex-shrink:0">'+String.fromCharCode(65+i)+'</span>'+o+'</div>'; }).join('');
}

function answerQ(i){ quizAnswers.push(i); quizStep++; quizStep<QUIZ_QUESTIONS.length?renderQuiz():showQuizResult(); }

function showQuizResult(){
  var score=[0,0,0,0]; quizAnswers.forEach(function(a){ score[a]++; });
  var max=Math.max.apply(null,score), idx=score.indexOf(max);
  var m=[{career:'Software Engineer',icon:'💻',color:'var(--cyan)',id:'software',reason:'You love building and logic-based problem solving.'},{career:'Data Scientist / AI',icon:'📊',color:'var(--violet)',id:'datascience',reason:'You are analytical and enjoy finding patterns in data.'},{career:'Cybersecurity Analyst',icon:'🔐',color:'var(--rose)',id:'cybersecurity',reason:'You think like a defender and love system security.'},{career:'Product Manager',icon:'🎯',color:'#a78bfa',id:'product',reason:'You have leadership instincts and a strategic mindset.'}][idx];
  var panel=document.getElementById('quiz-result-panel');
  if(panel){panel.style.display='block';panel.innerHTML='<div style="text-align:center;padding:20px 0"><div style="font-size:54px;margin-bottom:12px;animation:float 2s ease-in-out infinite">'+m.icon+'</div><div style="font-family:\'Syne\',sans-serif;font-weight:800;font-size:19px;margin-bottom:8px">Your Best Fit:</div><div style="font-size:22px;font-weight:700;color:'+m.color+';margin-bottom:8px">'+m.career+'</div><div style="font-size:13px;color:var(--text-2);margin-bottom:18px;line-height:1.6">'+m.reason+'</div><button onclick="goRoadmap(\''+m.id+'\')" class="btn-primary" style="margin-bottom:10px">View My Roadmap →</button><div><button onclick="restartQuiz()" style="background:none;border:none;color:var(--text-2);cursor:pointer;font-size:13px;text-decoration:underline">Retake Quiz</button></div></div>';}
  var qc=document.getElementById('quiz-content'); if(qc) qc.innerHTML='<div style="text-align:center;padding:20px;color:var(--text-2)">✅ Quiz complete! See your results →</div>';
}

function restartQuiz(){ quizAnswers=[]; quizStep=0; var p=document.getElementById('quiz-result-panel'); if(p) p.style.display='none'; renderQuiz(); }

/* ═══════════ RESOURCES TAB ═══════════ */
function renderResources(){
  var grid=document.getElementById('resources-grid'); if(!grid) return;
  grid.innerHTML=RESOURCES.map(function(cat){
    return '<div class="card"><div style="display:flex;align-items:center;gap:10px;margin-bottom:14px"><span style="font-size:18px">'+cat.cat.split(' ')[0]+'</span><span style="font-family:\'Syne\',sans-serif;font-weight:700;font-size:15px;color:'+cat.color+'">'+cat.cat.slice(2)+'</span></div>'
      +cat.items.map(function(item){
        return '<a class="resource-row" href="'+item.link+'" target="_blank" rel="noopener">'
          +'<div style="width:36px;height:36px;border-radius:8px;background:'+cat.color+'18;display:flex;align-items:center;justify-content:center;font-size:14px;flex-shrink:0">🔗</div>'
          +'<div style="flex:1"><div style="font-size:13px;font-weight:600;color:var(--text)">'+item.name+'</div><div style="font-size:12px;color:var(--text-2);margin-top:1px">'+item.desc+'</div></div>'
          +'<span style="font-size:11px;padding:3px 8px;border-radius:6px;background:'+cat.color+'18;color:'+cat.color+';font-weight:600;white-space:nowrap">'+item.type+'</span>'
        +'</a>';
      }).join('')+'</div>';
  }).join('');
}

/* ═══════════ INIT ═══════════ */
initPage();
</script>
</body>
</html>
