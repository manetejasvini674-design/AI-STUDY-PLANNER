-- =====================================================
-- StudyAI - Complete Database Schema
-- Import this in phpMyAdmin after creating database
-- Database Name: study_planner_db
-- =====================================================

CREATE DATABASE IF NOT EXISTS study_planner_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE study_planner_db;

-- =====================================================
-- 1. USERS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  course VARCHAR(100) DEFAULT 'Computer Science',
  semester VARCHAR(20) DEFAULT '1',
  daily_hours INT DEFAULT 4,
  study_preference ENUM('morning','afternoon','evening') DEFAULT 'morning',
  favorite_subjects TEXT DEFAULT NULL,
  avatar_initials VARCHAR(3) DEFAULT '',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- =====================================================
-- 2. SUBJECTS TABLE (per user)
-- =====================================================
CREATE TABLE IF NOT EXISTS subjects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  name VARCHAR(100) NOT NULL,
  difficulty ENUM('easy','medium','hard') DEFAULT 'medium',
  exam_date DATE,
  color VARCHAR(20) DEFAULT '#00d2ff',
  credits INT DEFAULT 3,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================
-- 3. STUDY SCHEDULE TABLE (AI Generated)
-- =====================================================
CREATE TABLE IF NOT EXISTS study_schedule (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  subject VARCHAR(100) NOT NULL,
  topic VARCHAR(200) DEFAULT '',
  study_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  color VARCHAR(20) DEFAULT '#00d2ff',
  bg_color VARCHAR(40) DEFAULT 'rgba(0,210,255,.08)',
  completed TINYINT(1) DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================
-- 4. TASKS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS tasks (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  name VARCHAR(255) NOT NULL,
  subject VARCHAR(100) DEFAULT 'General',
  priority ENUM('High','Medium','Low') DEFAULT 'Medium',
  deadline DATE,
  estimated_time VARCHAR(20) DEFAULT '',
  status ENUM('todo','inprogress','done') DEFAULT 'todo',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================
-- 5. STUDY SESSIONS TABLE (Timer/Pomodoro)
-- =====================================================
CREATE TABLE IF NOT EXISTS study_sessions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  subject VARCHAR(100) NOT NULL,
  duration_minutes INT NOT NULL DEFAULT 0,
  session_date DATE NOT NULL,
  session_type ENUM('focus','break','long_break') DEFAULT 'focus',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================
-- 6. NOTIFICATIONS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS notifications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  title VARCHAR(100) NOT NULL,
  message TEXT NOT NULL,
  type ENUM('reminder','achievement','warning','info') DEFAULT 'info',
  icon VARCHAR(10) DEFAULT '🔔',
  status ENUM('unread','read') DEFAULT 'unread',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================
-- 7. CGPA RECORDS TABLE
-- =====================================================
CREATE TABLE IF NOT EXISTS cgpa_records (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  semester_label VARCHAR(30) DEFAULT 'Current',
  subject VARCHAR(100) NOT NULL,
  credits INT NOT NULL DEFAULT 3,
  grade VARCHAR(5) NOT NULL,
  grade_points DECIMAL(3,2) DEFAULT 0.00,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================
-- 8. USER STREAKS / GOALS
-- =====================================================
CREATE TABLE IF NOT EXISTS user_stats (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  current_streak INT DEFAULT 0,
  longest_streak INT DEFAULT 0,
  total_study_hours INT DEFAULT 0,
  tasks_completed INT DEFAULT 0,
  last_active_date DATE,
  weekly_goal_hours INT DEFAULT 20,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- =====================================================
-- SAMPLE DATA (optional demo user)
-- =====================================================
-- Password: demo123 (bcrypt hash)
INSERT IGNORE INTO users (id, name, email, password, course, semester, daily_hours) VALUES
(1, 'Arjun Rao', 'demo@studyai.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Computer Science', '3', 4);

INSERT IGNORE INTO user_stats (user_id, current_streak, longest_streak, total_study_hours, tasks_completed, weekly_goal_hours) VALUES
(1, 7, 12, 142, 38, 20);

INSERT IGNORE INTO subjects (user_id, name, difficulty, exam_date, color) VALUES
(1, 'Mathematics', 'hard', DATE_ADD(CURDATE(), INTERVAL 21 DAY), '#10b981'),
(1, 'Physics', 'medium', DATE_ADD(CURDATE(), INTERVAL 14 DAY), '#00d2ff'),
(1, 'Chemistry', 'hard', DATE_ADD(CURDATE(), INTERVAL 5 DAY), '#f59e0b'),
(1, 'English', 'easy', DATE_ADD(CURDATE(), INTERVAL 28 DAY), '#7c3aed');

-- =====================================================
-- MIGRATION: Add favorite_subjects column if missing
-- Run this if you already have the database imported
-- =====================================================
ALTER TABLE users ADD COLUMN IF NOT EXISTS favorite_subjects TEXT DEFAULT NULL;
