# 🧠 StudyAI – Full Stack Study Planner

A complete AI-powered study planner with PHP + MySQL backend, featuring an **AI Career Guide** that auto-analyzes each student's actual subjects, study hours, CGPA, and performance data.

---

## 📁 Project Structure

```
studyai/
├── index.html              ← Landing page
├── login.html              ← Login page
├── register.html           ← Register page
├── dashboard.html          ← Main dashboard
├── schedule.html           ← AI study schedule
├── tasks.html              ← Task manager (Kanban)
├── analytics.html          ← Study analytics & charts
├── timer.html              ← Pomodoro study timer
├── notifications.html      ← Notifications
├── profile-setup.html      ← Profile & subjects setup
├── cgpa-planner.html       ← CGPA calculator
├── career-guide.html       ← 🤖 AI Career Guide
├── config.php              ← Database config
├── database.sql            ← Full DB schema + demo data
├── js/
│   └── api.js              ← Shared API client
└── api/
    ├── auth.php            ← Login / Register / Logout
    ├── dashboard.php       ← Dashboard aggregated data
    ├── tasks.php           ← Task CRUD
    ├── schedule.php        ← AI schedule generation
    ├── analytics.php       ← Analytics & session logging
    ├── notifications.php   ← Notifications
    ├── profile.php         ← Profile & subjects
    ├── cgpa.php            ← CGPA records
    └── career.php          ← 🤖 AI Career Guide API
```

---

## ⚙️ Setup (XAMPP)

### Step 1 – Copy Files
Extract to: `C:\xampp\htdocs\studyai\`

### Step 2 – Start XAMPP
Open XAMPP Control Panel → Start **Apache** + **MySQL**

### Step 3 – Create Database
1. Open `http://localhost/phpmyadmin`
2. Click **New** → Name it `study_planner_db` → Click **Create**
3. Click the database → **Import** tab → Choose `database.sql` → Click **Go**

### Step 4 – Configure (if needed)
Edit `config.php`:
```php
define('DB_USER', 'root');   // your phpMyAdmin username
define('DB_PASS', '');       // your phpMyAdmin password (blank by default)
```

### Step 5 – Open App
Visit: `http://localhost/studyai/`

---

## 🔑 Demo Account
| Field | Value |
|-------|-------|
| Email | demo@studyai.com |
| Password | password |

---

## 🤖 AI Career Guide – How It Works

The Career Guide is **fully AI-powered** and personalized per student:

### Data it reads from the database:
- Student's registered **subjects** (name + difficulty)
- **Study session hours** per subject (which subjects studied most)
- **CGPA records** (grades per subject — detects A/O grades)
- **Study stats** (total hours, streak, tasks completed)
- **User profile** (course/stream, semester)
- **Quiz answers** (5-question career quiz)

### What AI generates automatically:
| Feature | Description |
|---------|-------------|
| **AI Analysis** | Auto-loads on page open. Returns top 4 matched careers with personalized match % and reasons based on actual subjects |
| **Career Roadmap** | Sends selected career + student data to AI → returns 12-month personalized roadmap with tips based on streak/hours |
| **CareerAI Chat** | Conversational AI that knows student's full profile. Answers "which career suits my subjects?" using real data |
| **Career Quiz** | Quiz answers + subject data sent to AI → combined personalized career recommendation |
| **Career Tracks** | Static grid with AI-matched careers highlighted |

### To enable real AI (optional):
Set `ANTHROPIC_API_KEY` as a server environment variable in XAMPP:
- Windows: Add to `C:\xampp\apache\conf\httpd.conf`:
  ```
  SetEnv ANTHROPIC_API_KEY your_key_here
  ```
- Or set in PHP: add `putenv('ANTHROPIC_API_KEY=your_key');` at top of `config.php`

**Without API key:** Falls back to a smart rule-based engine that still analyzes subjects/CGPA to suggest careers.

---

## 🗺️ User Flow

1. **Register** → creates account
2. **Profile Setup** → add subjects (name, difficulty, exam date)
3. **Generate AI Schedule** → schedule page auto-generates study plan
4. **Study Timer** → log study sessions (saved to DB)
5. **Tasks** → create & manage tasks in Kanban board
6. **CGPA Planner** → enter grades, calculate CGPA
7. **Career Guide** → AI reads all your data → personalized career paths
8. **Analytics** → view charts based on real logged data

---

## 📋 All Pages & APIs

| Page | PHP API | What it does |
|------|---------|-------------|
| login.html | auth.php | Session login with bcrypt |
| register.html | auth.php | Register + welcome notification |
| dashboard.html | dashboard.php | Aggregated stats, today's schedule |
| schedule.html | schedule.php | AI schedule generation, mark complete |
| tasks.html | tasks.php | Full CRUD, Kanban drag-and-drop |
| analytics.html | analytics.php | Charts, streaks, session history |
| timer.html | analytics.php | Log sessions, update streak |
| notifications.html | notifications.php | Read/delete notifications |
| profile-setup.html | profile.php | Add subjects, update profile |
| cgpa-planner.html | cgpa.php | Save/calculate CGPA per semester |
| career-guide.html | career.php | AI career analysis, roadmaps, chat |
