<?php
// =====================================================
// StudyAI - Tasks API
// File: api/tasks.php
// =====================================================

require_once '../config.php';
startSession();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

$userId = getAuthUser();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$db     = getDB();

switch ($method) {

    // ── GET ALL TASKS ──────────────────────────────
    case 'GET':
        $status = $_GET['status'] ?? '';
        if ($status) {
            $stmt = $db->prepare('SELECT * FROM tasks WHERE user_id=? AND status=? ORDER BY created_at DESC');
            $stmt->bind_param('is', $userId, $status);
        } else {
            $stmt = $db->prepare('SELECT * FROM tasks WHERE user_id=? ORDER BY created_at DESC');
            $stmt->bind_param('i', $userId);
        }
        $stmt->execute();
        $tasks = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

        // Stats
        $stmtS = $db->prepare('SELECT status, COUNT(*) as cnt FROM tasks WHERE user_id=? GROUP BY status');
        $stmtS->bind_param('i', $userId);
        $stmtS->execute();
        $statsRows = $stmtS->get_result()->fetch_all(MYSQLI_ASSOC);
        $stats = ['todo' => 0, 'inprogress' => 0, 'done' => 0];
        foreach ($statsRows as $r) $stats[$r['status']] = (int)$r['cnt'];

        sendJSON(['success' => true, 'tasks' => $tasks, 'stats' => $stats]);
        break;

    // ── CREATE TASK ────────────────────────────────
    case 'POST':
        $data = getRequestBody();
        $name     = trim($data['name'] ?? '');
        $subject  = $data['subject']  ?? 'General';
        $priority = $data['priority'] ?? 'Medium';
        $deadline = $data['deadline'] ?? null;
        $estTime  = $data['time']     ?? '';
        $status   = $data['status']   ?? 'todo';

        if (!$name) sendJSON(['success' => false, 'error' => 'Task name is required']);

        $stmt = $db->prepare('INSERT INTO tasks (user_id, name, subject, priority, deadline, estimated_time, status) VALUES (?,?,?,?,?,?,?)');
        $stmt->bind_param('issssss', $userId, $name, $subject, $priority, $deadline, $estTime, $status);
        $stmt->execute();
        $id = $db->insert_id;

        $task = ['id'=>$id,'user_id'=>$userId,'name'=>$name,'subject'=>$subject,'priority'=>$priority,'deadline'=>$deadline,'estimated_time'=>$estTime,'status'=>$status];
        sendJSON(['success' => true, 'task' => $task]);
        break;

    // ── UPDATE TASK ────────────────────────────────
    case 'PUT':
        $data = getRequestBody();
        $id = (int)($data['id'] ?? 0);
        if (!$id) sendJSON(['success' => false, 'error' => 'Task ID required']);

        // Build update
        $fields = [];
        $types  = '';
        $values = [];

        foreach (['name','subject','priority','deadline','estimated_time','status'] as $f) {
            $key = $f === 'estimated_time' ? 'time' : $f;
            if (isset($data[$key])) {
                $fields[] = "$f = ?";
                $types   .= 's';
                $values[] = $data[$key];
            }
        }

        if (empty($fields)) sendJSON(['success' => false, 'error' => 'Nothing to update']);

        $types  .= 'ii';
        $values[] = $userId;
        $values[] = $id;

        $stmt = $db->prepare('UPDATE tasks SET ' . implode(', ', $fields) . ' WHERE user_id=? AND id=?');
        $stmt->bind_param($types, ...$values);
        $stmt->execute();

        // If completed, update stats
        if (isset($data['status']) && $data['status'] === 'done') {
            $stmt_tc = $db->prepare("UPDATE user_stats SET tasks_completed = tasks_completed + 1 WHERE user_id = ?");
            $stmt_tc->bind_param("i", $userId);
            $stmt_tc->execute();
        }

        sendJSON(['success' => true]);
        break;

    // ── DELETE TASK ────────────────────────────────
    case 'DELETE':
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) sendJSON(['success' => false, 'error' => 'Task ID required']);
        $stmt = $db->prepare('DELETE FROM tasks WHERE id=? AND user_id=?');
        $stmt->bind_param('ii', $id, $userId);
        $stmt->execute();
        sendJSON(['success' => true]);
        break;
}
