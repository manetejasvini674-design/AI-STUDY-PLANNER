<?php
// =====================================================
// StudyAI - CGPA Planner API
// File: api/cgpa.php
// =====================================================

require_once '../config.php';
startSession();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

$userId = getAuthUser();
$method = $_SERVER['REQUEST_METHOD'];
$db     = getDB();

// Grade to points mapping (10-point scale)
$gradePoints = [
    'O'  => 10, 'A+' => 9, 'A'  => 8,
    'B+' => 7,  'B'  => 6, 'C'  => 5,
    'D'  => 4,  'F'  => 0,
    // Also support number grades
    '10'=>10,'9'=>9,'8'=>8,'7'=>7,'6'=>6,'5'=>5,'4'=>4,'0'=>0
];

switch ($method) {

    case 'GET':
        $sem = $_GET['semester'] ?? '';
        if ($sem) {
            $stmt = $db->prepare('SELECT * FROM cgpa_records WHERE user_id=? AND semester_label=? ORDER BY created_at');
            $stmt->bind_param('is', $userId, $sem);
        } else {
            $stmt = $db->prepare('SELECT * FROM cgpa_records WHERE user_id=? ORDER BY semester_label, created_at');
            $stmt->bind_param('i', $userId);
        }
        $stmt->execute();
        $records = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

        // Calculate CGPA
        $totalPoints  = 0;
        $totalCredits = 0;
        foreach ($records as $r) {
            $totalPoints  += $r['grade_points'] * $r['credits'];
            $totalCredits += $r['credits'];
        }
        $cgpa = $totalCredits > 0 ? round($totalPoints / $totalCredits, 2) : 0;

        sendJSON(['success'=>true,'records'=>$records,'cgpa'=>$cgpa,'total_credits'=>$totalCredits]);
        break;

    case 'POST':
        $data     = getRequestBody();
        $semLabel = $data['semester_label'] ?? 'Semester 1';
        $subjects = $data['subjects'] ?? [];

        if (empty($subjects)) sendJSON(['success'=>false,'error'=>'No subjects provided']);

        // Delete old records for this semester
        $stmt = $db->prepare('DELETE FROM cgpa_records WHERE user_id=? AND semester_label=?');
        $stmt->bind_param('is', $userId, $semLabel);
        $stmt->execute();

        $inserted = 0;
        foreach ($subjects as $sub) {
            $name    = trim($sub['name'] ?? '');
            $credits = (int)($sub['credits'] ?? 3);
            $grade   = strtoupper(trim($sub['grade'] ?? 'B'));
            if (!$name || !$grade) continue;

            $gp = $gradePoints[$grade] ?? 0;

            $stmt = $db->prepare('INSERT INTO cgpa_records (user_id, semester_label, subject, credits, grade, grade_points) VALUES (?,?,?,?,?,?)');
            $stmt->bind_param('isissd', $userId, $semLabel, $name, $credits, $grade, $gp);
            $stmt->execute();
            $inserted++;
        }

        // Recalculate overall CGPA
        $stmt = $db->prepare('SELECT SUM(grade_points * credits) as total, SUM(credits) as cred FROM cgpa_records WHERE user_id=?');
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $row  = $stmt->get_result()->fetch_assoc();
        $cgpa = $row['cred'] > 0 ? round($row['total'] / $row['cred'], 2) : 0;

        sendJSON(['success'=>true,'message'=>"$inserted subjects saved",'cgpa'=>$cgpa]);
        break;

    case 'DELETE':
        $id = (int)($_GET['id'] ?? 0);
        if ($id) {
            $stmt = $db->prepare('DELETE FROM cgpa_records WHERE id=? AND user_id=?');
            $stmt->bind_param('ii', $id, $userId);
        } else {
            $stmt = $db->prepare('DELETE FROM cgpa_records WHERE user_id=?');
            $stmt->bind_param('i', $userId);
        }
        $stmt->execute();
        sendJSON(['success'=>true]);
        break;
}
