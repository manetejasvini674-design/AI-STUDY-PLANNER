<?php
// =====================================================
// StudyAI - Auth API
// File: api/auth.php
// Handles: register, login, logout, check
// =====================================================

require_once '../config.php';
startSession();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST, GET');
header('Access-Control-Allow-Headers: Content-Type');

$action = $_GET['action'] ?? $_POST['action'] ?? '';

switch ($action) {

    // ── REGISTER ──────────────────────────────────
    case 'register':
        $data = getRequestBody();
        $name     = trim($data['name'] ?? '');
        $email    = strtolower(trim($data['email'] ?? ''));
        $password = $data['password'] ?? '';
        $course   = $data['course'] ?? 'Computer Science';
        $semester = $data['semester'] ?? '1';

        if (!$name || !$email || !$password) {
            sendJSON(['success' => false, 'error' => 'All fields are required']);
        }
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            sendJSON(['success' => false, 'error' => 'Invalid email address']);
        }
        if (strlen($password) < 6) {
            sendJSON(['success' => false, 'error' => 'Password must be at least 6 characters']);
        }

        $db = getDB();

        // Check if email exists
        $stmt = $db->prepare('SELECT id FROM users WHERE email = ?');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        if ($stmt->get_result()->num_rows > 0) {
            sendJSON(['success' => false, 'error' => 'Email already registered']);
        }

        $hash = password_hash($password, PASSWORD_BCRYPT);
        $initials = strtoupper(implode('', array_map(fn($w) => $w[0], explode(' ', $name))));
        $initials = substr($initials, 0, 2);

        $stmt = $db->prepare('INSERT INTO users (name, email, password, course, semester, avatar_initials) VALUES (?,?,?,?,?,?)');
        $stmt->bind_param('ssssss', $name, $email, $hash, $course, $semester, $initials);
        $stmt->execute();
        $userId = $db->insert_id;

        // Create stats row
        $stmt = $db->prepare('INSERT INTO user_stats (user_id, weekly_goal_hours) VALUES (?, 20)');
        $stmt->bind_param('i', $userId);
        $stmt->execute();

        // Create welcome notification
        $welcomeMsg = "Welcome to StudyAI, $name! Your AI study planner is ready.";
        $title = "Welcome! 🎉";
        $stmt = $db->prepare('INSERT INTO notifications (user_id, title, message, type, icon) VALUES (?,?,?,?,?)');
        $stmt->bind_param('issss', $userId, $title, $welcomeMsg, 'info', '🎉');
        $stmt->execute();

        $_SESSION['user_id']   = $userId;
        $_SESSION['user_name'] = $name;
        $_SESSION['user_email']= $email;

        sendJSON([
            'success' => true,
            'user' => ['id' => $userId, 'name' => $name, 'email' => $email, 'initials' => $initials, 'course' => $course, 'semester' => $semester],
            'redirect' => 'profile-setup.php'
        ]);
        break;

    // ── LOGIN ──────────────────────────────────────
    case 'login':
        $data = getRequestBody();
        $email    = strtolower(trim($data['email'] ?? ''));
        $password = $data['password'] ?? '';

        if (!$email || !$password) {
            sendJSON(['success' => false, 'error' => 'Email and password are required']);
        }

        $db = getDB();
        $stmt = $db->prepare('SELECT id, name, email, password, course, semester, avatar_initials FROM users WHERE email = ?');
        $stmt->bind_param('s', $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();

        if (!$user || !password_verify($password, $user['password'])) {
            sendJSON(['success' => false, 'error' => 'Invalid email or password']);
        }

        // Update last active
        $uid = $user['id'];
        $today = date('Y-m-d');
        $stmt = $db->prepare('UPDATE user_stats SET last_active_date=? WHERE user_id=?');
        $stmt->bind_param('si', $today, $uid);
        $stmt->execute();

        $_SESSION['user_id']   = $user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['user_email']= $user['email'];

        sendJSON([
            'success' => true,
            'user' => [
                'id'       => $user['id'],
                'name'     => $user['name'],
                'email'    => $user['email'],
                'initials' => $user['avatar_initials'] ?: strtoupper(substr($user['name'], 0, 2)),
                'course'   => $user['course'],
                'semester' => $user['semester']
            ],
            'redirect' => 'dashboard.php'
        ]);
        break;

    // ── LOGOUT ─────────────────────────────────────
    case 'logout':
        session_destroy();
        sendJSON(['success' => true, 'redirect' => 'login.php']);
        break;

    // ── CHECK SESSION ──────────────────────────────
    case 'check':
        if (isset($_SESSION['user_id'])) {
            $db = getDB();
            $uid = $_SESSION['user_id'];
            $stmt = $db->prepare('SELECT id, name, email, course, semester, avatar_initials FROM users WHERE id = ?');
            $stmt->bind_param('i', $uid);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            sendJSON(['success' => true, 'user' => $user, 'loggedIn' => true]);
        } else {
            sendJSON(['success' => true, 'loggedIn' => false]);
        }
        break;

    default:
        sendJSON(['success' => false, 'error' => 'Unknown action'], 400);
}
