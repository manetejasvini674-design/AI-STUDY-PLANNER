<?php
// =====================================================
// StudyAI - Schedule API (AI Generation Engine)
// File: api/schedule.php
// =====================================================

require_once '../config.php';
startSession();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

$userId = getAuthUser();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$db     = getDB();

// ── COLOR MAP ──────────────────────────────────────
$subjectColors = [
    0 => ['color'=>'#10b981','bg'=>'rgba(16,185,129,.08)'],
    1 => ['color'=>'#00d2ff','bg'=>'rgba(0,210,255,.08)'],
    2 => ['color'=>'#f59e0b','bg'=>'rgba(245,158,11,.08)'],
    3 => ['color'=>'#7c3aed','bg'=>'rgba(124,58,237,.08)'],
    4 => ['color'=>'#ec4899','bg'=>'rgba(236,72,153,.08)'],
    5 => ['color'=>'#f43f5e','bg'=>'rgba(244,63,94,.08)'],
];

// ── DIFFICULTY WEIGHTS ─────────────────────────────
$diffWeight = ['easy'=>1, 'medium'=>2, 'hard'=>3];

switch ($method) {

    // ── GET SCHEDULE ───────────────────────────────
    case 'GET':
        $date = $_GET['date'] ?? date('Y-m-d');
        $week = $_GET['week'] ?? '';

        if ($week) {
            // Get week's schedule
            $start = date('Y-m-d', strtotime('monday this week'));
            $end   = date('Y-m-d', strtotime('sunday this week'));
            $stmt  = $db->prepare('SELECT * FROM study_schedule WHERE user_id=? AND study_date BETWEEN ? AND ? ORDER BY study_date, start_time');
            $stmt->bind_param('iss', $userId, $start, $end);
        } else {
            $stmt = $db->prepare('SELECT * FROM study_schedule WHERE user_id=? AND study_date=? ORDER BY start_time');
            $stmt->bind_param('is', $userId, $date);
        }
        $stmt->execute();
        $schedule = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
        sendJSON(['success' => true, 'schedule' => $schedule]);
        break;

    case 'POST':
        if ($action === 'generate') {
            // Fetch user data including favorite_subjects
            $stmt = $db->prepare('SELECT daily_hours, study_preference, favorite_subjects FROM users WHERE id=?');
            $stmt->bind_param('i', $userId);
            $stmt->execute();
            $user = $stmt->get_result()->fetch_assoc();
            $dailyHours = $user['daily_hours'] ?? 4;
            $pref       = $user['study_preference'] ?? 'morning';
            $favSubsRaw = $user['favorite_subjects'] ?? null;
            $favSubs    = $favSubsRaw ? (json_decode($favSubsRaw, true) ?: []) : [];

            // Fetch subjects
            $stmt = $db->prepare('SELECT * FROM subjects WHERE user_id=? ORDER BY exam_date ASC');
            $stmt->bind_param('i', $userId);
            $stmt->execute();
            $subjects = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

            if (empty($subjects)) {
                sendJSON(['success' => false, 'error' => 'Please add your subjects first in Profile Setup']);
            }

            // Calculate priority weights
            $today = new DateTime();
            $totalWeight = 0;
            $subjectData = [];

            foreach ($subjects as $i => $sub) {
                $weight = $diffWeight[$sub['difficulty']] ?? 2;

                // Boost weight for favorite subjects (user's preferred focus)
                if (!empty($favSubs) && in_array($sub['name'], $favSubs)) {
                    $weight *= 1.5;
                }

                if ($sub['exam_date']) {
                    $examDate = new DateTime($sub['exam_date']);
                    $daysLeft = (int)$today->diff($examDate)->days;
                    // Closer exam = higher weight
                    if ($daysLeft <= 7)  $weight *= 3;
                    elseif ($daysLeft <= 14) $weight *= 2;
                    elseif ($daysLeft <= 21) $weight *= 1.5;
                }
                $totalWeight += $weight;
                $colorSet = $subjectColors[$i % count($subjectColors)];
                $subjectData[] = array_merge($sub, [
                    'weight'    => $weight,
                    'color'     => $colorSet['color'],
                    'bg'        => $colorSet['bg'],
                    'hours'     => 0,
                    'isFavorite'=> in_array($sub['name'], $favSubs)
                ]);
            }

            // Allocate hours per subject
            foreach ($subjectData as &$sub) {
                $sub['hours'] = round(($sub['weight'] / $totalWeight) * $dailyHours, 1);
                if ($sub['hours'] < 0.5) $sub['hours'] = 0.5;
            }
            unset($sub);

            // Define start times based on preference
            $startHours = [
                'morning'   => 7,
                'afternoon' => 12,
                'evening'   => 16
            ];
            $startHour = $startHours[$pref] ?? 7;

            // ── DYNAMIC TOPIC GENERATOR ───────────────────
            // Topics are generated from the user's actual subject names
            // not hardcoded lists — fully personalized
            $topicTemplates = [
                'Concept Review',
                'Practice Problems',
                'Past Papers',
                'Quick Revision',
                'Mock Test',
                'Deep Study Session',
                'Formula/Rule Review',
                'Chapter Summary',
                'Exercise Sets',
                'Important Questions',
                'Exam Prep',
                'Weak Areas Focus',
                'Sample Questions',
                'Revision Quiz',
            ];

            // Build per-subject topic list dynamically
            $subjectTopics = [];
            foreach ($subjectData as $sub) {
                $name = $sub['name'];
                // Generate context-specific topics based on subject name keywords
                $custom = [];
                $nl = strtolower($name);
                if (str_contains($nl, 'math') || str_contains($nl, 'calculus') || str_contains($nl, 'algebra')) {
                    $custom = ['Problem Sets', 'Formula Derivations', 'Integration Practice', 'Equation Solving', 'Theorem Proofs'];
                } elseif (str_contains($nl, 'physics')) {
                    $custom = ['Numerical Problems', 'Law Applications', 'Diagram Practice', 'Formula Sheet', 'Lab Questions'];
                } elseif (str_contains($nl, 'chem')) {
                    $custom = ['Reaction Mechanisms', 'Equation Balancing', 'Periodic Table Review', 'Organic Structures', 'Lab Prep'];
                } elseif (str_contains($nl, 'bio') || str_contains($nl, 'biology')) {
                    $custom = ['Diagram Labeling', 'Process Flow Review', 'Term Definitions', 'MCQ Practice', 'Case Studies'];
                } elseif (str_contains($nl, 'english') || str_contains($nl, 'lang') || str_contains($nl, 'literature')) {
                    $custom = ['Essay Writing', 'Grammar Drills', 'Comprehension Practice', 'Vocabulary Building', 'Writing Review'];
                } elseif (str_contains($nl, 'history') || str_contains($nl, 'social')) {
                    $custom = ['Timeline Review', 'Event Analysis', 'Map Study', 'Source Evaluation', 'Essay Prep'];
                } elseif (str_contains($nl, 'computer') || str_contains($nl, 'programming') || str_contains($nl, 'code')) {
                    $custom = ['Coding Practice', 'Algorithm Study', 'Debug Exercises', 'Project Work', 'Documentation Review'];
                } elseif (str_contains($nl, 'econom') || str_contains($nl, 'commerce') || str_contains($nl, 'business')) {
                    $custom = ['Case Study Analysis', 'Concept Mapping', 'Graph Interpretation', 'Theory Review', 'Numerical Practice'];
                } elseif (str_contains($nl, 'account')) {
                    $custom = ['Journal Entries', 'Balance Sheet Practice', 'Ledger Work', 'Trial Balance', 'Financial Ratios'];
                }
                // Merge custom with generic templates, deduplicated
                $merged = array_unique(array_merge($custom, $topicTemplates));
                $subjectTopics[$name] = $merged;
            }

            // Generate 7 days of schedule
            $stmt = $db->prepare('DELETE FROM study_schedule WHERE user_id=? AND study_date >= ?');
            $weekStart = date('Y-m-d');
            $stmt->bind_param('is', $userId, $weekStart);
            $stmt->execute();

            $inserted = [];
            for ($day = 0; $day < 7; $day++) {
                $date = date('Y-m-d', strtotime("+$day days"));
                $dayOfWeek = (int)date('N', strtotime($date)); // 1=Mon, 7=Sun
                $currentHour = $startHour;
                $currentMin  = 0;

                // Sunday = lighter schedule (only favorite subjects, or first subject)
                if ($dayOfWeek === 7) {
                    $daySubjects = array_filter($subjectData, fn($s) => $s['isFavorite']);
                    if (empty($daySubjects)) $daySubjects = array_slice($subjectData, 0, 1);
                    $daySubjects = array_values($daySubjects);
                } else {
                    $daySubjects = $subjectData;
                }

                foreach ($daySubjects as $i => $sub) {
                    $dur = $dayOfWeek === 7 ? 1 : $sub['hours'];
                    $startTime = sprintf('%02d:%02d:00', $currentHour, $currentMin);
                    $endMinutes = $currentHour * 60 + $currentMin + (int)($dur * 60);
                    $endTime = sprintf('%02d:%02d:00', floor($endMinutes / 60), $endMinutes % 60);

                    // Pick topic: rotate through subject-specific topic list
                    $topicList = $subjectTopics[$sub['name']] ?? $topicTemplates;
                    $topic = $topicList[($day * 3 + $i * 7) % count($topicList)];
                    // Prepend subject name to topic for clarity
                    $topicLabel = $sub['name'] . ' – ' . $topic;

                    $stmt = $db->prepare('INSERT INTO study_schedule (user_id, subject, topic, study_date, start_time, end_time, color, bg_color) VALUES (?,?,?,?,?,?,?,?)');
                    $stmt->bind_param('isssssss', $userId, $sub['name'], $topicLabel, $date, $startTime, $endTime, $sub['color'], $sub['bg']);
                    $stmt->execute();

                    $inserted[] = [
                        'subject' => $sub['name'],
                        'date'    => $date,
                        'start'   => $startTime,
                        'end'     => $endTime,
                        'topic'   => $topicLabel
                    ];

                    // Add 30 min break between subjects
                    $currentHour = (int)floor(($endMinutes + 30) / 60);
                    $currentMin  = ($endMinutes + 30) % 60;
                }
            }

            // Add notification
            $title = "Schedule Generated 🗓️";
            $favNote = !empty($favSubs) ? " (priority boost for: " . implode(', ', $favSubs) . ")" : "";
            $msg = "Your AI-powered study schedule for the next 7 days has been created{$favNote}!";
            $stmt = $db->prepare('INSERT INTO notifications (user_id, title, message, type, icon) VALUES (?,?,?,?,?)');
            $stmt->bind_param('issss', $userId, $title, $msg, 'info', '🤖');
            $stmt->execute();

            sendJSON(['success' => true, 'message' => 'Schedule generated!', 'sessions' => count($inserted)]);
        }
        break;

    // ── MARK COMPLETE ──────────────────────────────
    case 'PUT':
        $data = getRequestBody();
        $id = (int)($data['id'] ?? 0);
        if (!$id) sendJSON(['success' => false, 'error' => 'ID required']);

        $stmt = $db->prepare('UPDATE study_schedule SET completed=1 WHERE id=? AND user_id=?');
        $stmt->bind_param('ii', $id, $userId);
        $stmt->execute();
        sendJSON(['success' => true]);
        break;

    // ── DELETE SCHEDULE ────────────────────────────
    case 'DELETE':
        $stmt = $db->prepare('DELETE FROM study_schedule WHERE user_id=? AND study_date >= ?');
        $today = date('Y-m-d');
        $stmt->bind_param('is', $userId, $today);
        $stmt->execute();
        sendJSON(['success' => true, 'message' => 'Schedule cleared']);
        break;
}
