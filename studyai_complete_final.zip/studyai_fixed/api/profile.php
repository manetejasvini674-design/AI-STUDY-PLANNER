<?php
// =====================================================
// StudyAI - Profile & Subjects API
// File: api/profile.php
// =====================================================

require_once '../config.php';
startSession();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

$userId = getAuthUser();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$db     = getDB();

switch ($method) {

    // ── GET PROFILE + SUBJECTS ─────────────────────
    case 'GET':
        $stmt = $db->prepare('SELECT id, name, email, course, semester, daily_hours, study_preference, favorite_subjects, avatar_initials FROM users WHERE id=?');
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $user = $stmt->get_result()->fetch_assoc();

        $stmt2 = $db->prepare('SELECT * FROM subjects WHERE user_id=? ORDER BY exam_date ASC');
        $stmt2->bind_param('i', $userId);
        $stmt2->execute();
        $subjects = $stmt2->get_result()->fetch_all(MYSQLI_ASSOC);

        $stmt3 = $db->prepare('SELECT * FROM user_stats WHERE user_id=?');
        $stmt3->bind_param('i', $userId);
        $stmt3->execute();
        $stats = $stmt3->get_result()->fetch_assoc();

        sendJSON(['success'=>true, 'user'=>$user, 'subjects'=>$subjects, 'stats'=>$stats]);
        break;

    // ── SAVE PROFILE SETUP ─────────────────────────
    case 'POST':
        if ($action === 'setup') {
            $data     = getRequestBody();
            $course   = $data['course']     ?? '';
            $semester = $data['semester']   ?? '1';
            $dailyH   = (int)($data['daily_hours']      ?? 4);
            $pref     = $data['study_preference']        ?? 'morning';
            $goalH    = (int)($data['weekly_goal_hours'] ?? 20);
            $subjects = $data['subjects']                ?? [];
            $favSubs  = isset($data['favorite_subjects']) ? json_encode($data['favorite_subjects']) : null;

            // Update user
            $stmt = $db->prepare('UPDATE users SET course=?, semester=?, daily_hours=?, study_preference=?, favorite_subjects=? WHERE id=?');
            $stmt->bind_param('ssissi', $course, $semester, $dailyH, $pref, $favSubs, $userId);
            $stmt->execute();

            // Update or create stats
            $stmt = $db->prepare('INSERT INTO user_stats (user_id, weekly_goal_hours) VALUES (?,?) ON DUPLICATE KEY UPDATE weekly_goal_hours=?');
            $stmt->bind_param('iii', $userId, $goalH, $goalH);
            $stmt->execute();

            // Clear and re-insert subjects
            $stmt = $db->prepare('DELETE FROM subjects WHERE user_id=?');
            $stmt->bind_param('i', $userId);
            $stmt->execute();

            $colors = ['#10b981','#00d2ff','#f59e0b','#7c3aed','#ec4899','#f43f5e'];
            foreach ($subjects as $i => $sub) {
                $name  = trim($sub['name'] ?? '');
                if (!$name) continue;
                $diff  = $sub['difficulty'] ?? 'medium';
                $exam  = $sub['exam_date']  ?? null;
                $cred  = (int)($sub['credits'] ?? 3);
                $color = $colors[$i % count($colors)];
                $stmt  = $db->prepare('INSERT INTO subjects (user_id, name, difficulty, exam_date, credits, color) VALUES (?,?,?,?,?,?)');
                $stmt->bind_param('isssis', $userId, $name, $diff, $exam, $cred, $color);
                $stmt->execute();
            }

            // Notification
            $title = "Profile Updated ✅";
            $msg   = "Your study profile has been saved. Ready to generate your AI schedule!";
            $stmt  = $db->prepare('INSERT INTO notifications (user_id, title, message, type, icon) VALUES (?,?,?,?,?)');
            $stmt->bind_param('issss', $userId, $title, $msg, 'info', '✅');
            $stmt->execute();

            sendJSON(['success'=>true, 'message'=>'Profile saved! Redirecting to dashboard...']);

        } elseif ($action === 'add_subject') {
            $data  = getRequestBody();
            $name  = trim($data['name'] ?? '');
            $diff  = $data['difficulty'] ?? 'medium';
            $exam  = $data['exam_date']  ?? null;
            $cred  = (int)($data['credits'] ?? 3);

            if (!$name) sendJSON(['success'=>false,'error'=>'Subject name required']);

            $stmt = $db->prepare('INSERT INTO subjects (user_id, name, difficulty, exam_date, credits) VALUES (?,?,?,?,?)');
            $stmt->bind_param('isssi', $userId, $name, $diff, $exam, $cred);
            $stmt->execute();
            $id = $db->insert_id;

            sendJSON(['success'=>true,'id'=>$id]);
        }
        break;

    // ── UPDATE USER PROFILE ────────────────────────
    case 'PUT':
        $data = getRequestBody();
        $name = trim($data['name'] ?? '');
        $course   = $data['course']   ?? '';
        $semester = $data['semester'] ?? '';

        if ($name) {
            $initials = strtoupper(implode('', array_map(fn($w)=>$w[0], explode(' ',$name))));
            $initials = substr($initials,0,2);
            $stmt = $db->prepare('UPDATE users SET name=?, course=?, semester=?, avatar_initials=? WHERE id=?');
            $stmt->bind_param('ssssi', $name, $course, $semester, $initials, $userId);
            $stmt->execute();
            $_SESSION['user_name'] = $name;
        }
        sendJSON(['success'=>true]);
        break;

    // ── DELETE SUBJECT ─────────────────────────────
    case 'DELETE':
        $id = (int)($_GET['id'] ?? 0);
        if (!$id) sendJSON(['success'=>false,'error'=>'Subject ID required']);
        $stmt = $db->prepare('DELETE FROM subjects WHERE id=? AND user_id=?');
        $stmt->bind_param('ii', $id, $userId);
        $stmt->execute();
        sendJSON(['success'=>true]);
        break;
}
