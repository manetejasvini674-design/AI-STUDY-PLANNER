<?php
// =====================================================
// StudyAI - Analytics API
// File: api/analytics.php
// =====================================================

require_once '../config.php';
startSession();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

$userId = getAuthUser();
$method = $_SERVER['REQUEST_METHOD'];
$db     = getDB();

switch ($method) {

    case 'GET':
        $type = $_GET['type'] ?? 'overview';

        if ($type === 'overview') {
            // ── WEEKLY STUDY HOURS (last 7 days) ──
            $weeklyData = [];
            for ($i = 6; $i >= 0; $i--) {
                $date = date('Y-m-d', strtotime("-$i days"));
                $stmt = $db->prepare('SELECT COALESCE(SUM(duration_minutes),0) as mins FROM study_sessions WHERE user_id=? AND session_date=?');
                $stmt->bind_param('is', $userId, $date);
                $stmt->execute();
                $row = $stmt->get_result()->fetch_assoc();
                $weeklyData[] = [
                    'date'  => $date,
                    'day'   => date('D', strtotime($date)),
                    'hours' => round($row['mins'] / 60, 1)
                ];
            }

            // ── TASK STATS ──
            $stmt = $db->prepare('SELECT status, COUNT(*) as cnt FROM tasks WHERE user_id=? GROUP BY status');
            $stmt->bind_param('i', $userId);
            $stmt->execute();
            $taskRows = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $taskStats = ['todo'=>0,'inprogress'=>0,'done'=>0,'total'=>0];
            foreach ($taskRows as $r) {
                $taskStats[$r['status']] = (int)$r['cnt'];
                $taskStats['total'] += (int)$r['cnt'];
            }
            $taskStats['completion_rate'] = $taskStats['total'] > 0
                ? round(($taskStats['done'] / $taskStats['total']) * 100)
                : 0;

            // ── SUBJECT BREAKDOWN (sessions this week) ──
            $weekStart = date('Y-m-d', strtotime('monday this week'));
            $stmt = $db->prepare('SELECT subject, SUM(duration_minutes) as total_mins FROM study_sessions WHERE user_id=? AND session_date >= ? GROUP BY subject ORDER BY total_mins DESC');
            $stmt->bind_param('is', $userId, $weekStart);
            $stmt->execute();
            $subjectBreakdown = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

            // ── USER STATS ──
            $stmt = $db->prepare('SELECT * FROM user_stats WHERE user_id=?');
            $stmt->bind_param('i', $userId);
            $stmt->execute();
            $stats = $stmt->get_result()->fetch_assoc();

            // ── TOTAL SESSIONS THIS WEEK ──
            $stmt = $db->prepare('SELECT COUNT(*) as cnt, SUM(duration_minutes) as total FROM study_sessions WHERE user_id=? AND session_date >= ?');
            $stmt->bind_param('is', $userId, $weekStart);
            $stmt->execute();
            $sessionRow = $stmt->get_result()->fetch_assoc();

            // ── PRODUCTIVITY TREND (last 30 days, grouped by week) ──
            $prodData = [];
            for ($w = 3; $w >= 0; $w--) {
                $wStart = date('Y-m-d', strtotime("-$w weeks monday this week"));
                $wEnd   = date('Y-m-d', strtotime("-$w weeks sunday this week"));
                $stmt = $db->prepare('SELECT COALESCE(SUM(duration_minutes),0) as mins FROM study_sessions WHERE user_id=? AND session_date BETWEEN ? AND ?');
                $stmt->bind_param('iss', $userId, $wStart, $wEnd);
                $stmt->execute();
                $row = $stmt->get_result()->fetch_assoc();
                $prodData[] = ['week' => "Week " . (4 - $w), 'hours' => round($row['mins'] / 60, 1)];
            }

            // ── SCHEDULE COMPLETION ──
            $stmt = $db->prepare('SELECT COUNT(*) as total, SUM(completed) as done FROM study_schedule WHERE user_id=? AND study_date >= ?');
            $stmt->bind_param('is', $userId, $weekStart);
            $stmt->execute();
            $schedRow = $stmt->get_result()->fetch_assoc();
            $schedCompletion = $schedRow['total'] > 0
                ? round(($schedRow['done'] / $schedRow['total']) * 100)
                : 0;

            sendJSON([
                'success'           => true,
                'weeklyHours'       => $weeklyData,
                'taskStats'         => $taskStats,
                'subjectBreakdown'  => $subjectBreakdown,
                'userStats'         => $stats,
                'weekSessions'      => $sessionRow,
                'productivityTrend' => $prodData,
                'scheduleCompletion'=> $schedCompletion,
                'totalStudyHours'   => $stats['total_study_hours'] ?? 0,
                'streak'            => $stats['current_streak'] ?? 0,
            ]);
        }
        break;

    // ── LOG SESSION (from timer) ───────────────────
    case 'POST':
        $data    = getRequestBody();
        $subject = $data['subject'] ?? 'General';
        $mins    = (int)($data['duration_minutes'] ?? 0);
        $type    = $data['type'] ?? 'focus';

        if ($mins < 1) sendJSON(['success' => false, 'error' => 'Invalid duration']);

        $today = date('Y-m-d');
        $stmt = $db->prepare('INSERT INTO study_sessions (user_id, subject, duration_minutes, session_date, session_type) VALUES (?,?,?,?,?)');
        $stmt->bind_param('isiss', $userId, $subject, $mins, $today, $type);
        $stmt->execute();

        // Update total hours
        $hours = round($mins / 60, 2);
        $stmt_hours = $db->prepare("UPDATE user_stats SET total_study_hours = total_study_hours + ? WHERE user_id = ?");
        $stmt_hours->bind_param("di", $hours, $userId);
        $stmt_hours->execute();

        // Streak logic
        $stmt = $db->prepare('SELECT last_active_date, current_streak, longest_streak FROM user_stats WHERE user_id=?');
        $stmt->bind_param('i', $userId);
        $stmt->execute();
        $sRow = $stmt->get_result()->fetch_assoc();
        $lastDate = $sRow['last_active_date'];
        $streak   = (int)$sRow['current_streak'];
        $longest  = (int)$sRow['longest_streak'];

        $yesterday = date('Y-m-d', strtotime('-1 day'));
        if ($lastDate === $yesterday) {
            $streak++;
        } elseif ($lastDate !== $today) {
            $streak = 1;
        }
        $longest = max($longest, $streak);

        $stmt = $db->prepare('UPDATE user_stats SET last_active_date=?, current_streak=?, longest_streak=? WHERE user_id=?');
        $stmt->bind_param('siii', $today, $streak, $longest, $userId);
        $stmt->execute();

        sendJSON(['success' => true, 'streak' => $streak]);
        break;
}
