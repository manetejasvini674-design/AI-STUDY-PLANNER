<?php
// =====================================================
// StudyAI - AI Career Guide API
// File: api/career.php
// Uses Claude AI to generate personalized career guidance
// based on student's subjects, performance & study patterns
// =====================================================

require_once '../config.php';
startSession();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST');
header('Access-Control-Allow-Headers: Content-Type');

$userId = getAuthUser();
$method = $_SERVER['REQUEST_METHOD'];
$action = $_GET['action'] ?? '';
$db     = getDB();

// ── GATHER STUDENT DATA ───────────────────────────────
function getStudentData($db, $userId) {
    // User profile
    $stmt = $db->prepare('SELECT name, course, semester, favorite_subjects FROM users WHERE id=?');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $user = $stmt->get_result()->fetch_assoc();

    // Subjects with difficulty
    $stmt = $db->prepare('SELECT name, difficulty, exam_date FROM subjects WHERE user_id=? ORDER BY difficulty DESC');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $subjects = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // Study session stats per subject
    $stmt = $db->prepare('SELECT subject, SUM(duration_minutes) as total_mins, COUNT(*) as sessions FROM study_sessions WHERE user_id=? GROUP BY subject ORDER BY total_mins DESC');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $sessionStats = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // Task completion stats
    $stmt = $db->prepare('SELECT subject, COUNT(*) as total, SUM(status="done") as done FROM tasks WHERE user_id=? GROUP BY subject');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $taskStats = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // CGPA data
    $stmt = $db->prepare('SELECT subject, grade, grade_points, credits FROM cgpa_records WHERE user_id=? ORDER BY grade_points DESC');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $cgpaData = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

    // Overall stats
    $stmt = $db->prepare('SELECT * FROM user_stats WHERE user_id=?');
    $stmt->bind_param('i', $userId);
    $stmt->execute();
    $stats = $stmt->get_result()->fetch_assoc();

    return compact('user', 'subjects', 'sessionStats', 'taskStats', 'cgpaData', 'stats');
}

switch ($method) {

    // ── GET STUDENT DATA SUMMARY ──────────────────
    case 'GET':
        if ($action === 'student_data') {
            $data = getStudentData($db, $userId);
            sendJSON(['success' => true, 'data' => $data]);
        }
        break;

    // ── GENERATE AI CAREER GUIDANCE ──────────────
    case 'POST':
        $data     = getRequestBody();
        $genType  = $data['type'] ?? 'full'; // full | roadmap | skills | chat
        $extra    = $data['extra'] ?? [];    // extra context from user input

        $studentData = getStudentData($db, $userId);

        // Build study analysis
        $subjectList = array_map(fn($s) => $s['name'].'('.$s['difficulty'].')', $studentData['subjects']);
        $favSubsRaw  = $studentData['user']['favorite_subjects'] ?? null;
        $favSubs     = $favSubsRaw ? (json_decode($favSubsRaw, true) ?: []) : [];
        $topStudied  = array_slice($studentData['sessionStats'], 0, 3);
        $topSubjects = array_map(fn($s) => $s['subject'].': '.round($s['total_mins']/60,1).'h', $topStudied);
        $cgpaSubs    = array_map(fn($c) => $c['subject'].': '.$c['grade'].' ('.$c['grade_points'].' GP)', $studentData['cgpaData']);

        $totalHours  = $studentData['stats']['total_study_hours'] ?? 0;
        $streak      = $studentData['stats']['current_streak'] ?? 0;
        $tasksDone   = $studentData['stats']['tasks_completed'] ?? 0;

        // Detect strong subjects from CGPA and study time
        $strongSubjects = [];
        foreach ($studentData['cgpaData'] as $c) {
            if ($c['grade_points'] >= 8) $strongSubjects[] = $c['subject'];
        }
        foreach ($studentData['sessionStats'] as $s) {
            if ($s['total_mins'] >= 120) $strongSubjects[] = $s['subject'];
        }
        $strongSubjects = array_unique($strongSubjects);

        // Build context
        $studentContext = "
Student Profile:
- Name: {$studentData['user']['name']}
- Course/Stream: {$studentData['user']['course']}
- Semester: {$studentData['user']['semester']}
- Registered Subjects: " . implode(', ', $subjectList) . "
- Favorite/Priority Subjects: " . (empty($favSubs) ? 'Not specified' : implode(', ', $favSubs)) . "
- Total Study Hours Logged: {$totalHours}h
- Current Day Streak: {$streak} days
- Tasks Completed: {$tasksDone}
- Most-Studied Subjects (time): " . implode(', ', $topSubjects) . "
- Strong Subjects (CGPA/time): " . implode(', ', $strongSubjects) . "
- CGPA Records: " . implode(', ', $cgpaSubs) . "
";

        $quizAnswers = $extra['quiz_answers'] ?? [];
        if (!empty($quizAnswers)) {
            $studentContext .= "\nStudent's Quiz Answers:\n";
            foreach ($quizAnswers as $q => $a) {
                $studentContext .= "- $q: $a\n";
            }
        }

        // Also accept favorite_subjects passed directly from frontend
        $extraFavSubs = $extra['favorite_subjects'] ?? [];
        if (!empty($extraFavSubs) && is_array($extraFavSubs)) {
            $studentContext .= "\nFavourite/Priority Subjects (user-declared): " . implode(', ', $extraFavSubs) . "\n";
            $studentContext .= "IMPORTANT: Base your top career recommendations primarily on these favourite subjects!\n";
        }

        $userMessage = $extra['message'] ?? '';

        // Build prompts based on type
        if ($genType === 'chat') {
            $systemPrompt = "You are CareerAI, a smart and friendly career counselor for students. You have access to the student's study data and help them with personalized career advice.

{$studentContext}

RULES:
- Be warm, motivating, specific. Use the student's actual data.
- Give concrete, actionable advice.
- Keep responses concise (under 250 words).
- Use emojis sparingly for friendliness.
- Format with bullet points when listing steps.
- Always tie advice back to their actual subjects and study patterns.";

            $userPrompt = $userMessage ?: "What career should I pursue based on my subjects?";

        } elseif ($genType === 'roadmap') {
            $career = $extra['career'] ?? 'Software Engineer';
            $systemPrompt = "You are CareerAI, an expert career roadmap generator for students.

{$studentContext}

Generate a personalized, detailed 12-month career roadmap for becoming a {$career}.
Respond ONLY with valid JSON (no markdown, no backticks) in this exact format:
{
  \"career\": \"career name\",
  \"match_score\": 85,
  \"match_reason\": \"why this fits the student\",
  \"phases\": [
    {
      \"phase\": \"Phase name\",
      \"duration\": \"3 months\",
      \"icon\": \"emoji\",
      \"color\": \"#hexcolor\",
      \"tasks\": [\"task 1\", \"task 2\", \"task 3\", \"task 4\"]
    }
  ],
  \"key_skills\": [\"skill1\", \"skill2\", \"skill3\", \"skill4\", \"skill5\"],
  \"salary_range\": \"₹X – ₹Y LPA\",
  \"top_companies\": [\"Company1\", \"Company2\", \"Company3\", \"Company4\"],
  \"personalized_tip\": \"specific tip based on their study data\"
}";
            $userPrompt = "Generate roadmap for {$career} based on my profile.";

        } else {
            // Full career analysis
            $systemPrompt = "You are CareerAI, a brilliant AI career counselor analyzing a student's academic data.

{$studentContext}

Analyze the student's data and generate a comprehensive career analysis.
Respond ONLY with valid JSON (no markdown, no backticks) in this exact format:
{
  \"top_careers\": [
    {
      \"id\": \"unique_id\",
      \"title\": \"Career Title\",
      \"icon\": \"emoji\",
      \"match_score\": 92,
      \"match_reason\": \"2-sentence personalized reason based on their actual subjects\",
      \"salary\": \"₹X – ₹Y LPA\",
      \"demand\": 90,
      \"color\": \"#hexcolor\",
      \"key_skills\": [\"skill1\", \"skill2\", \"skill3\"],
      \"time_to_job\": \"X months\"
    }
  ],
  \"strongest_subjects\": [\"subject1\", \"subject2\"],
  \"study_personality\": \"2-3 sentence description of their study style based on data\",
  \"study_insights\": [
    {\"icon\": \"emoji\", \"label\": \"insight title\", \"value\": \"insight value\"}
  ],
  \"immediate_actions\": [\"action1\", \"action2\", \"action3\"],
  \"ai_summary\": \"3-4 sentence personalized summary tying their subjects, study habits, and career potential together\"
}";
            $userPrompt = "Analyze my academic profile and recommend the best career paths.";
        }

        // Call Anthropic API
        $anthropicKey = defined('ANTHROPIC_API_KEY') ? ANTHROPIC_API_KEY : (getenv('ANTHROPIC_API_KEY') ?: '');
        if (!$anthropicKey) {
            // Fallback: generate smart rule-based recommendation
            sendJSON(['success' => true, 'type' => $genType, 'data' => generateFallbackCareer($studentData, $genType, $extra)]);
            break;
        }

        $payload = [
            'model'      => 'claude-opus-4-6',
            'max_tokens' => $genType === 'chat' ? 400 : 1200,
            'system'     => $systemPrompt,
            'messages'   => [['role' => 'user', 'content' => $userPrompt]]
        ];

        $ch = curl_init('https://api.anthropic.com/v1/messages');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_HTTPHEADER     => [
                'Content-Type: application/json',
                'x-api-key: ' . $anthropicKey,
                'anthropic-version: 2023-06-01'
            ],
            CURLOPT_TIMEOUT => 30
        ]);

        $response = curl_exec($ch);
        $curlError = curl_error($ch);
        curl_close($ch);

        if ($curlError) {
            sendJSON(['success' => false, 'error' => 'AI service error: ' . $curlError]);
        }

        $aiResponse = json_decode($response, true);
        if (!isset($aiResponse['content'][0]['text'])) {
            // Fallback
            sendJSON(['success' => true, 'type' => $genType, 'data' => generateFallbackCareer($studentData, $genType, $extra)]);
            break;
        }

        $aiText = $aiResponse['content'][0]['text'];

        if ($genType === 'chat') {
            sendJSON(['success' => true, 'type' => 'chat', 'data' => ['message' => $aiText]]);
        } else {
            // Parse JSON response
            $parsed = json_decode($aiText, true);
            if (!$parsed) {
                // Try extracting JSON from text
                preg_match('/\{.*\}/s', $aiText, $matches);
                $parsed = $matches ? json_decode($matches[0], true) : null;
            }
            if ($parsed) {
                sendJSON(['success' => true, 'type' => $genType, 'data' => $parsed]);
            } else {
                sendJSON(['success' => true, 'type' => $genType, 'data' => generateFallbackCareer($studentData, $genType, $extra)]);
            }
        }
        break;
}

// ── RULE-BASED FALLBACK (when no API key) ─────────────
function generateFallbackCareer($studentData, $genType, $extra) {
    $subjects    = array_map(fn($s) => strtolower($s['name']), $studentData['subjects']);
    $topStudied  = $studentData['sessionStats'][0]['subject'] ?? 'General';
    $course      = strtolower($studentData['user']['course'] ?? '');
    $totalHours  = $studentData['stats']['total_study_hours'] ?? 0;
    $streak      = $studentData['stats']['current_streak'] ?? 0;

    // Determine career matches based on subjects
    $careerMap = [
        ['keywords'=>['math','physics','computer','programming','algorithm'],
         'careers'  =>[
            ['id'=>'software','title'=>'Software Engineer','icon'=>'💻','match_score'=>92,'salary'=>'₹8L–₹40L','demand'=>95,'color'=>'#00d2ff','key_skills'=>['DSA','System Design','JavaScript','Python','SQL'],'time_to_job'=>'6 months'],
            ['id'=>'aiml',   'title'=>'AI/ML Engineer',   'icon'=>'🤖','match_score'=>88,'salary'=>'₹12L–₹60L','demand'=>98,'color'=>'#ec4899','key_skills'=>['Python','TensorFlow','Math','Statistics','LLMs'],'time_to_job'=>'9 months'],
         ]],
        ['keywords'=>['chemistry','biology','physics','science'],
         'careers'  =>[
            ['id'=>'research','title'=>'Research Scientist','icon'=>'🔬','match_score'=>90,'salary'=>'₹6L–₹30L','demand'=>80,'color'=>'#10b981','key_skills'=>['Research Methods','Data Analysis','Lab Skills','Python','Statistics'],'time_to_job'=>'12 months'],
            ['id'=>'datascience','title'=>'Data Scientist','icon'=>'📊','match_score'=>85,'salary'=>'₹10L–₹45L','demand'=>93,'color'=>'#7c3aed','key_skills'=>['Python','SQL','Statistics','ML','Visualization'],'time_to_job'=>'8 months'],
         ]],
        ['keywords'=>['english','history','economics','business','commerce'],
         'careers'  =>[
            ['id'=>'product','title'=>'Product Manager','icon'=>'🎯','match_score'=>87,'salary'=>'₹15L–₹55L','demand'=>88,'color'=>'#a78bfa','key_skills'=>['Strategy','User Research','Agile','Analytics','Communication'],'time_to_job'=>'8 months'],
            ['id'=>'marketing','title'=>'Digital Marketer','icon'=>'📱','match_score'=>84,'salary'=>'₹5L–₹25L','demand'=>85,'color'=>'#f59e0b','key_skills'=>['SEO','Content','Analytics','Social Media','Copywriting'],'time_to_job'=>'4 months'],
         ]],
    ];

    $matchedCareers = [];
    foreach ($careerMap as $map) {
        $score = 0;
        foreach ($subjects as $sub) {
            foreach ($map['keywords'] as $kw) {
                if (str_contains($sub, $kw)) $score++;
            }
        }
        if (str_contains($course, implode('|', $map['keywords']))) $score += 2;
        if ($score > 0) {
            foreach ($map['careers'] as $c) {
                $c['match_reason'] = "Based on your {$topStudied} focus and {$totalHours}h of logged study, this career aligns with your academic strengths.";
                $matchedCareers[] = $c;
            }
        }
    }

    // Ensure at least 3 careers
    $default = [
        ['id'=>'software','title'=>'Software Engineer','icon'=>'💻','match_score'=>80,'match_reason'=>"Strong analytical skills from your studies make you a great fit for software development.",'salary'=>'₹8L–₹40L','demand'=>95,'color'=>'#00d2ff','key_skills'=>['DSA','JavaScript','Python','Git','System Design'],'time_to_job'=>'6 months'],
        ['id'=>'datascience','title'=>'Data Scientist','icon'=>'📊','match_score'=>78,'match_reason'=>"Your consistent study habits and analytical approach suit data science well.",'salary'=>'₹10L–₹45L','demand'=>93,'color'=>'#7c3aed','key_skills'=>['Python','SQL','Statistics','ML','Tableau'],'time_to_job'=>'8 months'],
        ['id'=>'product','title'=>'Product Manager','icon'=>'🎯','match_score'=>75,'match_reason'=>"Your multi-subject discipline shows the breadth needed for product management.",'salary'=>'₹15L–₹55L','demand'=>88,'color'=>'#a78bfa','key_skills'=>['Strategy','UX','Analytics','Communication','Agile'],'time_to_job'=>'8 months'],
    ];

    if (count($matchedCareers) < 2) $matchedCareers = $default;
    usort($matchedCareers, fn($a,$b)=>$b['match_score']-$a['match_score']);
    $matchedCareers = array_slice($matchedCareers, 0, 4);

    if ($genType === 'roadmap') {
        $career = $extra['career'] ?? 'Software Engineer';
        return [
            'career'         => $career,
            'match_score'    => 85,
            'match_reason'   => "Based on your subjects and {$totalHours}h of study data",
            'phases'         => [
                ['phase'=>'Foundation','duration'=>'3 months','icon'=>'📚','color'=>'#00d2ff','tasks'=>['Learn core programming concepts','Build 3 small projects','Study data structures','Get comfortable with Git']],
                ['phase'=>'Intermediate','duration'=>'3 months','icon'=>'🔧','color'=>'#7c3aed','tasks'=>['Build full-stack project','Learn databases','Practice system design','Contribute to open source']],
                ['phase'=>'Advanced','duration'=>'3 months','icon'=>'🚀','color'=>'#10b981','tasks'=>['Build portfolio project','Start applying to internships','Practice interview problems','Network on LinkedIn']],
                ['phase'=>'Job Ready','duration'=>'3 months','icon'=>'🏆','color'=>'#f59e0b','tasks'=>['Apply to 10+ companies/week','Mock interviews daily','Negotiate offers','Land your dream job!']],
            ],
            'key_skills'     => ['Python/JavaScript','Data Structures','System Design','SQL','Git'],
            'salary_range'   => '₹8L–₹40L LPA',
            'top_companies'  => ['Google','Microsoft','Amazon','Flipkart','Startups'],
            'personalized_tip'=> "Your {$streak}-day streak shows discipline — apply the same consistency to daily LeetCode practice!"
        ];
    }

    return [
        'top_careers'      => $matchedCareers,
        'strongest_subjects'=> array_slice($subjects, 0, 2),
        'study_personality'=> "You are a " . ($totalHours > 50 ? "dedicated, high-intensity" : "steady, consistent") . " learner. Your {$streak}-day streak shows strong self-discipline. You tend to focus deeply on subjects you're passionate about.",
        'study_insights'   => [
            ['icon'=>'⏱️','label'=>'Total Hours Logged','value'=>$totalHours.'h'],
            ['icon'=>'🔥','label'=>'Current Streak','value'=>$streak.' days'],
            ['icon'=>'✅','label'=>'Tasks Completed','value'=>$studentData['stats']['tasks_completed']??0],
            ['icon'=>'📚','label'=>'Subjects Tracked','value'=>count($subjects)],
        ],
        'immediate_actions'=> [
            'Set up a LinkedIn profile and add your top subjects',
            'Start a personal project using '.(ucfirst($subjects[0]??'your best subject')),
            'Aim for 1 certification in your target career field this semester',
        ],
        'ai_summary'       => "Based on your {$totalHours}h of logged study and focus on ".implode(', ', array_slice($subjects,0,2)).", you show strong potential in analytical and technical fields. Your {$streak}-day study streak demonstrates the discipline needed to succeed in competitive careers. Focus on building projects in your strongest subjects to stand out to employers."
    ];
}
