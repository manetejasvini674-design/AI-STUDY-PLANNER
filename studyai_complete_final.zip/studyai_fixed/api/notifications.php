<?php
// =====================================================
// StudyAI - Notifications API
// File: api/notifications.php
// =====================================================

require_once '../config.php';
startSession();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
header('Access-Control-Allow-Headers: Content-Type');

$userId = getAuthUser();
$method = $_SERVER['REQUEST_METHOD'];
$db     = getDB();

switch ($method) {

    case 'GET':
        $limit = (int)($_GET['limit'] ?? 50);
        $stmt = $db->prepare('SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT ?');
        $stmt->bind_param('ii', $userId, $limit);
        $stmt->execute();
        $notifs = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

        $stmt2 = $db->prepare('SELECT COUNT(*) as cnt FROM notifications WHERE user_id=? AND status="unread"');
        $stmt2->bind_param('i', $userId);
        $stmt2->execute();
        $unread = $stmt2->get_result()->fetch_assoc()['cnt'];

        sendJSON(['success' => true, 'notifications' => $notifs, 'unread_count' => (int)$unread]);
        break;

    case 'PUT':
        $data = getRequestBody();
        $id   = (int)($data['id'] ?? 0);
        if ($id) {
            $stmt = $db->prepare('UPDATE notifications SET status="read" WHERE id=? AND user_id=?');
            $stmt->bind_param('ii', $id, $userId);
        } else {
            // Mark all read
            $stmt = $db->prepare('UPDATE notifications SET status="read" WHERE user_id=?');
            $stmt->bind_param('i', $userId);
        }
        $stmt->execute();
        sendJSON(['success' => true]);
        break;

    case 'DELETE':
        $id = (int)($_GET['id'] ?? 0);
        if ($id) {
            $stmt = $db->prepare('DELETE FROM notifications WHERE id=? AND user_id=?');
            $stmt->bind_param('ii', $id, $userId);
        } else {
            $stmt = $db->prepare('DELETE FROM notifications WHERE user_id=?');
            $stmt->bind_param('i', $userId);
        }
        $stmt->execute();
        sendJSON(['success' => true]);
        break;
}
