<?php
// =====================================================
// StudyAI - Dashboard API
// File: api/dashboard.php
// =====================================================

require_once '../config.php';
startSession();

header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');
header('Access-Control-Allow-Headers: Content-Type');

$userId = getAuthUser();
$db     = getDB();

// User info
$stmt = $db->prepare('SELECT name, avatar_initials, course, semester FROM users WHERE id=?');
$stmt->bind_param('i', $userId);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

// Stats
$stmt = $db->prepare('SELECT * FROM user_stats WHERE user_id=?');
$stmt->bind_param('i', $userId);
$stmt->execute();
$stats = $stmt->get_result()->fetch_assoc() ?? ['current_streak'=>0,'total_study_hours'=>0,'tasks_completed'=>0,'weekly_goal_hours'=>20];

// Today's schedule
$today = date('Y-m-d');
$stmt = $db->prepare('SELECT * FROM study_schedule WHERE user_id=? AND study_date=? ORDER BY start_time');
$stmt->bind_param('is', $userId, $today);
$stmt->execute();
$todaySchedule = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Upcoming tasks (next 7 days, not done)
$next7 = date('Y-m-d', strtotime('+7 days'));
$stmt = $db->prepare('SELECT * FROM tasks WHERE user_id=? AND status != "done" AND (deadline IS NULL OR deadline <= ?) ORDER BY deadline ASC LIMIT 5');
$stmt->bind_param('is', $userId, $next7);
$stmt->execute();
$upcomingTasks = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Task completion this week
$weekStart = date('Y-m-d', strtotime('monday this week'));
$stmt = $db->prepare('SELECT COUNT(*) as total, SUM(status="done") as done FROM tasks WHERE user_id=? AND created_at >= ?');
$stmt->bind_param('is', $userId, $weekStart);
$stmt->execute();
$taskWeek = $stmt->get_result()->fetch_assoc();
$taskCompletion = $taskWeek['total'] > 0 ? round(($taskWeek['done'] / $taskWeek['total']) * 100) : 0;

// Weekly study hours
$stmt = $db->prepare('SELECT COALESCE(SUM(duration_minutes),0) as mins FROM study_sessions WHERE user_id=? AND session_date >= ?');
$stmt->bind_param('is', $userId, $weekStart);
$stmt->execute();
$weekMins = $stmt->get_result()->fetch_assoc()['mins'];
$weekHours = round($weekMins / 60, 1);

// Unread notifications count
$stmt = $db->prepare('SELECT COUNT(*) as cnt FROM notifications WHERE user_id=? AND status="unread"');
$stmt->bind_param('i', $userId);
$stmt->execute();
$unreadNotifs = $stmt->get_result()->fetch_assoc()['cnt'];

// Subjects + exam countdown
$stmt = $db->prepare('SELECT name, exam_date, color, difficulty FROM subjects WHERE user_id=? ORDER BY exam_date ASC LIMIT 4');
$stmt->bind_param('i', $userId);
$stmt->execute();
$subjects = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
foreach ($subjects as &$s) {
    if ($s['exam_date']) {
        $diff = (new DateTime())->diff(new DateTime($s['exam_date']));
        $s['days_left'] = $diff->days;
    } else {
        $s['days_left'] = null;
    }
}
unset($s);

// Bar chart data (last 7 days hours)
$chartData = [];
for ($i = 6; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i days"));
    $stmt = $db->prepare('SELECT COALESCE(SUM(duration_minutes),0) as mins FROM study_sessions WHERE user_id=? AND session_date=?');
    $stmt->bind_param('is', $userId, $d);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc();
    $chartData[] = ['day' => date('D', strtotime($d)), 'hours' => round($row['mins'] / 60, 1)];
}

sendJSON([
    'success'         => true,
    'user'            => $user,
    'stats'           => $stats,
    'weekHours'       => $weekHours,
    'weeklyGoal'      => (int)($stats['weekly_goal_hours'] ?? 20),
    'todaySchedule'   => $todaySchedule,
    'upcomingTasks'   => $upcomingTasks,
    'taskCompletion'  => $taskCompletion,
    'unreadNotifs'    => (int)$unreadNotifs,
    'subjects'        => $subjects,
    'chartData'       => $chartData,
]);
