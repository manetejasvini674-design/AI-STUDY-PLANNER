<?php
// =====================================================
// StudyAI - Database Configuration
// File: config.php
// =====================================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');        // Change to your phpMyAdmin username
define('DB_PASS', '');            // Change to your phpMyAdmin password
define('DB_NAME', 'study_planner_db');
define('BASE_URL', 'http://localhost/studyai/'); // Change to your XAMPP path

// ── ANTHROPIC API KEY (for AI Career Guide feature) ──────────────
// Get your free key from: https://console.anthropic.com
// Set this as an environment variable OR paste it directly below:
define('ANTHROPIC_API_KEY', getenv('ANTHROPIC_API_KEY') ?: 'YOUR_ANTHROPIC_API_KEY_HERE');

// Create connection
function getDB() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if ($conn->connect_error) {
        http_response_code(500);
        die(json_encode(['success' => false, 'error' => 'Database connection failed: ' . $conn->connect_error]));
    }
    $conn->set_charset('utf8mb4');
    return $conn;
}

// Start session if not started
function startSession() {
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
}

// Send JSON response
function sendJSON($data, $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json');
    header('Access-Control-Allow-Origin: *');
    header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE');
    header('Access-Control-Allow-Headers: Content-Type');
    echo json_encode($data);
    exit;
}

// Get logged in user ID
function getAuthUser() {
    startSession();
    if (!isset($_SESSION['user_id'])) {
        sendJSON(['success' => false, 'error' => 'Not authenticated'], 401);
    }
    return $_SESSION['user_id'];
}

// Get request body as JSON
function getRequestBody() {
    $input = file_get_contents('php://input');
    return json_decode($input, true) ?? [];
}
